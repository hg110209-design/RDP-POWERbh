import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Profile from "./pages/Profile";
import ProPartner from "./pages/ProPartner";
import ProPartnership from "./pages/ProPartnership";
import LevelTeam from "./pages/LevelTeam";
import ReferEarn from "./pages/ReferEarn";
import Withdrawal from "./pages/Withdrawal";
import NewsEvents from "./pages/NewsEvents";
import Support from "./pages/Support";
import Payment from "./pages/Payment";
import GlobalMining from "./pages/GlobalMining";
import AdminLogin from "./pages/admin/AdminLogin";
import AdminDashboard from "./pages/admin/AdminDashboard";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/register" element={<Register />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/pro-partner" element={<ProPartner />} />
          <Route path="/pro-partnership" element={<ProPartnership />} />
          <Route path="/level-team" element={<LevelTeam />} />
          <Route path="/refer-earn" element={<ReferEarn />} />
          <Route path="/withdrawal" element={<Withdrawal />} />
          <Route path="/news-events" element={<NewsEvents />} />
          <Route path="/support" element={<Support />} />
          <Route path="/payment/:type" element={<Payment />} />
          <Route path="/global-mining" element={<GlobalMining />} />
          <Route path="/admin" element={<AdminLogin />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
