import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Plus, Save, Trash2, Check, X, Edit2 } from "lucide-react";
import ImageUpload from "./ImageUpload";

interface Props { section: string; }

const PaymentSettings = ({ section }: Props) => {
  const { toast } = useToast();
  const [methods, setMethods] = useState<any[]>([]);
  const [pending, setPending] = useState<any[]>([]);
  const [newMethod, setNewMethod] = useState({ name: "", number: "", image_url: "" });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editData, setEditData] = useState({ name: "", number: "", image_url: "" });

  useEffect(() => { fetchData(); }, [section]);

  const fetchData = async () => {
    if (section === "payment-methods") {
      const { data } = await supabase.from("payment_methods").select("*");
      setMethods(data || []);
    } else {
      let type = section === "payment-pending" ? "account_activation" : section === "referral-pending" ? "referral_earn" : "global_earn";
      
      // Fetch payment requests
      const { data: requests } = await supabase
        .from("payment_requests")
        .select("*")
        .eq("type", type)
        .eq("status", "pending");
      
      if (requests && requests.length > 0) {
        // Fetch profiles for each request
        const userIds = requests.map(r => r.user_id);
        const { data: profiles } = await supabase
          .from("profiles")
          .select("user_id, username, email")
          .in("user_id", userIds);
        
        // Merge profiles with requests
        const mergedData = requests.map(req => ({
          ...req,
          profiles: profiles?.find(p => p.user_id === req.user_id) || null
        }));
        setPending(mergedData);
      } else {
        setPending([]);
      }
    }
  };

  const handleAddMethod = async () => {
    if (!newMethod.name || !newMethod.number) return;
    await supabase.from("payment_methods").insert(newMethod);
    setNewMethod({ name: "", number: "", image_url: "" });
    fetchData();
    toast({ title: "Added", description: "Payment method added." });
  };

  const handleDeleteMethod = async (id: string) => {
    await supabase.from("payment_methods").delete().eq("id", id);
    fetchData();
    toast({ title: "Deleted", description: "Payment method removed." });
  };

  const handleEdit = (item: any) => {
    setEditingId(item.id);
    setEditData({ name: item.name, number: item.number, image_url: item.image_url || "" });
  };

  const handleSaveEdit = async () => {
    if (!editingId) return;
    await supabase.from("payment_methods").update(editData).eq("id", editingId);
    setEditingId(null);
    fetchData();
    toast({ title: "Updated" });
  };

  const handleRequest = async (id: string, userId: string, type: string, approve: boolean) => {
    await supabase.from("payment_requests").update({ status: approve ? "approved" : "rejected" }).eq("id", id);
    if (approve) {
      if (type === "account_activation") {
        // Update profile status to active
        await supabase.from("profiles").update({ status: "active" }).eq("user_id", userId);
        
        // Add referral bonus to referrer
        const { data: profile } = await supabase
          .from("profiles")
          .select("referred_by")
          .eq("user_id", userId)
          .single();
        
        if (profile?.referred_by) {
          // Get referral bonus amount from settings
          const { data: bonusSetting } = await supabase
            .from("site_settings")
            .select("value")
            .eq("key", "referral_bonus")
            .single();
          
          const bonusAmount = parseFloat(bonusSetting?.value || "0");
          
          if (bonusAmount > 0) {
            // Add bonus to referrer's balance
            const { data: referrer } = await supabase
              .from("profiles")
              .select("total_profit")
              .eq("refer_code", profile.referred_by)
              .single();
            
            if (referrer) {
              await supabase
                .from("profiles")
                .update({ 
                  total_profit: (referrer.total_profit || 0) + bonusAmount 
                })
                .eq("refer_code", profile.referred_by);
            }
          }
        }
      }
      if (type === "referral_earn") await supabase.from("profiles").update({ referral_earn_active: true }).eq("user_id", userId);
      if (type === "global_earn") await supabase.from("profiles").update({ global_earn_active: true }).eq("user_id", userId);
    }
    fetchData();
    toast({ title: approve ? "Approved" : "Rejected" });
  };

  if (section === "payment-methods") {
    return (
      <div className="space-y-4">
        <h2 className="font-display text-xl font-bold">Payment Methods</h2>
        <div className="glass-card p-4 space-y-3">
          <input type="text" placeholder="Method Name" value={newMethod.name} onChange={(e) => setNewMethod({ ...newMethod, name: e.target.value })} className="input-field" />
          <input type="text" placeholder="Account Number" value={newMethod.number} onChange={(e) => setNewMethod({ ...newMethod, number: e.target.value })} className="input-field" />
          <label className="block text-sm font-medium">Image</label>
          <ImageUpload value={newMethod.image_url} onChange={(url) => setNewMethod({ ...newMethod, image_url: url })} folder="payment" />
          <button onClick={handleAddMethod} className="btn-primary flex items-center gap-2"><Plus className="h-4 w-4" /> Add Method</button>
        </div>
        
        {methods.map((m) => (
          <div key={m.id} className="glass-card p-4">
            {editingId === m.id ? (
              <div className="space-y-3">
                <input type="text" value={editData.name} onChange={(e) => setEditData({ ...editData, name: e.target.value })} className="input-field" />
                <input type="text" value={editData.number} onChange={(e) => setEditData({ ...editData, number: e.target.value })} className="input-field" />
                <ImageUpload value={editData.image_url} onChange={(url) => setEditData({ ...editData, image_url: url })} folder="payment" />
                <div className="flex gap-2">
                  <button onClick={handleSaveEdit} className="btn-primary flex items-center gap-2"><Save className="h-4 w-4" /> Save</button>
                  <button onClick={() => setEditingId(null)} className="btn-outline flex items-center gap-2"><X className="h-4 w-4" /> Cancel</button>
                </div>
              </div>
            ) : (
              <div className="flex justify-between items-center">
                <div className="flex gap-3 items-center">
                  {m.image_url && <img src={m.image_url} alt="" className="h-10 w-10 rounded-lg object-cover" />}
                  <div>
                    <p className="font-medium">{m.name}</p>
                    <p className="text-sm text-muted-foreground">{m.number}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => handleEdit(m)} className="p-2 text-primary hover:bg-primary/10 rounded-lg"><Edit2 className="h-4 w-4" /></button>
                  <button onClick={() => handleDeleteMethod(m.id)} className="p-2 text-destructive hover:bg-destructive/10 rounded-lg"><Trash2 className="h-4 w-4" /></button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    );
  }

  const getTitle = () => {
    switch (section) {
      case "payment-pending": return "Account Pending";
      case "referral-pending": return "Referral Earn Pending";
      case "global-pending": return "Global Earn Pending";
      default: return "Pending Requests";
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="font-display text-xl font-bold">{getTitle()}</h2>
      {pending.length === 0 ? (
        <div className="glass-card p-8 text-center text-muted-foreground">No pending requests</div>
      ) : (
        pending.map((req) => (
          <div key={req.id} className="glass-card p-4 space-y-3">
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <p className="text-muted-foreground">Username</p>
                <p className="font-medium">{req.profiles?.username || "N/A"}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Email</p>
                <p className="font-medium">{req.profiles?.email || "N/A"}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Transaction ID</p>
                <p className="font-medium font-mono text-xs">{req.transaction_id}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Payment Method</p>
                <p className="font-medium">{req.payment_method}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Amount</p>
                <p className="font-medium text-primary">${req.amount}</p>
              </div>
              <div>
                <p className="text-muted-foreground">User ID</p>
                <p className="font-medium font-mono text-xs truncate">{req.user_id}</p>
              </div>
            </div>
            <div className="flex gap-2 pt-2 border-t border-border">
              <button 
                onClick={() => handleRequest(req.id, req.user_id, req.type, true)} 
                className="flex-1 py-2 bg-success/20 text-success rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-success/30"
              >
                <Check className="h-4 w-4" /> Accept
              </button>
              <button 
                onClick={() => handleRequest(req.id, req.user_id, req.type, false)} 
                className="flex-1 py-2 bg-destructive/20 text-destructive rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-destructive/30"
              >
                <X className="h-4 w-4" /> Reject
              </button>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default PaymentSettings;
