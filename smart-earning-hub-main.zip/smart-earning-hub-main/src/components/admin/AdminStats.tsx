import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Users, DollarSign, Wallet, CreditCard, TrendingUp, Zap, Globe, Clock, CheckCircle, BarChart3 } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from "recharts";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format, subDays, startOfWeek, endOfWeek, eachDayOfInterval } from "date-fns";

interface ChartData {
  name: string;
  transactions: number;
  withdrawals: number;
  users: number;
}

const AdminStats = () => {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalTransactions: 0,
    totalWithdrawals: 0,
    paymentMethods: 0,
    activeAccounts: 0,
    referralEarnUsers: 0,
    globalEarnUsers: 0,
    todayAccounts: 0,
    todayWithdrawals: 0,
    todayReferrals: 0,
    activePlans: 0,
    pendingPayments: 0,
    pendingPlanRequests: 0,
    pendingWithdrawals: 0,
  });

  const [weeklyData, setWeeklyData] = useState<ChartData[]>([]);
  const [monthlyData, setMonthlyData] = useState<ChartData[]>([]);
  const [pieData, setPieData] = useState<{ name: string; value: number; color: string }[]>([]);

  useEffect(() => {
    const fetchStats = async () => {
      const today = new Date().toISOString().split("T")[0];

      const [users, payments, withdrawals, methods, profiles, activePlans, pendingPlanReqs, pendingWithdrawals] = await Promise.all([
        supabase.from("profiles").select("id", { count: "exact" }),
        supabase.from("payment_requests").select("amount, created_at").eq("status", "approved"),
        supabase.from("withdrawals").select("amount, created_at").eq("status", "approved"),
        supabase.from("payment_methods").select("id", { count: "exact" }).eq("is_active", true),
        supabase.from("profiles").select("status, referral_earn_active, global_earn_active, created_at"),
        supabase.from("user_active_plans").select("id", { count: "exact" }).eq("is_active", true),
        supabase.from("plan_activation_requests").select("id", { count: "exact" }).eq("status", "pending"),
        supabase.from("withdrawals").select("id", { count: "exact" }).eq("status", "pending"),
      ]);

      const totalTransactions = payments.data?.reduce((sum, p) => sum + Number(p.amount), 0) || 0;
      const totalWithdrawals = withdrawals.data?.reduce((sum, w) => sum + Number(w.amount), 0) || 0;
      const activeAccounts = profiles.data?.filter(p => p.status === "active").length || 0;
      const referralEarnUsers = profiles.data?.filter(p => p.referral_earn_active).length || 0;
      const globalEarnUsers = profiles.data?.filter(p => p.global_earn_active).length || 0;
      const todayAccounts = profiles.data?.filter(p => p.created_at?.startsWith(today)).length || 0;

      setStats({
        totalUsers: users.count || 0,
        totalTransactions,
        totalWithdrawals,
        paymentMethods: methods.count || 0,
        activeAccounts,
        referralEarnUsers,
        globalEarnUsers,
        todayAccounts,
        todayWithdrawals: 0,
        todayReferrals: 0,
        activePlans: activePlans.count || 0,
        pendingPayments: 0,
        pendingPlanRequests: pendingPlanReqs.count || 0,
        pendingWithdrawals: pendingWithdrawals.count || 0,
      });

      // Generate weekly data (last 7 days)
      const last7Days = eachDayOfInterval({
        start: subDays(new Date(), 6),
        end: new Date()
      });

      const weeklyChartData = last7Days.map(day => {
        const dayStr = format(day, 'yyyy-MM-dd');
        const dayTransactions = payments.data?.filter(p => p.created_at?.startsWith(dayStr))
          .reduce((sum, p) => sum + Number(p.amount), 0) || 0;
        const dayWithdrawals = withdrawals.data?.filter(w => w.created_at?.startsWith(dayStr))
          .reduce((sum, w) => sum + Number(w.amount), 0) || 0;
        const dayUsers = profiles.data?.filter(p => p.created_at?.startsWith(dayStr)).length || 0;

        return {
          name: format(day, 'EEE'),
          transactions: dayTransactions,
          withdrawals: dayWithdrawals,
          users: dayUsers
        };
      });

      setWeeklyData(weeklyChartData);

      // Generate monthly data (last 4 weeks)
      const monthlyChartData = [];
      for (let i = 3; i >= 0; i--) {
        const weekStart = startOfWeek(subDays(new Date(), i * 7));
        const weekEnd = endOfWeek(subDays(new Date(), i * 7));
        const weekStartStr = format(weekStart, 'yyyy-MM-dd');
        const weekEndStr = format(weekEnd, 'yyyy-MM-dd');

        const weekTransactions = payments.data?.filter(p => {
          const date = p.created_at?.split('T')[0];
          return date && date >= weekStartStr && date <= weekEndStr;
        }).reduce((sum, p) => sum + Number(p.amount), 0) || 0;

        const weekWithdrawals = withdrawals.data?.filter(w => {
          const date = w.created_at?.split('T')[0];
          return date && date >= weekStartStr && date <= weekEndStr;
        }).reduce((sum, w) => sum + Number(w.amount), 0) || 0;

        const weekUsers = profiles.data?.filter(p => {
          const date = p.created_at?.split('T')[0];
          return date && date >= weekStartStr && date <= weekEndStr;
        }).length || 0;

        monthlyChartData.push({
          name: `Week ${4 - i}`,
          transactions: weekTransactions,
          withdrawals: weekWithdrawals,
          users: weekUsers
        });
      }

      setMonthlyData(monthlyChartData);

      // Pie chart data
      setPieData([
        { name: 'Active Users', value: activeAccounts, color: 'hsl(var(--primary))' },
        { name: 'Referral Earn', value: referralEarnUsers, color: 'hsl(var(--accent))' },
        { name: 'Global Earn', value: globalEarnUsers, color: 'hsl(var(--success))' },
        { name: 'Pending', value: (users.count || 0) - activeAccounts, color: 'hsl(var(--muted))' },
      ]);
    };

    fetchStats();
  }, []);

  const statCards = [
    { icon: Users, label: "Total Users", value: stats.totalUsers, color: "primary" },
    { icon: DollarSign, label: "Total Transactions", value: `$${stats.totalTransactions}`, color: "success" },
    { icon: Wallet, label: "Total Withdrawals", value: `$${stats.totalWithdrawals}`, color: "accent" },
    { icon: CheckCircle, label: "Active Plans", value: stats.activePlans, color: "success" },
    { icon: CreditCard, label: "Payment Methods", value: stats.paymentMethods, color: "warning" },
    { icon: TrendingUp, label: "Active Accounts", value: stats.activeAccounts, color: "primary" },
    { icon: Zap, label: "Referral Earn Users", value: stats.referralEarnUsers, color: "accent" },
    { icon: Globe, label: "Global Earn Users", value: stats.globalEarnUsers, color: "success" },
  ];

  return (
    <div className="space-y-4">
      <h2 className="font-display text-xl font-bold">Dashboard Overview</h2>
      
      <div className="grid grid-cols-2 gap-3">
        {statCards.map((stat, index) => (
          <div key={index} className="glass-card p-4 animate-slide-up" style={{ animationDelay: `${0.05 * index}s` }}>
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-lg bg-${stat.color}/20 flex items-center justify-center`}>
                <stat.icon className={`h-5 w-5 text-${stat.color}`} />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
                <p className="font-display text-lg font-bold">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="glass-card p-4">
        <div className="flex items-center gap-2 mb-4">
          <BarChart3 className="h-5 w-5 text-primary" />
          <h3 className="font-semibold">Analytics Overview</h3>
        </div>
        
        <Tabs defaultValue="weekly" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="weekly">Weekly</TabsTrigger>
            <TabsTrigger value="monthly">Monthly</TabsTrigger>
          </TabsList>
          
          <TabsContent value="weekly" className="space-y-4">
            <div className="h-48">
              <p className="text-sm text-muted-foreground mb-2">Transactions & Withdrawals (Last 7 Days)</p>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={weeklyData}>
                  <defs>
                    <linearGradient id="colorTransactions" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorWithdrawals" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--accent))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--accent))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }} 
                  />
                  <Area 
                    type="monotone" 
                    dataKey="transactions" 
                    stroke="hsl(var(--primary))" 
                    fillOpacity={1} 
                    fill="url(#colorTransactions)" 
                    name="Transactions ($)"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="withdrawals" 
                    stroke="hsl(var(--accent))" 
                    fillOpacity={1} 
                    fill="url(#colorWithdrawals)" 
                    name="Withdrawals ($)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="h-36">
              <p className="text-sm text-muted-foreground mb-2">New Users (Last 7 Days)</p>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }} 
                  />
                  <Bar dataKey="users" fill="hsl(var(--success))" radius={[4, 4, 0, 0]} name="New Users" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
          
          <TabsContent value="monthly" className="space-y-4">
            <div className="h-48">
              <p className="text-sm text-muted-foreground mb-2">Transactions & Withdrawals (Last 4 Weeks)</p>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={monthlyData}>
                  <defs>
                    <linearGradient id="colorTransactionsMonthly" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorWithdrawalsMonthly" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--accent))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--accent))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }} 
                  />
                  <Area 
                    type="monotone" 
                    dataKey="transactions" 
                    stroke="hsl(var(--primary))" 
                    fillOpacity={1} 
                    fill="url(#colorTransactionsMonthly)" 
                    name="Transactions ($)"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="withdrawals" 
                    stroke="hsl(var(--accent))" 
                    fillOpacity={1} 
                    fill="url(#colorWithdrawalsMonthly)" 
                    name="Withdrawals ($)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="h-36">
              <p className="text-sm text-muted-foreground mb-2">New Users (Last 4 Weeks)</p>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }} 
                  />
                  <Bar dataKey="users" fill="hsl(var(--success))" radius={[4, 4, 0, 0]} name="New Users" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* User Distribution Pie Chart */}
      <div className="glass-card p-4">
        <h3 className="font-semibold mb-3">User Distribution</h3>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={40}
                outerRadius={70}
                paddingAngle={2}
                dataKey="value"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))', 
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }} 
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="grid grid-cols-2 gap-2 mt-2">
          {pieData.map((item, index) => (
            <div key={index} className="flex items-center gap-2 text-xs">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
              <span className="text-muted-foreground">{item.name}: {item.value}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="glass-card p-4">
        <h3 className="font-semibold mb-3">Today's Activity</h3>
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="p-2 bg-secondary rounded-lg">
            <p className="text-xs text-muted-foreground">New Accounts</p>
            <p className="font-display font-bold text-primary">{stats.todayAccounts}</p>
          </div>
          <div className="p-2 bg-secondary rounded-lg">
            <p className="text-xs text-muted-foreground">Withdrawals</p>
            <p className="font-display font-bold text-accent">{stats.todayWithdrawals}</p>
          </div>
          <div className="p-2 bg-secondary rounded-lg">
            <p className="text-xs text-muted-foreground">Referrals</p>
            <p className="font-display font-bold text-success">{stats.todayReferrals}</p>
          </div>
        </div>
      </div>

      <div className="glass-card p-4">
        <h3 className="font-semibold mb-3 flex items-center gap-2">
          <Clock className="h-4 w-4 text-warning" />
          Pending Requests
        </h3>
        <div className="grid grid-cols-2 gap-2 text-center">
          <div className="p-3 bg-warning/10 border border-warning/20 rounded-lg">
            <p className="text-xs text-muted-foreground">Plan Requests</p>
            <p className="font-display font-bold text-warning text-lg">{stats.pendingPlanRequests}</p>
          </div>
          <div className="p-3 bg-accent/10 border border-accent/20 rounded-lg">
            <p className="text-xs text-muted-foreground">Withdrawals</p>
            <p className="font-display font-bold text-accent text-lg">{stats.pendingWithdrawals}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminStats;
