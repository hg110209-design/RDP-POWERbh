import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Save } from "lucide-react";

const GeneralSettings = () => {
  const { toast } = useToast();
  const [settings, setSettings] = useState({ site_name: "", support_email: "", partner_program_link: "", domain_link: "" });

  useEffect(() => {
    supabase.from("site_settings").select("key, value").in("key", ["site_name", "support_email", "partner_program_link", "domain_link"]).then(({ data }) => {
      if (data) {
        const s: any = {};
        data.forEach(d => s[d.key] = d.value || "");
        setSettings(s);
      }
    });
  }, []);

  const handleSave = async () => {
    for (const [key, value] of Object.entries(settings)) {
      await supabase.from("site_settings").update({ value }).eq("key", key);
    }
    toast({ title: "Saved" });
  };

  return (
    <div className="space-y-4">
      <h2 className="font-display text-xl font-bold">General Settings</h2>
      <div className="glass-card p-4 space-y-4">
        <div><label className="block text-sm font-medium mb-2">Site Name</label><input type="text" value={settings.site_name} onChange={(e) => setSettings({ ...settings, site_name: e.target.value })} className="input-field" /></div>
        <div><label className="block text-sm font-medium mb-2">Support Email</label><input type="email" value={settings.support_email} onChange={(e) => setSettings({ ...settings, support_email: e.target.value })} className="input-field" /></div>
        <div><label className="block text-sm font-medium mb-2">Partner Program Link</label><input type="text" value={settings.partner_program_link} onChange={(e) => setSettings({ ...settings, partner_program_link: e.target.value })} className="input-field" /></div>
        <div><label className="block text-sm font-medium mb-2">Domain Link</label><input type="text" value={settings.domain_link} onChange={(e) => setSettings({ ...settings, domain_link: e.target.value })} className="input-field" /></div>
        <button onClick={handleSave} className="btn-primary flex items-center gap-2"><Save className="h-4 w-4" /> Save</button>
      </div>
    </div>
  );
};

export default GeneralSettings;
