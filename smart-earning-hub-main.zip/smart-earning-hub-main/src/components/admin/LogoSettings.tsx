import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Save } from "lucide-react";
import ImageUpload from "./ImageUpload";

const LogoSettings = () => {
  const { toast } = useToast();
  const [logo, setLogo] = useState("");

  useEffect(() => {
    supabase.from("site_settings").select("value").eq("key", "sign_in_logo").single().then(({ data }) => {
      if (data) setLogo(data.value || "");
    });
  }, []);

  const handleSave = async () => {
    await supabase.from("site_settings").update({ value: logo }).eq("key", "sign_in_logo");
    toast({ title: "Saved", description: "Logo updated." });
  };

  return (
    <div className="space-y-4">
      <h2 className="font-display text-xl font-bold">Logo Settings</h2>
      <div className="glass-card p-4 space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2">Sign In Logo</label>
          <ImageUpload value={logo} onChange={setLogo} folder="logo" />
        </div>
        <button onClick={handleSave} className="btn-primary flex items-center gap-2"><Save className="h-4 w-4" /> Save</button>
      </div>
    </div>
  );
};

export default LogoSettings;
