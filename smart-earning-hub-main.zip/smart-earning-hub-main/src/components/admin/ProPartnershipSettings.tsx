import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, Edit2, Save, X } from "lucide-react";

const ProPartnershipSettings = () => {
  const { toast } = useToast();
  const [plans, setPlans] = useState<any[]>([]);
  const [newPlan, setNewPlan] = useState({ name: "", description: "", referral_target: "", reward_amount: "" });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editData, setEditData] = useState({ name: "", description: "", referral_target: "", reward_amount: "" });

  useEffect(() => { fetchPlans(); }, []);

  const fetchPlans = async () => {
    const { data } = await supabase.from("pro_partnership_plans").select("*").order("order_index");
    setPlans(data || []);
  };

  const handleAdd = async () => {
    if (!newPlan.name || !newPlan.referral_target || !newPlan.reward_amount) return;
    await supabase.from("pro_partnership_plans").insert({
      name: newPlan.name,
      description: newPlan.description,
      referral_target: parseInt(newPlan.referral_target),
      reward_amount: parseFloat(newPlan.reward_amount),
      order_index: plans.length + 1,
    });
    setNewPlan({ name: "", description: "", referral_target: "", reward_amount: "" });
    fetchPlans();
    toast({ title: "Added" });
  };

  const handleEdit = (item: any) => {
    setEditingId(item.id);
    setEditData({ 
      name: item.name, 
      description: item.description || "", 
      referral_target: String(item.referral_target), 
      reward_amount: String(item.reward_amount) 
    });
  };

  const handleSaveEdit = async () => {
    if (!editingId) return;
    await supabase.from("pro_partnership_plans").update({
      name: editData.name,
      description: editData.description,
      referral_target: parseInt(editData.referral_target),
      reward_amount: parseFloat(editData.reward_amount),
    }).eq("id", editingId);
    setEditingId(null);
    fetchPlans();
    toast({ title: "Updated" });
  };

  const handleDelete = async (id: string) => {
    await supabase.from("pro_partnership_plans").delete().eq("id", id);
    fetchPlans();
    toast({ title: "Deleted" });
  };

  return (
    <div className="space-y-4">
      <h2 className="font-display text-xl font-bold">Pro Partnership Plans</h2>
      <div className="glass-card p-4 space-y-3">
        <input type="text" placeholder="Plan Name (e.g. Bronze)" value={newPlan.name} onChange={(e) => setNewPlan({ ...newPlan, name: e.target.value })} className="input-field" />
        <textarea placeholder="Description" value={newPlan.description} onChange={(e) => setNewPlan({ ...newPlan, description: e.target.value })} className="input-field" />
        <div className="grid grid-cols-2 gap-3">
          <input type="number" placeholder="Referral Target" value={newPlan.referral_target} onChange={(e) => setNewPlan({ ...newPlan, referral_target: e.target.value })} className="input-field" />
          <input type="number" placeholder="Reward ($)" value={newPlan.reward_amount} onChange={(e) => setNewPlan({ ...newPlan, reward_amount: e.target.value })} className="input-field" />
        </div>
        <button onClick={handleAdd} className="btn-primary flex items-center gap-2"><Plus className="h-4 w-4" /> Add Plan</button>
      </div>
      
      {plans.map((p) => (
        <div key={p.id} className="glass-card p-4">
          {editingId === p.id ? (
            <div className="space-y-3">
              <input type="text" value={editData.name} onChange={(e) => setEditData({ ...editData, name: e.target.value })} className="input-field" />
              <textarea value={editData.description} onChange={(e) => setEditData({ ...editData, description: e.target.value })} className="input-field" />
              <div className="grid grid-cols-2 gap-3">
                <input type="number" value={editData.referral_target} onChange={(e) => setEditData({ ...editData, referral_target: e.target.value })} className="input-field" placeholder="Referral Target" />
                <input type="number" value={editData.reward_amount} onChange={(e) => setEditData({ ...editData, reward_amount: e.target.value })} className="input-field" placeholder="Reward ($)" />
              </div>
              <div className="flex gap-2">
                <button onClick={handleSaveEdit} className="btn-primary flex items-center gap-2"><Save className="h-4 w-4" /> Save</button>
                <button onClick={() => setEditingId(null)} className="btn-outline flex items-center gap-2"><X className="h-4 w-4" /> Cancel</button>
              </div>
            </div>
          ) : (
            <div className="flex justify-between items-center">
              <div>
                <p className="font-medium">{p.name}</p>
                <p className="text-sm text-muted-foreground">{p.referral_target} referrals → ${p.reward_amount}</p>
              </div>
              <div className="flex gap-2">
                <button onClick={() => handleEdit(p)} className="p-2 text-primary hover:bg-primary/10 rounded-lg"><Edit2 className="h-4 w-4" /></button>
                <button onClick={() => handleDelete(p.id)} className="p-2 text-destructive hover:bg-destructive/10 rounded-lg"><Trash2 className="h-4 w-4" /></button>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default ProPartnershipSettings;
