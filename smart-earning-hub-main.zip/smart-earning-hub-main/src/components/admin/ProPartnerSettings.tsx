import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Save } from "lucide-react";

interface Props { section: string; }

const ProPartnerSettings = ({ section }: Props) => {
  const { toast } = useToast();
  const [data, setData] = useState({ text: "", amount: "" });
  const key = section === "referral-settings" ? "referral" : "global";

  useEffect(() => {
    supabase.from("site_settings").select("key, value").in("key", [`${key}_earn_text`, `${key}_earn_amount`]).then(({ data: d }) => {
      if (d) {
        const text = d.find(x => x.key === `${key}_earn_text`)?.value || "";
        const amount = d.find(x => x.key === `${key}_earn_amount`)?.value || "";
        setData({ text, amount });
      }
    });
  }, [section]);

  const handleSave = async () => {
    await supabase.from("site_settings").update({ value: data.text }).eq("key", `${key}_earn_text`);
    await supabase.from("site_settings").update({ value: data.amount }).eq("key", `${key}_earn_amount`);
    toast({ title: "Saved" });
  };

  return (
    <div className="space-y-4">
      <h2 className="font-display text-xl font-bold">{section === "referral-settings" ? "Referral" : "Global"} Earn Settings</h2>
      <div className="glass-card p-4 space-y-4">
        <div><label className="block text-sm font-medium mb-2">Description Text</label><textarea value={data.text} onChange={(e) => setData({ ...data, text: e.target.value })} className="input-field min-h-[100px]" /></div>
        <div><label className="block text-sm font-medium mb-2">Amount (USD)</label><input type="number" value={data.amount} onChange={(e) => setData({ ...data, amount: e.target.value })} className="input-field" /></div>
        <button onClick={handleSave} className="btn-primary flex items-center gap-2"><Save className="h-4 w-4" /> Save</button>
      </div>
    </div>
  );
};

export default ProPartnerSettings;
