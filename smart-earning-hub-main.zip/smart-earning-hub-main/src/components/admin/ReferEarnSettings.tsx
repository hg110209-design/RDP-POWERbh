import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Save } from "lucide-react";

const ReferEarnSettings = () => {
  const { toast } = useToast();
  const [data, setData] = useState({ domain_link: "", referral_bonus: "", refer_earn_info: "" });

  useEffect(() => {
    supabase.from("site_settings").select("key, value").in("key", ["domain_link", "referral_bonus", "refer_earn_info"]).then(({ data: d }) => {
      if (d) {
        const s: any = {};
        d.forEach(x => s[x.key] = x.value || "");
        setData(s);
      }
    });
  }, []);

  const handleSave = async () => {
    for (const [key, value] of Object.entries(data)) {
      await supabase.from("site_settings").update({ value }).eq("key", key);
    }
    toast({ title: "Saved" });
  };

  return (
    <div className="space-y-4">
      <h2 className="font-display text-xl font-bold">Refer & Earn Settings</h2>
      <div className="glass-card p-4 space-y-4">
        <div><label className="block text-sm font-medium mb-2">Domain Link</label><input type="text" value={data.domain_link} onChange={(e) => setData({ ...data, domain_link: e.target.value })} placeholder="https://yourdomain.com" className="input-field" /></div>
        <div><label className="block text-sm font-medium mb-2">Referral Bonus (USD per referral)</label><input type="number" value={data.referral_bonus} onChange={(e) => setData({ ...data, referral_bonus: e.target.value })} className="input-field" /></div>
        <div><label className="block text-sm font-medium mb-2">Info Text</label><textarea value={data.refer_earn_info} onChange={(e) => setData({ ...data, refer_earn_info: e.target.value })} className="input-field min-h-[100px]" /></div>
        <button onClick={handleSave} className="btn-primary flex items-center gap-2"><Save className="h-4 w-4" /> Save</button>
      </div>
    </div>
  );
};

export default ReferEarnSettings;
