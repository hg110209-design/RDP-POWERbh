import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Coins, DollarSign, RefreshCw, Save } from "lucide-react";

const GlobalMiningSettings = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  
  const [coinsPerDay, setCoinsPerDay] = useState("1");
  const [hpPrice, setHpPrice] = useState("0");
  const [exchangeStatus, setExchangeStatus] = useState<'coming_soon' | 'price'>('coming_soon');

  useEffect(() => {
    const fetchSettings = async () => {
      const { data } = await supabase
        .from("site_settings")
        .select("key, value")
        .in("key", ["mining_coins_per_day", "mining_hp_price", "mining_exchange_status"]);

      if (data) {
        data.forEach(s => {
          if (s.key === "mining_coins_per_day") setCoinsPerDay(s.value || "1");
          if (s.key === "mining_hp_price") setHpPrice(s.value || "0");
          if (s.key === "mining_exchange_status") setExchangeStatus(s.value as 'coming_soon' | 'price' || 'coming_soon');
        });
      }
      setLoading(false);
    };

    fetchSettings();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      const updates = [
        { key: "mining_coins_per_day", value: coinsPerDay },
        { key: "mining_hp_price", value: hpPrice },
        { key: "mining_exchange_status", value: exchangeStatus }
      ];

      for (const update of updates) {
        const { error } = await supabase
          .from("site_settings")
          .upsert({ key: update.key, value: update.value }, { onConflict: 'key' });
        
        if (error) throw error;
      }

      toast({
        title: "Settings Saved",
        description: "Global mining settings have been updated.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save settings.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-slide-up">
      <div className="flex items-center gap-2 mb-4">
        <Coins className="h-6 w-6 text-primary" />
        <h2 className="font-display text-xl font-bold">Global Mining Settings</h2>
      </div>

      {/* Coins Per Day */}
      <div className="glass-card p-4">
        <label className="block text-sm font-medium text-foreground mb-2">
          HP Coins Per 24 Hours
        </label>
        <p className="text-xs text-muted-foreground mb-3">
          How many HP coins a user earns every 24 hours
        </p>
        <div className="relative">
          <Coins className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <input
            type="number"
            step="0.01"
            value={coinsPerDay}
            onChange={(e) => setCoinsPerDay(e.target.value)}
            className="input-field pl-10"
            placeholder="1"
          />
        </div>
      </div>

      {/* HP Price */}
      <div className="glass-card p-4">
        <label className="block text-sm font-medium text-foreground mb-2">
          HP Coin Price (USD)
        </label>
        <p className="text-xs text-muted-foreground mb-3">
          Exchange rate for 1 HP coin to USD
        </p>
        <div className="relative">
          <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <input
            type="number"
            step="0.0001"
            value={hpPrice}
            onChange={(e) => setHpPrice(e.target.value)}
            className="input-field pl-10"
            placeholder="0.01"
          />
        </div>
      </div>

      {/* Exchange Status */}
      <div className="glass-card p-4">
        <label className="block text-sm font-medium text-foreground mb-2">
          HP Exchange Status
        </label>
        <p className="text-xs text-muted-foreground mb-3">
          Enable or disable HP exchange for users
        </p>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setExchangeStatus('coming_soon')}
            className={`p-4 rounded-xl border-2 transition-all ${
              exchangeStatus === 'coming_soon'
                ? 'border-primary bg-primary/10'
                : 'border-border hover:border-primary/50'
            }`}
          >
            <RefreshCw className="h-6 w-6 mx-auto mb-2 text-muted-foreground" />
            <p className="font-medium text-sm">Coming Soon</p>
            <p className="text-xs text-muted-foreground">Exchange disabled</p>
          </button>
          
          <button
            onClick={() => setExchangeStatus('price')}
            className={`p-4 rounded-xl border-2 transition-all ${
              exchangeStatus === 'price'
                ? 'border-primary bg-primary/10'
                : 'border-border hover:border-primary/50'
            }`}
          >
            <DollarSign className="h-6 w-6 mx-auto mb-2 text-success" />
            <p className="font-medium text-sm">Price Active</p>
            <p className="text-xs text-muted-foreground">Exchange enabled</p>
          </button>
        </div>
      </div>

      {/* Save Button */}
      <button
        onClick={handleSave}
        disabled={saving}
        className="w-full btn-primary flex items-center justify-center gap-2 disabled:opacity-50"
      >
        <Save className={`h-5 w-5 ${saving ? 'animate-spin' : ''}`} />
        {saving ? "Saving..." : "Save Settings"}
      </button>
    </div>
  );
};

export default GlobalMiningSettings;