import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Save } from "lucide-react";
import ImageUpload from "./ImageUpload";

const ProPartnershipFooterSettings = () => {
  const { toast } = useToast();
  const [data, setData] = useState({ text: "", image: "" });

  useEffect(() => {
    const fetchSettings = async () => {
      const { data: settings } = await supabase
        .from("site_settings")
        .select("key, value")
        .in("key", ["pro_partnership_description", "pro_partnership_footer_image"]);

      if (settings) {
        const s: any = {};
        settings.forEach(x => {
          if (x.key === "pro_partnership_description") s.text = x.value || "";
          if (x.key === "pro_partnership_footer_image") s.image = x.value || "";
        });
        setData(s);
      }
    };
    fetchSettings();
  }, []);

  const handleSave = async () => {
    await supabase.from("site_settings").update({ value: data.text }).eq("key", "pro_partnership_description");
    await supabase.from("site_settings").update({ value: data.image }).eq("key", "pro_partnership_footer_image");
    toast({ title: "Saved" });
  };

  return (
    <div className="glass-card p-4 space-y-4">
      <h3 className="font-display font-bold text-lg">Pro Partnership Page Footer</h3>
      <p className="text-sm text-muted-foreground">This text and image will appear below all partnership plans, blending with the background.</p>
      
      <div>
        <label className="block text-sm font-medium mb-2">Description Text</label>
        <textarea
          value={data.text}
          onChange={(e) => setData({ ...data, text: e.target.value })}
          placeholder="Enter partnership description..."
          className="input-field min-h-[100px]"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Footer Image</label>
        <ImageUpload
          value={data.image}
          onChange={(url) => setData({ ...data, image: url })}
          folder="partnership"
        />
      </div>

      <button onClick={handleSave} className="btn-primary flex items-center gap-2">
        <Save className="h-4 w-4" /> Save
      </button>
    </div>
  );
};

export default ProPartnershipFooterSettings;
