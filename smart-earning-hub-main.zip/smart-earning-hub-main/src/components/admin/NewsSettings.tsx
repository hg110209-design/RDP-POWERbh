import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, Edit2, Save, X } from "lucide-react";
import ImageUpload from "./ImageUpload";

const NewsSettings = () => {
  const { toast } = useToast();
  const [news, setNews] = useState<any[]>([]);
  const [newPost, setNewPost] = useState({ title: "", content: "", image_url: "" });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editData, setEditData] = useState({ title: "", content: "", image_url: "" });

  useEffect(() => { fetchNews(); }, []);

  const fetchNews = async () => {
    const { data } = await supabase.from("news_events").select("*").order("created_at", { ascending: false });
    setNews(data || []);
  };

  const handleAdd = async () => {
    if (!newPost.title) return;
    await supabase.from("news_events").insert(newPost);
    setNewPost({ title: "", content: "", image_url: "" });
    fetchNews();
    toast({ title: "Added" });
  };

  const handleEdit = (item: any) => {
    setEditingId(item.id);
    setEditData({ title: item.title, content: item.content || "", image_url: item.image_url || "" });
  };

  const handleSaveEdit = async () => {
    if (!editingId) return;
    await supabase.from("news_events").update(editData).eq("id", editingId);
    setEditingId(null);
    fetchNews();
    toast({ title: "Updated" });
  };

  const handleDelete = async (id: string) => {
    await supabase.from("news_events").delete().eq("id", id);
    fetchNews();
    toast({ title: "Deleted" });
  };

  return (
    <div className="space-y-4">
      <h2 className="font-display text-xl font-bold">News & Events</h2>
      <div className="glass-card p-4 space-y-3">
        <input type="text" placeholder="Title" value={newPost.title} onChange={(e) => setNewPost({ ...newPost, title: e.target.value })} className="input-field" />
        <textarea placeholder="Content" value={newPost.content} onChange={(e) => setNewPost({ ...newPost, content: e.target.value })} className="input-field min-h-[100px]" />
        <label className="block text-sm font-medium mb-2">Image</label>
        <ImageUpload value={newPost.image_url} onChange={(url) => setNewPost({ ...newPost, image_url: url })} folder="news" />
        <button onClick={handleAdd} className="btn-primary flex items-center gap-2"><Plus className="h-4 w-4" /> Add Post</button>
      </div>
      
      {news.map((n) => (
        <div key={n.id} className="glass-card p-4">
          {editingId === n.id ? (
            <div className="space-y-3">
              <input type="text" value={editData.title} onChange={(e) => setEditData({ ...editData, title: e.target.value })} className="input-field" />
              <textarea value={editData.content} onChange={(e) => setEditData({ ...editData, content: e.target.value })} className="input-field min-h-[80px]" />
              <ImageUpload value={editData.image_url} onChange={(url) => setEditData({ ...editData, image_url: url })} folder="news" />
              <div className="flex gap-2">
                <button onClick={handleSaveEdit} className="btn-primary flex items-center gap-2"><Save className="h-4 w-4" /> Save</button>
                <button onClick={() => setEditingId(null)} className="btn-outline flex items-center gap-2"><X className="h-4 w-4" /> Cancel</button>
              </div>
            </div>
          ) : (
            <div className="flex justify-between items-start">
              <div className="flex gap-3">
                {n.image_url && <img src={n.image_url} alt="" className="h-12 w-12 rounded-lg object-cover" />}
                <div>
                  <p className="font-medium">{n.title}</p>
                  <p className="text-sm text-muted-foreground truncate max-w-[200px]">{n.content}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => handleEdit(n)} className="p-2 text-primary hover:bg-primary/10 rounded-lg"><Edit2 className="h-4 w-4" /></button>
                <button onClick={() => handleDelete(n.id)} className="p-2 text-destructive hover:bg-destructive/10 rounded-lg"><Trash2 className="h-4 w-4" /></button>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default NewsSettings;
