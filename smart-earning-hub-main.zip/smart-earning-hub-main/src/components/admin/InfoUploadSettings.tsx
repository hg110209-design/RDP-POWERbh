import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Save, Plus, Trash2, Edit2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ImageUpload from "./ImageUpload";

interface InfoItem {
  id: string;
  type: string;
  content_type: string;
  content: string;
  order_index: number;
}

const InfoUploadSettings = () => {
  const { toast } = useToast();
  const [referralText, setReferralText] = useState("");
  const [globalText, setGlobalText] = useState("");
  const [referralImages, setReferralImages] = useState<InfoItem[]>([]);
  const [globalImages, setGlobalImages] = useState<InfoItem[]>([]);
  const [newReferralImage, setNewReferralImage] = useState("");
  const [newGlobalImage, setNewGlobalImage] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState("");

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const { data } = await supabase
      .from("pro_partner_info")
      .select("*")
      .order("order_index");

    if (data) {
      const refText = data.find(d => d.type === "referral" && d.content_type === "text");
      const globText = data.find(d => d.type === "global" && d.content_type === "text");
      
      setReferralText(refText?.content || "");
      setGlobalText(globText?.content || "");
      setReferralImages(data.filter(d => d.type === "referral" && d.content_type === "image"));
      setGlobalImages(data.filter(d => d.type === "global" && d.content_type === "image"));
    }
  };

  const handleSaveText = async (type: "referral" | "global") => {
    const content = type === "referral" ? referralText : globalText;
    const existing = type === "referral" 
      ? referralImages.find(i => false) // Check for existing text
      : globalImages.find(i => false);

    // Check if text exists
    const { data: existingText } = await supabase
      .from("pro_partner_info")
      .select("id")
      .eq("type", type)
      .eq("content_type", "text")
      .single();

    if (existingText) {
      await supabase
        .from("pro_partner_info")
        .update({ content })
        .eq("id", existingText.id);
    } else {
      await supabase
        .from("pro_partner_info")
        .insert({ type, content_type: "text", content });
    }

    toast({ title: "Text Saved" });
  };

  const handleAddImage = async (type: "referral" | "global") => {
    const imageUrl = type === "referral" ? newReferralImage : newGlobalImage;
    if (!imageUrl) return;

    const images = type === "referral" ? referralImages : globalImages;
    await supabase
      .from("pro_partner_info")
      .insert({ 
        type, 
        content_type: "image", 
        content: imageUrl,
        order_index: images.length 
      });

    type === "referral" ? setNewReferralImage("") : setNewGlobalImage("");
    toast({ title: "Image Added" });
    fetchData();
  };

  const handleDelete = async (id: string) => {
    await supabase.from("pro_partner_info").delete().eq("id", id);
    toast({ title: "Deleted" });
    fetchData();
  };

  const handleEdit = (item: InfoItem) => {
    setEditingId(item.id);
    setEditContent(item.content);
  };

  const handleSaveEdit = async () => {
    if (!editingId) return;
    await supabase
      .from("pro_partner_info")
      .update({ content: editContent })
      .eq("id", editingId);
    setEditingId(null);
    setEditContent("");
    toast({ title: "Updated" });
    fetchData();
  };

  const ImageSection = ({ type, images, newImage, setNewImage }: {
    type: "referral" | "global";
    images: InfoItem[];
    newImage: string;
    setNewImage: (val: string) => void;
  }) => (
    <div className="space-y-4">
      <div className="glass-card p-4 space-y-3">
        <label className="block text-sm font-medium">Add New Image</label>
        <ImageUpload
          value={newImage}
          onChange={setNewImage}
          folder="pro-partner-info"
        />
        <button
          onClick={() => handleAddImage(type)}
          disabled={!newImage}
          className="btn-primary flex items-center gap-2 disabled:opacity-50"
        >
          <Plus className="h-4 w-4" /> Add Image
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {images.map(img => (
          <div key={img.id} className="glass-card p-2 relative group">
            {editingId === img.id ? (
              <div className="space-y-2">
                <ImageUpload
                  value={editContent}
                  onChange={setEditContent}
                  folder="pro-partner-info"
                />
                <button onClick={handleSaveEdit} className="btn-primary w-full text-sm">
                  Save
                </button>
              </div>
            ) : (
              <>
                <img src={img.content} alt="" className="w-full h-24 object-cover rounded" />
                <div className="absolute top-1 right-1 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => handleEdit(img)}
                    className="p-1 bg-blue-500/80 rounded text-white"
                  >
                    <Edit2 className="h-3 w-3" />
                  </button>
                  <button
                    onClick={() => handleDelete(img.id)}
                    className="p-1 bg-red-500/80 rounded text-white"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      <h2 className="font-display text-xl font-bold">Info Upload</h2>
      
      <Tabs defaultValue="referral" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="referral">Referral Earn</TabsTrigger>
          <TabsTrigger value="global">Global Earn</TabsTrigger>
        </TabsList>
        
        <TabsContent value="referral" className="space-y-4 mt-4">
          <div className="glass-card p-4 space-y-3">
            <label className="block text-sm font-medium">Description Text</label>
            <textarea
              value={referralText}
              onChange={(e) => setReferralText(e.target.value)}
              className="input-field min-h-[100px]"
              placeholder="Enter description text for Referral Earn section..."
            />
            <button
              onClick={() => handleSaveText("referral")}
              className="btn-primary flex items-center gap-2"
            >
              <Save className="h-4 w-4" /> Save Text
            </button>
          </div>
          
          <ImageSection 
            type="referral" 
            images={referralImages}
            newImage={newReferralImage}
            setNewImage={setNewReferralImage}
          />
        </TabsContent>
        
        <TabsContent value="global" className="space-y-4 mt-4">
          <div className="glass-card p-4 space-y-3">
            <label className="block text-sm font-medium">Description Text</label>
            <textarea
              value={globalText}
              onChange={(e) => setGlobalText(e.target.value)}
              className="input-field min-h-[100px]"
              placeholder="Enter description text for Global Earn section..."
            />
            <button
              onClick={() => handleSaveText("global")}
              className="btn-primary flex items-center gap-2"
            >
              <Save className="h-4 w-4" /> Save Text
            </button>
          </div>
          
          <ImageSection 
            type="global" 
            images={globalImages}
            newImage={newGlobalImage}
            setNewImage={setNewGlobalImage}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default InfoUploadSettings;
