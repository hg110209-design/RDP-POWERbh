import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { User, Crown, Check } from "lucide-react";

interface UserWithPlans {
  id: string;
  user_id: string;
  name: string;
  email: string;
  profile_image: string | null;
  activePlans: {
    plan_id: string;
    plan_name: string;
    activated_at: string;
  }[];
  referral_earn_active: boolean;
  global_earn_active: boolean;
}

interface Plan {
  id: string;
  name: string;
}

const ActiveProPartnershipUsers = () => {
  const [users, setUsers] = useState<UserWithPlans[]>([]);
  const [plans, setPlans] = useState<Plan[]>([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    // Fetch all plans
    const { data: plansData } = await supabase
      .from("pro_partnership_plans")
      .select("id, name")
      .eq("is_active", true)
      .order("order_index");

    if (plansData) setPlans(plansData);

    // Fetch users with active plans
    const { data: activePlansData } = await supabase
      .from("user_active_plans")
      .select("*")
      .eq("is_active", true);

    // Fetch profiles with referral or global earn active
    const { data: profilesData } = await supabase
      .from("profiles")
      .select("*")
      .or("referral_earn_active.eq.true,global_earn_active.eq.true");

    if (profilesData) {
      const usersWithPlans: UserWithPlans[] = profilesData.map(profile => {
        const userActivePlans = activePlansData?.filter(ap => ap.user_id === profile.user_id) || [];
        
        return {
          id: profile.id,
          user_id: profile.user_id,
          name: profile.name,
          email: profile.email,
          profile_image: profile.profile_image,
          referral_earn_active: profile.referral_earn_active,
          global_earn_active: profile.global_earn_active,
          activePlans: userActivePlans.map(ap => {
            const plan = plansData?.find(p => p.id === ap.plan_id);
            return {
              plan_id: ap.plan_id,
              plan_name: plan?.name || "Unknown",
              activated_at: ap.activated_at
            };
          })
        };
      });

      setUsers(usersWithPlans);
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="font-display text-xl font-bold flex items-center gap-2">
        <Crown className="h-5 w-5 text-yellow-500" />
        Active Pro Partnership Users
      </h2>

      {users.length === 0 ? (
        <div className="glass-card p-8 text-center">
          <p className="text-muted-foreground">No users with active Pro Partnership plans</p>
        </div>
      ) : (
        <div className="space-y-3">
          {users.map(user => (
            <div key={user.id} className="glass-card p-4">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center overflow-hidden shrink-0">
                  {user.profile_image ? (
                    <img src={user.profile_image} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <User className="h-6 w-6 text-primary" />
                  )}
                </div>
                
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold truncate">{user.name}</h3>
                  <p className="text-sm text-muted-foreground truncate">{user.email}</p>
                  
                  <div className="flex flex-wrap gap-2 mt-3">
                    {user.referral_earn_active && (
                      <span className="px-2 py-1 bg-green-500/20 text-green-500 text-xs rounded-full flex items-center gap-1">
                        <Check className="h-3 w-3" /> Referral Earn
                      </span>
                    )}
                    {user.global_earn_active && (
                      <span className="px-2 py-1 bg-blue-500/20 text-blue-500 text-xs rounded-full flex items-center gap-1">
                        <Check className="h-3 w-3" /> Global Earn
                      </span>
                    )}
                  </div>

                  {user.activePlans.length > 0 && (
                    <div className="mt-3">
                      <p className="text-xs text-muted-foreground mb-1">Active Partnership Plans:</p>
                      <div className="flex flex-wrap gap-1">
                        {user.activePlans.map((plan, idx) => (
                          <span key={idx} className="px-2 py-0.5 bg-yellow-500/20 text-yellow-600 text-xs rounded">
                            {plan.plan_name}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="text-right shrink-0">
                  <div className="text-sm font-medium text-primary">
                    {user.activePlans.length + (user.referral_earn_active ? 1 : 0) + (user.global_earn_active ? 1 : 0)} Active
                  </div>
                  <div className="text-xs text-muted-foreground">
                    / {plans.length + 2} Total
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ActiveProPartnershipUsers;
