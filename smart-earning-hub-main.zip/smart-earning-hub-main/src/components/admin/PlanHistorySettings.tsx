import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Check, X, User } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface PlanRequest {
  id: string;
  user_id: string;
  plan_type: string;
  transaction_id: string;
  payment_method: string;
  amount: number;
  status: string;
  created_at: string;
  profiles?: {
    name: string;
    email: string;
    profile_image: string | null;
  };
}

const PlanHistorySettings = () => {
  const { toast } = useToast();
  const [referralRequests, setReferralRequests] = useState<PlanRequest[]>([]);
  const [globalRequests, setGlobalRequests] = useState<PlanRequest[]>([]);

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = async () => {
    const { data } = await supabase
      .from("plan_activation_requests")
      .select("*")
      .order("created_at", { ascending: false });

    if (data) {
      // Fetch user profiles for each request
      const requestsWithProfiles = await Promise.all(
        data.map(async (req) => {
          const { data: profile } = await supabase
            .from("profiles")
            .select("name, email, profile_image")
            .eq("user_id", req.user_id)
            .single();
          return { ...req, profiles: profile };
        })
      );

      setReferralRequests(requestsWithProfiles.filter(r => r.plan_type === "referral"));
      setGlobalRequests(requestsWithProfiles.filter(r => r.plan_type === "global"));
    }
  };

  const handleAction = async (id: string, status: "approved" | "rejected", planType: string, userId: string) => {
    await supabase
      .from("plan_activation_requests")
      .update({ status, updated_at: new Date().toISOString() })
      .eq("id", id);

    if (status === "approved") {
      const field = planType === "referral" ? "referral_earn_active" : "global_earn_active";
      await supabase
        .from("profiles")
        .update({ [field]: true })
        .eq("user_id", userId);
    }

    toast({ title: status === "approved" ? "Plan Activated" : "Request Rejected" });
    fetchRequests();
  };

  const RequestCard = ({ request }: { request: PlanRequest }) => (
    <div className="glass-card p-4 flex items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center overflow-hidden">
          {request.profiles?.profile_image ? (
            <img src={request.profiles.profile_image} alt="" className="w-full h-full object-cover" />
          ) : (
            <User className="h-5 w-5 text-primary" />
          )}
        </div>
        <div>
          <p className="font-medium">{request.profiles?.name || "Unknown"}</p>
          <p className="text-xs text-muted-foreground">{request.profiles?.email}</p>
        </div>
      </div>
      <div className="text-right text-sm">
        <p>৳{request.amount}</p>
        <p className="text-xs text-muted-foreground">{request.payment_method}</p>
        <p className="text-xs text-muted-foreground">TxID: {request.transaction_id}</p>
      </div>
      <div className="flex items-center gap-2">
        {request.status === "pending" ? (
          <>
            <button
              onClick={() => handleAction(request.id, "approved", request.plan_type, request.user_id)}
              className="p-2 bg-green-500/20 hover:bg-green-500/30 rounded-lg text-green-500"
            >
              <Check className="h-4 w-4" />
            </button>
            <button
              onClick={() => handleAction(request.id, "rejected", request.plan_type, request.user_id)}
              className="p-2 bg-red-500/20 hover:bg-red-500/30 rounded-lg text-red-500"
            >
              <X className="h-4 w-4" />
            </button>
          </>
        ) : (
          <span className={`px-2 py-1 rounded text-xs ${
            request.status === "approved" ? "bg-green-500/20 text-green-500" : "bg-red-500/20 text-red-500"
          }`}>
            {request.status}
          </span>
        )}
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      <h2 className="font-display text-xl font-bold">Plan History</h2>
      
      <Tabs defaultValue="referral" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="referral">Referral Earn</TabsTrigger>
          <TabsTrigger value="global">Global Earn</TabsTrigger>
        </TabsList>
        
        <TabsContent value="referral" className="space-y-3 mt-4">
          {referralRequests.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No referral earn requests</p>
          ) : (
            referralRequests.map(req => <RequestCard key={req.id} request={req} />)
          )}
        </TabsContent>
        
        <TabsContent value="global" className="space-y-3 mt-4">
          {globalRequests.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No global earn requests</p>
          ) : (
            globalRequests.map(req => <RequestCard key={req.id} request={req} />)
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PlanHistorySettings;
