import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, Check, X, Edit2, Save } from "lucide-react";
import ImageUpload from "./ImageUpload";

interface Props { section: string; }

const WithdrawalSettings = ({ section }: Props) => {
  const { toast } = useToast();
  const [methods, setMethods] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [newMethod, setNewMethod] = useState({ name: "", min_amount: "10", max_amount: "1000", image_url: "" });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editData, setEditData] = useState({ name: "", min_amount: "", max_amount: "", image_url: "" });

  useEffect(() => { fetchData(); }, [section]);

  const fetchData = async () => {
    if (section === "withdrawal-methods") {
      const { data } = await supabase.from("withdrawal_methods").select("*");
      setMethods(data || []);
    } else {
      let query = supabase.from("withdrawals").select("*, profiles(username, refer_code)").order("created_at", { ascending: false });
      if (section === "withdrawal-pending") query = query.eq("status", "pending");
      if (section === "withdrawal-approved") query = query.eq("status", "approved");
      if (section === "withdrawal-rejected") query = query.eq("status", "rejected");
      const { data } = await query.limit(50);
      setWithdrawals(data || []);
    }
  };

  const handleAddMethod = async () => {
    if (!newMethod.name) return;
    await supabase.from("withdrawal_methods").insert({ 
      name: newMethod.name, 
      min_amount: parseFloat(newMethod.min_amount), 
      max_amount: parseFloat(newMethod.max_amount),
      image_url: newMethod.image_url 
    });
    setNewMethod({ name: "", min_amount: "10", max_amount: "1000", image_url: "" });
    fetchData();
    toast({ title: "Added" });
  };

  const handleEdit = (item: any) => {
    setEditingId(item.id);
    setEditData({ 
      name: item.name, 
      min_amount: String(item.min_amount), 
      max_amount: String(item.max_amount),
      image_url: item.image_url || "" 
    });
  };

  const handleSaveEdit = async () => {
    if (!editingId) return;
    await supabase.from("withdrawal_methods").update({
      name: editData.name,
      min_amount: parseFloat(editData.min_amount),
      max_amount: parseFloat(editData.max_amount),
      image_url: editData.image_url
    }).eq("id", editingId);
    setEditingId(null);
    fetchData();
    toast({ title: "Updated" });
  };

  const handleWithdrawal = async (id: string, approve: boolean) => {
    await supabase.from("withdrawals").update({ status: approve ? "approved" : "rejected" }).eq("id", id);
    fetchData();
    toast({ title: approve ? "Approved" : "Rejected" });
  };

  if (section === "withdrawal-methods") {
    return (
      <div className="space-y-4">
        <h2 className="font-display text-xl font-bold">Withdrawal Methods</h2>
        <div className="glass-card p-4 space-y-3">
          <input type="text" placeholder="Method Name" value={newMethod.name} onChange={(e) => setNewMethod({ ...newMethod, name: e.target.value })} className="input-field" />
          <div className="grid grid-cols-2 gap-3">
            <input type="number" placeholder="Min Amount" value={newMethod.min_amount} onChange={(e) => setNewMethod({ ...newMethod, min_amount: e.target.value })} className="input-field" />
            <input type="number" placeholder="Max Amount" value={newMethod.max_amount} onChange={(e) => setNewMethod({ ...newMethod, max_amount: e.target.value })} className="input-field" />
          </div>
          <label className="block text-sm font-medium">Image</label>
          <ImageUpload value={newMethod.image_url} onChange={(url) => setNewMethod({ ...newMethod, image_url: url })} folder="withdrawal" />
          <button onClick={handleAddMethod} className="btn-primary flex items-center gap-2"><Plus className="h-4 w-4" /> Add</button>
        </div>
        
        {methods.map((m) => (
          <div key={m.id} className="glass-card p-4">
            {editingId === m.id ? (
              <div className="space-y-3">
                <input type="text" value={editData.name} onChange={(e) => setEditData({ ...editData, name: e.target.value })} className="input-field" />
                <div className="grid grid-cols-2 gap-3">
                  <input type="number" value={editData.min_amount} onChange={(e) => setEditData({ ...editData, min_amount: e.target.value })} className="input-field" />
                  <input type="number" value={editData.max_amount} onChange={(e) => setEditData({ ...editData, max_amount: e.target.value })} className="input-field" />
                </div>
                <ImageUpload value={editData.image_url} onChange={(url) => setEditData({ ...editData, image_url: url })} folder="withdrawal" />
                <div className="flex gap-2">
                  <button onClick={handleSaveEdit} className="btn-primary flex items-center gap-2"><Save className="h-4 w-4" /> Save</button>
                  <button onClick={() => setEditingId(null)} className="btn-outline flex items-center gap-2"><X className="h-4 w-4" /> Cancel</button>
                </div>
              </div>
            ) : (
              <div className="flex justify-between items-center">
                <div className="flex gap-3 items-center">
                  {m.image_url && <img src={m.image_url} alt="" className="h-10 w-10 rounded-lg object-cover" />}
                  <div>
                    <p className="font-medium">{m.name}</p>
                    <p className="text-sm text-muted-foreground">${m.min_amount} - ${m.max_amount}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => handleEdit(m)} className="p-2 text-primary hover:bg-primary/10 rounded-lg"><Edit2 className="h-4 w-4" /></button>
                  <button onClick={async () => { await supabase.from("withdrawal_methods").delete().eq("id", m.id); fetchData(); }} className="p-2 text-destructive hover:bg-destructive/10 rounded-lg"><Trash2 className="h-4 w-4" /></button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    );
  }

  const getTitle = () => {
    switch (section) {
      case "withdrawal-pending": return "Payment Pending";
      case "withdrawal-approved": return "Payment Approved";
      case "withdrawal-rejected": return "Payment Rejected";
      case "withdrawal-history": return "All History";
      default: return "Withdrawals";
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved": return <span className="px-2 py-0.5 bg-success/20 text-success text-xs rounded-full">Approved</span>;
      case "rejected": return <span className="px-2 py-0.5 bg-destructive/20 text-destructive text-xs rounded-full">Rejected</span>;
      default: return <span className="px-2 py-0.5 bg-warning/20 text-warning text-xs rounded-full">Pending</span>;
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="font-display text-xl font-bold">{getTitle()}</h2>
      {withdrawals.length === 0 ? (
        <div className="glass-card p-8 text-center text-muted-foreground">No withdrawals found</div>
      ) : (
        withdrawals.map((w) => (
          <div key={w.id} className="glass-card p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="font-display text-xl font-bold text-primary">${w.amount}</span>
                {getStatusBadge(w.status)}
              </div>
              <span className="text-xs text-muted-foreground">
                {new Date(w.created_at).toLocaleDateString()}
              </span>
            </div>
            
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <p className="text-muted-foreground">Username</p>
                <p className="font-medium">{w.profiles?.username || "N/A"}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Refer Code</p>
                <p className="font-medium">{w.profiles?.refer_code || "N/A"}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Payment Method</p>
                <p className="font-medium">{w.payment_method}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Account Name</p>
                <p className="font-medium">{w.account_name}</p>
              </div>
              <div className="col-span-2">
                <p className="text-muted-foreground">Account Number</p>
                <p className="font-medium font-mono">{w.account_id}</p>
              </div>
            </div>
            
            {section === "withdrawal-pending" && (
              <div className="flex gap-2 pt-2 border-t border-border">
                <button 
                  onClick={() => handleWithdrawal(w.id, true)} 
                  className="flex-1 py-2 bg-success/20 text-success rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-success/30"
                >
                  <Check className="h-4 w-4" /> Accept
                </button>
                <button 
                  onClick={() => handleWithdrawal(w.id, false)} 
                  className="flex-1 py-2 bg-destructive/20 text-destructive rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-destructive/30"
                >
                  <X className="h-4 w-4" /> Reject
                </button>
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );
};

export default WithdrawalSettings;
