import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Search, Check, X, Save } from "lucide-react";

interface Props {
  section: string;
}

const UserSettings = ({ section }: Props) => {
  const { toast } = useToast();
  const [searchCode, setSearchCode] = useState("");
  const [users, setUsers] = useState<any[]>([]);
  const [activationAmount, setActivationAmount] = useState("10");
  const [pendingRequests, setPendingRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchData();
  }, [section]);

  const fetchData = async () => {
    if (section === "activation-setting") {
      const { data } = await supabase.from("site_settings").select("value").eq("key", "activation_amount").single();
      if (data) setActivationAmount(data.value || "10");
    } else if (section === "account-pending") {
      const { data } = await supabase.from("payment_requests").select("*, profiles(username, email)").eq("type", "account_activation").eq("status", "pending");
      setPendingRequests(data || []);
    } else {
      let query = supabase.from("profiles").select("*");
      if (section === "active-account") query = query.eq("status", "active");
      if (section === "active-referral") query = query.eq("referral_earn_active", true);
      if (section === "active-global") query = query.eq("global_earn_active", true);
      const { data } = await query.limit(50);
      setUsers(data || []);
    }
  };

  const handleSaveAmount = async () => {
    setLoading(true);
    await supabase.from("site_settings").update({ value: activationAmount }).eq("key", "activation_amount");
    toast({ title: "Saved", description: "Activation amount updated." });
    setLoading(false);
  };

  const handleRequest = async (id: string, userId: string, approve: boolean) => {
    await supabase.from("payment_requests").update({ status: approve ? "approved" : "rejected" }).eq("id", id);
    if (approve) {
      await supabase.from("profiles").update({ status: "active" }).eq("user_id", userId);
    }
    toast({ title: approve ? "Approved" : "Rejected", description: `Request ${approve ? "approved" : "rejected"}.` });
    fetchData();
  };

  if (section === "activation-setting") {
    return (
      <div className="space-y-4">
        <h2 className="font-display text-xl font-bold">Activation Settings</h2>
        <div className="glass-card p-4">
          <label className="block text-sm font-medium mb-2">Activation Amount (USD)</label>
          <input type="number" value={activationAmount} onChange={(e) => setActivationAmount(e.target.value)} className="input-field mb-4" />
          <button onClick={handleSaveAmount} disabled={loading} className="btn-primary flex items-center gap-2">
            <Save className="h-4 w-4" /> Save
          </button>
        </div>
      </div>
    );
  }

  if (section === "account-pending") {
    return (
      <div className="space-y-4">
        <h2 className="font-display text-xl font-bold">Payment Pending</h2>
        {pendingRequests.length === 0 ? (
          <div className="glass-card p-8 text-center text-muted-foreground">No pending requests</div>
        ) : (
          pendingRequests.map((req) => (
            <div key={req.id} className="glass-card p-4 flex items-center justify-between">
              <div>
                <p className="font-medium">{req.profiles?.username || "Unknown"}</p>
                <p className="text-sm text-muted-foreground">{req.profiles?.email}</p>
                <p className="text-xs text-muted-foreground">TxID: {req.transaction_id}</p>
              </div>
              <div className="flex gap-2">
                <button onClick={() => handleRequest(req.id, req.user_id, true)} className="p-2 bg-success/20 text-success rounded-lg"><Check className="h-5 w-5" /></button>
                <button onClick={() => handleRequest(req.id, req.user_id, false)} className="p-2 bg-destructive/20 text-destructive rounded-lg"><X className="h-5 w-5" /></button>
              </div>
            </div>
          ))
        )}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="font-display text-xl font-bold">
        {section === "active-account" && "Active Accounts"}
        {section === "active-referral" && "Referral Earn Users"}
        {section === "active-global" && "Global Earn Users"}
        {section === "active-partnership" && "Pro Partnership Users"}
      </h2>
      
      <div className="flex gap-2">
        <input type="text" value={searchCode} onChange={(e) => setSearchCode(e.target.value)} placeholder="Search by ID" className="input-field flex-1" />
        <button className="btn-primary px-4"><Search className="h-5 w-5" /></button>
      </div>

      <div className="space-y-2">
        {users.filter(u => !searchCode || u.refer_code?.includes(searchCode)).map((user) => (
          <div key={user.id} className="glass-card p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="font-medium">{user.username}</p>
                <p className="text-sm text-muted-foreground">ID: {user.refer_code} | {user.email}</p>
              </div>
              <span className="px-2 py-1 rounded-full bg-success/20 text-success text-xs">Active</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default UserSettings;
