import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Save } from "lucide-react";
import ImageUpload from "./ImageUpload";

const WithdrawalFooterSettings = () => {
  const { toast } = useToast();
  const [data, setData] = useState({ text: "", image: "" });

  useEffect(() => {
    const fetchSettings = async () => {
      const { data: settings } = await supabase
        .from("site_settings")
        .select("key, value")
        .in("key", ["withdrawal_footer_text", "withdrawal_footer_image"]);

      if (settings) {
        const s: any = {};
        settings.forEach(x => {
          if (x.key === "withdrawal_footer_text") s.text = x.value || "";
          if (x.key === "withdrawal_footer_image") s.image = x.value || "";
        });
        setData(s);
      }
    };
    fetchSettings();
  }, []);

  const handleSave = async () => {
    await supabase.from("site_settings").update({ value: data.text }).eq("key", "withdrawal_footer_text");
    await supabase.from("site_settings").update({ value: data.image }).eq("key", "withdrawal_footer_image");
    toast({ title: "Saved" });
  };

  return (
    <div className="glass-card p-4 space-y-4">
      <h3 className="font-display font-bold text-lg">Withdrawal Page Footer</h3>
      <p className="text-sm text-muted-foreground">This text and image will appear at the bottom of the Withdrawal page, blending with the background.</p>
      
      <div>
        <label className="block text-sm font-medium mb-2">Footer Text</label>
        <textarea
          value={data.text}
          onChange={(e) => setData({ ...data, text: e.target.value })}
          placeholder="Enter footer text..."
          className="input-field min-h-[100px]"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Footer Image</label>
        <ImageUpload
          value={data.image}
          onChange={(url) => setData({ ...data, image: url })}
          folder="withdrawal"
        />
      </div>

      <button onClick={handleSave} className="btn-primary flex items-center gap-2">
        <Save className="h-4 w-4" /> Save
      </button>
    </div>
  );
};

export default WithdrawalFooterSettings;
