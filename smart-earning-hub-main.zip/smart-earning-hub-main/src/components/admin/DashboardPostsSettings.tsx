import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, Edit2, Save, X } from "lucide-react";
import ImageUpload from "./ImageUpload";

interface DashboardPost {
  id: string;
  title: string;
  content: string | null;
  image_url: string | null;
  is_active: boolean;
  created_at: string;
}

const DashboardPostsSettings = () => {
  const { toast } = useToast();
  const [posts, setPosts] = useState<DashboardPost[]>([]);
  const [newPost, setNewPost] = useState({ title: "", content: "", image_url: "" });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editData, setEditData] = useState({ title: "", content: "", image_url: "" });

  useEffect(() => { fetchPosts(); }, []);

  const fetchPosts = async () => {
    const { data } = await supabase
      .from("dashboard_posts")
      .select("*")
      .order("created_at", { ascending: false });
    setPosts((data as DashboardPost[]) || []);
  };

  const handleAdd = async () => {
    if (!newPost.title) return;
    await supabase.from("dashboard_posts").insert(newPost);
    setNewPost({ title: "", content: "", image_url: "" });
    fetchPosts();
    toast({ title: "Post Added" });
  };

  const handleEdit = (item: DashboardPost) => {
    setEditingId(item.id);
    setEditData({ 
      title: item.title, 
      content: item.content || "", 
      image_url: item.image_url || "" 
    });
  };

  const handleSaveEdit = async () => {
    if (!editingId) return;
    await supabase.from("dashboard_posts").update(editData).eq("id", editingId);
    setEditingId(null);
    fetchPosts();
    toast({ title: "Updated" });
  };

  const handleDelete = async (id: string) => {
    await supabase.from("dashboard_posts").delete().eq("id", id);
    fetchPosts();
    toast({ title: "Deleted" });
  };

  return (
    <div className="space-y-4">
      <h2 className="font-display text-xl font-bold">Dashboard Big Update Posts</h2>
      <p className="text-sm text-muted-foreground">These posts will appear in the "Big Update" section at the bottom of the user Dashboard.</p>
      
      <div className="glass-card p-4 space-y-3">
        <input 
          type="text" 
          placeholder="Title" 
          value={newPost.title} 
          onChange={(e) => setNewPost({ ...newPost, title: e.target.value })} 
          className="input-field" 
        />
        <textarea 
          placeholder="Content" 
          value={newPost.content} 
          onChange={(e) => setNewPost({ ...newPost, content: e.target.value })} 
          className="input-field min-h-[100px]" 
        />
        <label className="block text-sm font-medium mb-2">Image</label>
        <ImageUpload 
          value={newPost.image_url} 
          onChange={(url) => setNewPost({ ...newPost, image_url: url })} 
          folder="dashboard" 
        />
        <button onClick={handleAdd} className="btn-primary flex items-center gap-2">
          <Plus className="h-4 w-4" /> Add Post
        </button>
      </div>
      
      {posts.map((post) => (
        <div key={post.id} className="glass-card p-4">
          {editingId === post.id ? (
            <div className="space-y-3">
              <input 
                type="text" 
                value={editData.title} 
                onChange={(e) => setEditData({ ...editData, title: e.target.value })} 
                className="input-field" 
              />
              <textarea 
                value={editData.content} 
                onChange={(e) => setEditData({ ...editData, content: e.target.value })} 
                className="input-field min-h-[80px]" 
              />
              <ImageUpload 
                value={editData.image_url} 
                onChange={(url) => setEditData({ ...editData, image_url: url })} 
                folder="dashboard" 
              />
              <div className="flex gap-2">
                <button onClick={handleSaveEdit} className="btn-primary flex items-center gap-2">
                  <Save className="h-4 w-4" /> Save
                </button>
                <button onClick={() => setEditingId(null)} className="btn-outline flex items-center gap-2">
                  <X className="h-4 w-4" /> Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="flex justify-between items-start">
              <div className="flex gap-3">
                {post.image_url && (
                  <img src={post.image_url} alt="" className="h-12 w-12 rounded-lg object-cover" />
                )}
                <div>
                  <p className="font-medium">{post.title}</p>
                  <p className="text-sm text-muted-foreground truncate max-w-[200px]">{post.content}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => handleEdit(post)} 
                  className="p-2 text-primary hover:bg-primary/10 rounded-lg"
                >
                  <Edit2 className="h-4 w-4" />
                </button>
                <button 
                  onClick={() => handleDelete(post.id)} 
                  className="p-2 text-destructive hover:bg-destructive/10 rounded-lg"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default DashboardPostsSettings;
