import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Save } from "lucide-react";

const WithdrawalConfirmTextSettings = () => {
  const { toast } = useToast();
  const [text, setText] = useState("");

  useEffect(() => {
    supabase
      .from("site_settings")
      .select("value")
      .eq("key", "withdrawal_confirm_text")
      .single()
      .then(({ data }) => {
        if (data) setText(data.value || "");
      });
  }, []);

  const handleSave = async () => {
    const { data: existing } = await supabase
      .from("site_settings")
      .select("id")
      .eq("key", "withdrawal_confirm_text")
      .single();

    if (existing) {
      await supabase
        .from("site_settings")
        .update({ value: text })
        .eq("key", "withdrawal_confirm_text");
    } else {
      await supabase
        .from("site_settings")
        .insert({ key: "withdrawal_confirm_text", value: text });
    }

    toast({ title: "Saved" });
  };

  return (
    <div className="space-y-4">
      <h2 className="font-display text-xl font-bold">Withdrawal Confirm Text</h2>
      <div className="glass-card p-4 space-y-4">
        <p className="text-sm text-muted-foreground">
          This text will appear below the "Confirm Withdrawal" button on the withdrawal page.
        </p>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="input-field min-h-[120px]"
          placeholder="Enter instructions or notes for users..."
        />
        <button onClick={handleSave} className="btn-primary flex items-center gap-2">
          <Save className="h-4 w-4" /> Save
        </button>
      </div>
    </div>
  );
};

export default WithdrawalConfirmTextSettings;
