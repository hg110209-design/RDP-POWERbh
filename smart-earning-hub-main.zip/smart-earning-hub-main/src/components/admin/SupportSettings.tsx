import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, Edit2, Save, X } from "lucide-react";
import ImageUpload from "./ImageUpload";

const SupportSettings = () => {
  const { toast } = useToast();
  const [links, setLinks] = useState<any[]>([]);
  const [newLink, setNewLink] = useState({ title: "", link: "", image_url: "" });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editData, setEditData] = useState({ title: "", link: "", image_url: "" });

  useEffect(() => { fetchLinks(); }, []);

  const fetchLinks = async () => {
    const { data } = await supabase.from("support_links").select("*");
    setLinks(data || []);
  };

  const handleAdd = async () => {
    if (!newLink.title || !newLink.link) return;
    await supabase.from("support_links").insert(newLink);
    setNewLink({ title: "", link: "", image_url: "" });
    fetchLinks();
    toast({ title: "Added" });
  };

  const handleEdit = (item: any) => {
    setEditingId(item.id);
    setEditData({ title: item.title, link: item.link, image_url: item.image_url || "" });
  };

  const handleSaveEdit = async () => {
    if (!editingId) return;
    await supabase.from("support_links").update(editData).eq("id", editingId);
    setEditingId(null);
    fetchLinks();
    toast({ title: "Updated" });
  };

  const handleDelete = async (id: string) => {
    await supabase.from("support_links").delete().eq("id", id);
    fetchLinks();
    toast({ title: "Deleted" });
  };

  return (
    <div className="space-y-4">
      <h2 className="font-display text-xl font-bold">Support Links</h2>
      <div className="glass-card p-4 space-y-3">
        <input type="text" placeholder="Title (e.g. Telegram)" value={newLink.title} onChange={(e) => setNewLink({ ...newLink, title: e.target.value })} className="input-field" />
        <input type="text" placeholder="Link URL" value={newLink.link} onChange={(e) => setNewLink({ ...newLink, link: e.target.value })} className="input-field" />
        <label className="block text-sm font-medium">Image</label>
        <ImageUpload value={newLink.image_url} onChange={(url) => setNewLink({ ...newLink, image_url: url })} folder="support" />
        <button onClick={handleAdd} className="btn-primary flex items-center gap-2"><Plus className="h-4 w-4" /> Add</button>
      </div>
      
      {links.map((l) => (
        <div key={l.id} className="glass-card p-4">
          {editingId === l.id ? (
            <div className="space-y-3">
              <input type="text" value={editData.title} onChange={(e) => setEditData({ ...editData, title: e.target.value })} className="input-field" />
              <input type="text" value={editData.link} onChange={(e) => setEditData({ ...editData, link: e.target.value })} className="input-field" />
              <ImageUpload value={editData.image_url} onChange={(url) => setEditData({ ...editData, image_url: url })} folder="support" />
              <div className="flex gap-2">
                <button onClick={handleSaveEdit} className="btn-primary flex items-center gap-2"><Save className="h-4 w-4" /> Save</button>
                <button onClick={() => setEditingId(null)} className="btn-outline flex items-center gap-2"><X className="h-4 w-4" /> Cancel</button>
              </div>
            </div>
          ) : (
            <div className="flex justify-between items-center">
              <div className="flex gap-3 items-center">
                {l.image_url && <img src={l.image_url} alt="" className="h-10 w-10 rounded-lg object-cover" />}
                <div>
                  <p className="font-medium">{l.title}</p>
                  <p className="text-sm text-muted-foreground truncate max-w-[200px]">{l.link}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => handleEdit(l)} className="p-2 text-primary hover:bg-primary/10 rounded-lg"><Edit2 className="h-4 w-4" /></button>
                <button onClick={() => handleDelete(l.id)} className="p-2 text-destructive hover:bg-destructive/10 rounded-lg"><Trash2 className="h-4 w-4" /></button>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default SupportSettings;
