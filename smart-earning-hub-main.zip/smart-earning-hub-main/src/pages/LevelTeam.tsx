import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Search, Users, TrendingUp, DollarSign, ArrowUpRight, Zap, Globe, Check, X, User } from "lucide-react";

interface Profile {
  total_profit: number;
  daily_profit: number;
  partners_count: number;
  total_teams: number;
  referral_earn_active: boolean;
  global_earn_active: boolean;
}

interface SearchedUser {
  id: string;
  username: string;
  name: string;
  refer_code: string;
  total_profit: number;
  partners_count: number;
  total_teams: number;
  referral_earn_active: boolean;
  global_earn_active: boolean;
  profile_image: string | null;
}

const LevelTeam = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [searchCode, setSearchCode] = useState("");
  const [searchedUser, setSearchedUser] = useState<SearchedUser | null>(null);
  const [searching, setSearching] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        navigate("/auth");
        return;
      }

      const { data } = await supabase
        .from("profiles")
        .select("total_profit, daily_profit, partners_count, total_teams, referral_earn_active, global_earn_active")
        .eq("user_id", session.user.id)
        .single();

      if (data) {
        setProfile(data);
      }

      setLoading(false);
    };

    fetchProfile();
  }, [navigate]);

  const handleSearch = async () => {
    if (!searchCode.trim()) {
      toast({
        title: "Error",
        description: "Please enter a user ID.",
        variant: "destructive",
      });
      return;
    }

    setSearching(true);
    setSearchedUser(null);

    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, username, name, refer_code, total_profit, partners_count, total_teams, referral_earn_active, global_earn_active, profile_image")
        .eq("refer_code", searchCode.trim())
        .single();

      if (error || !data) {
        toast({
          title: "Not Found",
          description: "No user found with this ID.",
          variant: "destructive",
        });
        return;
      }

      setSearchedUser(data);
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to search user.",
        variant: "destructive",
      });
    } finally {
      setSearching(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-20 glass-card rounded-none border-x-0 border-t-0 px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-2 -ml-2 hover:bg-secondary rounded-lg">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="font-display font-bold text-lg gradient-text">Level Team</h1>
      </header>

      <main className="px-4 py-4 pb-20 space-y-4">
        {profile && (
          <>
            {/* Stats cards */}
            <div className="space-y-3 animate-slide-up">
              {/* Total Profit */}
              <div className="stat-card">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                      <DollarSign className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Total Profit</p>
                      <p className="font-display text-2xl font-bold">${profile.total_profit.toFixed(2)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 text-success text-sm">
                    <ArrowUpRight className="h-4 w-4" />
                    <span>+${profile.daily_profit.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {/* Partners */}
                <div className="stat-card">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-accent/20 flex items-center justify-center">
                      <Users className="h-4 w-4 text-accent" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Partners</p>
                      <p className="font-display text-xl font-bold">{profile.partners_count}</p>
                    </div>
                  </div>
                </div>

                {/* Total Teams */}
                <div className="stat-card">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-success/20 flex items-center justify-center">
                      <TrendingUp className="h-4 w-4 text-success" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Total Teams</p>
                      <p className="font-display text-xl font-bold">{profile.total_teams}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Plan status */}
            <div className="glass-card p-4 animate-slide-up" style={{ animationDelay: "0.1s" }}>
              <div className="flex items-center justify-between py-2 border-b border-border">
                <div className="flex items-center gap-2">
                  <Zap className="h-4 w-4 text-primary" />
                  <span>Referral Earn</span>
                </div>
                {profile.referral_earn_active ? (
                  <span className="px-2 py-1 rounded-full bg-success/20 text-success text-xs">Active</span>
                ) : (
                  <button
                    onClick={() => navigate("/pro-partner")}
                    className="text-xs text-primary hover:underline"
                  >
                    Pay Active
                  </button>
                )}
              </div>
              <div className="flex items-center justify-between py-2">
                <div className="flex items-center gap-2">
                  <Globe className="h-4 w-4 text-accent" />
                  <span>Global Earn</span>
                </div>
                {profile.global_earn_active ? (
                  <span className="px-2 py-1 rounded-full bg-success/20 text-success text-xs">Active</span>
                ) : (
                  <button
                    onClick={() => navigate("/pro-partner")}
                    className="text-xs text-primary hover:underline"
                  >
                    Pay Active
                  </button>
                )}
              </div>
            </div>
          </>
        )}

        {/* Search user */}
        <div className="glass-card p-4 animate-slide-up" style={{ animationDelay: "0.2s" }}>
          <h2 className="font-display font-bold text-lg mb-3">Check User ID</h2>
          <div className="flex gap-2">
            <input
              type="text"
              value={searchCode}
              onChange={(e) => setSearchCode(e.target.value)}
              placeholder="Enter user ID"
              className="input-field flex-1"
            />
            <button
              onClick={handleSearch}
              disabled={searching}
              className="btn-primary px-4"
            >
              {searching ? (
                <div className="animate-spin h-5 w-5 border-2 border-primary-foreground border-t-transparent rounded-full" />
              ) : (
                <Search className="h-5 w-5" />
              )}
            </button>
          </div>
        </div>

        {/* Searched user result */}
        {searchedUser && (
          <div className="glass-card p-4 animate-slide-up">
            <div className="flex items-center gap-3 mb-4 pb-4 border-b border-border">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center overflow-hidden">
                {searchedUser.profile_image ? (
                  <img src={searchedUser.profile_image} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <User className="h-6 w-6 text-primary-foreground" />
                )}
              </div>
              <div>
                <p className="font-display font-bold">{searchedUser.username}</p>
                <p className="text-sm text-muted-foreground">ID: {searchedUser.refer_code}</p>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-2 mb-4">
              <div className="text-center p-2 bg-secondary rounded-lg">
                <p className="text-xs text-muted-foreground">Profit</p>
                <p className="font-display font-bold text-primary">${searchedUser.total_profit.toFixed(0)}</p>
              </div>
              <div className="text-center p-2 bg-secondary rounded-lg">
                <p className="text-xs text-muted-foreground">Partners</p>
                <p className="font-display font-bold">{searchedUser.partners_count}</p>
              </div>
              <div className="text-center p-2 bg-secondary rounded-lg">
                <p className="text-xs text-muted-foreground">Teams</p>
                <p className="font-display font-bold">{searchedUser.total_teams}</p>
              </div>
            </div>

            {/* Plan status */}
            <div className="space-y-2">
              <div className="flex items-center justify-between p-2 bg-secondary rounded-lg">
                <span className="text-sm">Referral Earn</span>
                {searchedUser.referral_earn_active ? (
                  <Check className="h-4 w-4 text-success" />
                ) : (
                  <X className="h-4 w-4 text-destructive" />
                )}
              </div>
              <div className="flex items-center justify-between p-2 bg-secondary rounded-lg">
                <span className="text-sm">Global Earn</span>
                {searchedUser.global_earn_active ? (
                  <Check className="h-4 w-4 text-success" />
                ) : (
                  <X className="h-4 w-4 text-destructive" />
                )}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default LevelTeam;
