import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { 
  Eye, EyeOff, Mail, Lock, User, UserPlus, ArrowLeft, Shield, Hash,
  CheckCircle2, Users, DollarSign, TrendingUp, Globe, Zap, Award
} from "lucide-react";
import { z } from "zod";

const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters").max(20, "Username must be less than 20 characters"),
  name: z.string().min(2, "Name must be at least 2 characters").max(50, "Name must be less than 50 characters"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  referCode: z.string().optional(),
});

const Register = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchParams] = useSearchParams();
  
  const [formData, setFormData] = useState({
    username: "",
    name: "",
    email: "",
    password: "",
    referCode: searchParams.get("ref") || "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [logo, setLogo] = useState<string | null>(null);
  const [registrationGuide, setRegistrationGuide] = useState("");
  const [activationAmount, setActivationAmount] = useState("10");
  const [isFirstUser, setIsFirstUser] = useState(false);

  useEffect(() => {
    // Check if this is the first user (no profiles exist with active status)
    const checkFirstUser = async () => {
      const { count, error } = await supabase
        .from("profiles")
        .select("*", { count: "exact", head: true });
      // If error (RLS blocking) or count is 0, treat as first user scenario
      // But we need to check via public route - let's check site_settings for a flag
      setIsFirstUser(count === 0 || count === null);
    };
    checkFirstUser();
    const fetchSettings = async () => {
      const { data } = await supabase
        .from("site_settings")
        .select("key, value")
        .in("key", ["site_logo", "registration_guide", "activation_amount"]);
      
      if (data) {
        data.forEach(setting => {
          if (setting.key === "site_logo") setLogo(setting.value);
          if (setting.key === "registration_guide") setRegistrationGuide(setting.value || "");
          if (setting.key === "activation_amount") setActivationAmount(setting.value || "10");
        });
      }
    };
    fetchSettings();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      registerSchema.parse(formData);
    } catch (err) {
      if (err instanceof z.ZodError) {
        toast({
          title: "Validation Error",
          description: err.errors[0].message,
          variant: "destructive",
        });
        return;
      }
    }

    setLoading(true);

    try {
      // Check if username exists
      const { data: existingUser } = await supabase
        .from("profiles")
        .select("username")
        .eq("username", formData.username)
        .single();

      if (existingUser) {
        toast({
          title: "Registration Failed",
          description: "This username is already taken.",
          variant: "destructive",
        });
        setLoading(false);
        return;
      }

      // Check if refer code is valid (skip for first user)
      if (!isFirstUser) {
        if (!formData.referCode) {
          toast({
            title: "Registration Failed",
            description: "Refer code is required.",
            variant: "destructive",
          });
          setLoading(false);
          return;
        }

        const { data: referrer } = await supabase
          .from("profiles")
          .select("refer_code")
          .eq("refer_code", formData.referCode)
          .single();

        if (!referrer) {
          toast({
            title: "Registration Failed",
            description: "Invalid refer code. Please enter a valid refer code.",
            variant: "destructive",
          });
          setLoading(false);
          return;
        }
      }

      // Create account
      const { data, error } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          emailRedirectTo: `${window.location.origin}/`,
          data: {
            username: formData.username,
            name: formData.name,
            referred_by: formData.referCode,
          },
        },
      });

      if (error) {
        if (error.message.includes("already registered")) {
          toast({
            title: "Registration Failed",
            description: "This email is already registered. Please sign in instead.",
            variant: "destructive",
          });
        } else {
          toast({
            title: "Registration Failed",
            description: error.message,
            variant: "destructive",
          });
        }
        return;
      }

      if (data.user) {
        // Navigate to payment page
        navigate(`/payment/account_activation?userId=${data.user.id}`);
      }
    } catch (err) {
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const features = [
    { icon: Users, label: "10,000+ Active Members", color: "text-primary" },
    { icon: DollarSign, label: "Instant Withdrawals", color: "text-success" },
    { icon: TrendingUp, label: "Daily Earnings", color: "text-accent" },
    { icon: Globe, label: "Global Community", color: "text-primary" },
  ];

  const trustBadges = [
    { icon: Shield, label: "Secure Platform" },
    { icon: Zap, label: "Fast Payments" },
    { icon: Award, label: "Trusted by 10K+" },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Background effects */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/5" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-float" style={{ animationDelay: "3s" }} />
      </div>

      {/* Header */}
      <header className="relative z-10 p-4">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back</span>
        </button>
      </header>

      {/* Main content */}
      <main className="relative z-10 flex-1 flex flex-col items-center px-4 py-6 overflow-auto">
        {/* Logo */}
        <div className="mb-4 animate-fade-in">
          {logo ? (
            <img src={logo} alt="Logo" className="h-12 w-auto" />
          ) : (
            <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center animate-pulse-glow">
              <Shield className="h-6 w-6 text-primary-foreground" />
            </div>
          )}
        </div>

        {/* Trust badges */}
        <div className="flex flex-wrap justify-center gap-3 mb-4 animate-slide-up">
          {trustBadges.map((badge, idx) => (
            <div 
              key={idx}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-secondary/50 rounded-full text-xs"
            >
              <badge.icon className="h-3 w-3 text-primary" />
              <span className="text-muted-foreground">{badge.label}</span>
            </div>
          ))}
        </div>

        {/* Features grid */}
        <div className="grid grid-cols-2 gap-2 mb-4 w-full max-w-sm animate-slide-up" style={{ animationDelay: "0.05s" }}>
          {features.map((feature, idx) => (
            <div 
              key={idx}
              className="glass-card p-3 flex items-center gap-2"
            >
              <div className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center">
                <feature.icon className={`h-4 w-4 ${feature.color}`} />
              </div>
              <span className="text-xs font-medium">{feature.label}</span>
            </div>
          ))}
        </div>

        {/* Guide box */}
        {registrationGuide && (
          <div className="glass-card p-3 mb-4 max-w-sm w-full animate-slide-up" style={{ animationDelay: "0.1s" }}>
            <div className="flex items-start gap-2">
              <CheckCircle2 className="h-5 w-5 text-success flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-sm text-foreground mb-1">Account Activation Guide</h3>
                <p className="text-xs text-muted-foreground">{registrationGuide}</p>
              </div>
            </div>
          </div>
        )}

        {/* Registration form */}
        <div className="glass-card p-5 w-full max-w-sm animate-slide-up" style={{ animationDelay: "0.15s" }}>
          <h1 className="font-display text-xl font-bold text-center mb-4 gradient-text">Create Account</h1>

          <form onSubmit={handleRegister} className="space-y-3">
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                name="username"
                placeholder="Username (unique)"
                value={formData.username}
                onChange={handleChange}
                className="input-field pl-9 py-2.5 text-sm"
                required
              />
            </div>

            <div className="relative">
              <UserPlus className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                name="name"
                placeholder="Full Name"
                value={formData.name}
                onChange={handleChange}
                className="input-field pl-9 py-2.5 text-sm"
                required
              />
            </div>

            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="email"
                name="email"
                placeholder="Email"
                value={formData.email}
                onChange={handleChange}
                className="input-field pl-9 py-2.5 text-sm"
                required
              />
            </div>

            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                placeholder="Password"
                value={formData.password}
                onChange={handleChange}
                className="input-field pl-9 pr-9 py-2.5 text-sm"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>

            {!isFirstUser && (
              <div className="relative">
                <Hash className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input
                  type="text"
                  name="referCode"
                  placeholder="Refer Code (required)"
                  value={formData.referCode}
                  onChange={handleChange}
                  className="input-field pl-9 py-2.5 text-sm"
                  required
                />
              </div>
            )}
            {isFirstUser && (
              <div className="p-2.5 rounded-lg bg-primary/10 border border-primary/20">
                <p className="text-xs text-primary text-center">
                  You are the first user! No refer code needed.
                </p>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full btn-primary py-2.5 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? "Creating Account..." : "Continue to Payment"}
            </button>
          </form>

          {/* Pay Active button */}
          <div className="mt-4">
            <div className="glass-card p-3 border border-destructive/50 animate-pulse-glow">
              <p className="text-center text-xs text-muted-foreground mb-1">Account Activation Fee</p>
              <p className="text-center font-display text-xl font-bold text-destructive">${activationAmount}</p>
            </div>
          </div>

          <div className="mt-4 text-center">
            <p className="text-xs text-muted-foreground">
              Already have an account?{" "}
              <button
                onClick={() => navigate("/auth")}
                className="text-primary hover:underline font-medium"
              >
                Sign In
              </button>
            </p>
          </div>
        </div>

        {/* Bottom stats section */}
        <div className="mt-6 w-full max-w-sm animate-slide-up" style={{ animationDelay: "0.2s" }}>
          <div className="glass-card p-4">
            <h3 className="text-center text-sm font-semibold mb-3">Why Join Us?</h3>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div>
                <p className="font-display text-lg font-bold text-primary">$50K+</p>
                <p className="text-xs text-muted-foreground">Paid Out</p>
              </div>
              <div>
                <p className="font-display text-lg font-bold text-success">10K+</p>
                <p className="text-xs text-muted-foreground">Members</p>
              </div>
              <div>
                <p className="font-display text-lg font-bold text-accent">24/7</p>
                <p className="text-xs text-muted-foreground">Support</p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Register;
