import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { 
  Menu, X, User, Users, TrendingUp, DollarSign, 
  LogOut, Share2, Wallet, Newspaper, HeadphonesIcon,
  ChevronRight, ArrowUpRight, Bell, Crown, Star, Shield,
  Zap, Target, Gift, Award, Sparkles
} from "lucide-react";

interface Profile {
  id: string;
  username: string;
  name: string;
  refer_code: string;
  profile_image: string | null;
  status: string;
  total_profit: number;
  daily_profit: number;
  partners_count: number;
  total_teams: number;
  created_at: string;
}

interface SliderImage {
  id: string;
  image_url: string;
}

interface DashboardPost {
  id: string;
  title: string;
  content: string | null;
  image_url: string | null;
}

const Dashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [menuOpen, setMenuOpen] = useState(false);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [sliderImages, setSliderImages] = useState<SliderImage[]>([]);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [siteName, setSiteName] = useState("Best Income Platform");
  const [showWelcome, setShowWelcome] = useState(false);
  const [dashboardPosts, setDashboardPosts] = useState<DashboardPost[]>([]);

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        navigate("/auth");
        return;
      }

      // Fetch profile
      const { data: profileData } = await supabase
        .from("profiles")
        .select("*")
        .eq("user_id", session.user.id)
        .single();

      if (profileData) {
        setProfile(profileData);
        
        // Check if first login
        const hasSeenWelcome = localStorage.getItem(`welcome_${session.user.id}`);
        if (!hasSeenWelcome) {
          setShowWelcome(true);
          localStorage.setItem(`welcome_${session.user.id}`, "true");
        }
      }

      // Fetch slider images
      const { data: sliders } = await supabase
        .from("slider_images")
        .select("*")
        .eq("is_active", true)
        .order("order_index");

      if (sliders) {
        setSliderImages(sliders);
      }

      // Fetch site name
      const { data: settings } = await supabase
        .from("site_settings")
        .select("value")
        .eq("key", "site_name")
        .maybeSingle();

      if (settings) {
        setSiteName(settings.value || "Best Income Platform");
      }

      // Fetch dashboard posts
      const { data: postsData } = await supabase
        .from("dashboard_posts")
        .select("*")
        .eq("is_active", true)
        .order("created_at", { ascending: false });

      if (postsData) {
        setDashboardPosts(postsData as DashboardPost[]);
      }
    };

    checkAuth();

    // Auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session) {
        navigate("/auth");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  // Slider auto-play
  useEffect(() => {
    if (sliderImages.length > 1) {
      const interval = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % sliderImages.length);
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [sliderImages.length]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/auth");
  };

  const menuItems = [
    { icon: User, label: "Profile", path: "/profile" },
    { icon: Crown, label: "Pro Partner", path: "/pro-partner" },
    { icon: Users, label: "Pro Partnership", path: "/pro-partnership" },
    { icon: Zap, label: "Global Mining", path: "/global-mining" },
    { icon: TrendingUp, label: "Level Team", path: "/level-team" },
    { icon: Share2, label: "Refer & Earn", path: "/refer-earn" },
    { icon: Wallet, label: "Withdrawal", path: "/withdrawal" },
    { icon: Newspaper, label: "News & Event", path: "/news-events" },
    { icon: HeadphonesIcon, label: "Support", path: "/support" },
  ];

  if (!profile) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Animated background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/5" />
        <div className="absolute top-1/3 left-1/4 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-1/3 right-1/4 w-64 h-64 bg-accent/10 rounded-full blur-3xl animate-float" style={{ animationDelay: "2s" }} />
      </div>

      {/* Welcome modal */}
      {showWelcome && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm">
          <div className="glass-card p-6 m-4 max-w-sm text-center animate-scale-in">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Bell className="h-8 w-8 text-primary-foreground" />
            </div>
            <h2 className="font-display text-xl font-bold mb-2 gradient-text">Welcome!</h2>
            <p className="text-muted-foreground mb-4">
              Welcome to {siteName}! Your account is now active. Start building your team and earning today.
            </p>
            <button
              onClick={() => setShowWelcome(false)}
              className="btn-primary w-full"
            >
              Get Started
            </button>
          </div>
        </div>
      )}

      {/* Sidebar */}
      <div className={`fixed inset-y-0 right-0 z-40 w-72 bg-card border-l border-border transform transition-transform duration-300 ${menuOpen ? "translate-x-0" : "translate-x-full"}`}>
        <div className="p-4">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-display font-bold text-lg">Menu</h2>
            <button onClick={() => setMenuOpen(false)} className="p-2 hover:bg-secondary rounded-lg">
              <X className="h-5 w-5" />
            </button>
          </div>

          <nav className="space-y-1">
            {menuItems.map((item) => (
              <button
                key={item.path}
                onClick={() => {
                  navigate(item.path);
                  setMenuOpen(false);
                }}
                className="menu-item w-full"
              >
                <item.icon className="h-5 w-5" />
                <span>{item.label}</span>
                <ChevronRight className="h-4 w-4 ml-auto" />
              </button>
            ))}
            
            <button
              onClick={handleLogout}
              className="menu-item w-full text-destructive hover:text-destructive"
            >
              <LogOut className="h-5 w-5" />
              <span>Logout</span>
            </button>
          </nav>
        </div>
      </div>

      {/* Overlay */}
      {menuOpen && (
        <div 
          className="fixed inset-0 z-30 bg-background/50 backdrop-blur-sm"
          onClick={() => setMenuOpen(false)}
        />
      )}

      {/* Header */}
      <header className="sticky top-0 z-20 glass-card rounded-none border-x-0 border-t-0 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
            <Sparkles className="h-4 w-4 text-primary-foreground" />
          </div>
          <h1 className="font-display font-bold text-lg gradient-text">Dashboard</h1>
        </div>
        <button
          onClick={() => setMenuOpen(true)}
          className="p-2 hover:bg-secondary rounded-lg transition-colors"
        >
          <Menu className="h-6 w-6" />
        </button>
      </header>

      {/* Main content */}
      <main className="relative z-10 px-4 py-4 pb-20 space-y-4">
        {/* Profile card - Premium */}
        <div className="glass-card p-4 animate-slide-up overflow-hidden relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-primary/20 to-transparent rounded-bl-full" />
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary via-accent to-primary flex items-center justify-center overflow-hidden ring-2 ring-primary/30">
                {profile.profile_image ? (
                  <img src={profile.profile_image} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <User className="h-8 w-8 text-primary-foreground" />
                )}
              </div>
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-success flex items-center justify-center">
                <Shield className="h-3 w-3 text-success-foreground" />
              </div>
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 rounded-full bg-primary/20 text-primary text-xs font-medium">ID: {profile.refer_code}</span>
              </div>
              <p className="font-display font-bold text-lg text-foreground">{profile.username}</p>
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <Star className="h-3 w-3 text-warning" />
                Member since {new Date(profile.created_at).toLocaleDateString()}
              </p>
            </div>
          </div>
        </div>

        {/* Premium Stats Grid */}
        <div className="grid grid-cols-1 gap-3 animate-slide-up" style={{ animationDelay: "0.1s" }}>
          {/* Total Profit - Hero Card */}
          <div className="glass-card p-5 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-accent/10" />
            <div className="relative flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/30">
                  <DollarSign className="h-7 w-7 text-primary-foreground" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground font-medium">Total Profit</p>
                  <p className="font-display text-3xl font-bold gradient-text">${profile.total_profit.toFixed(2)}</p>
                </div>
              </div>
              <div className="flex flex-col items-end gap-1">
                <div className="flex items-center gap-1 text-success text-sm bg-success/10 px-3 py-1 rounded-full">
                  <ArrowUpRight className="h-4 w-4" />
                  <span className="font-medium">+${profile.daily_profit.toFixed(2)}</span>
                </div>
                <span className="text-xs text-muted-foreground">Today's Earning</span>
              </div>
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-2 gap-3">
            <div className="glass-card p-4 relative overflow-hidden group hover:border-accent/50 transition-all">
              <div className="absolute top-0 right-0 w-16 h-16 bg-accent/10 rounded-bl-3xl group-hover:bg-accent/20 transition-colors" />
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-accent/20 flex items-center justify-center">
                  <Users className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Partners</p>
                  <p className="font-display text-2xl font-bold text-foreground">{profile.partners_count}</p>
                </div>
              </div>
            </div>

            <div className="glass-card p-4 relative overflow-hidden group hover:border-success/50 transition-all">
              <div className="absolute top-0 right-0 w-16 h-16 bg-success/10 rounded-bl-3xl group-hover:bg-success/20 transition-colors" />
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-success/20 flex items-center justify-center">
                  <TrendingUp className="h-5 w-5 text-success" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Total Teams</p>
                  <p className="font-display text-2xl font-bold text-foreground">{profile.total_teams}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Big News Update Slider */}
        {sliderImages.length > 0 && (
          <div className="animate-slide-up" style={{ animationDelay: "0.2s" }}>
            <div className="flex items-center gap-2 mb-3">
              <Newspaper className="h-5 w-5 text-primary" />
              <h2 className="font-display font-bold text-lg">Big News Update</h2>
            </div>
            <div className="relative rounded-2xl overflow-hidden aspect-video shadow-xl shadow-primary/10">
              {sliderImages.map((slide, index) => (
                <div
                  key={slide.id}
                  className={`absolute inset-0 transition-all duration-500 ${
                    index === currentSlide ? "opacity-100 scale-100" : "opacity-0 scale-105"
                  }`}
                >
                  <img
                    src={slide.image_url}
                    alt={`Slide ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
                </div>
              ))}
              
              {/* Dots */}
              {sliderImages.length > 1 && (
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                  {sliderImages.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentSlide(index)}
                      className={`h-2 rounded-full transition-all ${
                        index === currentSlide ? "bg-primary w-6" : "bg-foreground/30 w-2"
                      }`}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Quick Actions - Premium */}
        <div className="animate-slide-up" style={{ animationDelay: "0.3s" }}>
          <div className="flex items-center gap-2 mb-3">
            <Zap className="h-5 w-5 text-accent" />
            <h2 className="font-display font-bold text-lg">Quick Actions</h2>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => navigate("/refer-earn")}
              className="glass-card p-4 text-left hover:border-primary/50 transition-all group relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent group-hover:from-primary/10 transition-colors" />
              <div className="relative">
                <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <Share2 className="h-6 w-6 text-primary" />
                </div>
                <p className="font-semibold text-foreground">Refer & Earn</p>
                <p className="text-xs text-muted-foreground">Share and earn rewards</p>
              </div>
            </button>
            
            <button
              onClick={() => navigate("/withdrawal")}
              className="glass-card p-4 text-left hover:border-success/50 transition-all group relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-success/5 to-transparent group-hover:from-success/10 transition-colors" />
              <div className="relative">
                <div className="w-12 h-12 rounded-xl bg-success/20 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <Wallet className="h-6 w-6 text-success" />
                </div>
                <p className="font-semibold text-foreground">Withdraw</p>
                <p className="text-xs text-muted-foreground">Withdraw your earnings</p>
              </div>
            </button>
          </div>
        </div>

        {/* More Actions */}
        <div className="grid grid-cols-4 gap-2 animate-slide-up" style={{ animationDelay: "0.35s" }}>
          <button onClick={() => navigate("/pro-partner")} className="glass-card p-3 flex flex-col items-center gap-2 hover:border-primary/50 transition-all">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <Crown className="h-5 w-5 text-primary" />
            </div>
            <span className="text-xs font-medium">Pro Partner</span>
          </button>
          <button onClick={() => navigate("/pro-partnership")} className="glass-card p-3 flex flex-col items-center gap-2 hover:border-accent/50 transition-all">
            <div className="w-10 h-10 rounded-xl bg-accent/20 flex items-center justify-center">
              <Award className="h-5 w-5 text-accent" />
            </div>
            <span className="text-xs font-medium">Partnership</span>
          </button>
          <button onClick={() => navigate("/news-events")} className="glass-card p-3 flex flex-col items-center gap-2 hover:border-warning/50 transition-all">
            <div className="w-10 h-10 rounded-xl bg-warning/20 flex items-center justify-center">
              <Newspaper className="h-5 w-5 text-warning" />
            </div>
            <span className="text-xs font-medium">News</span>
          </button>
          <button onClick={() => navigate("/support")} className="glass-card p-3 flex flex-col items-center gap-2 hover:border-success/50 transition-all">
            <div className="w-10 h-10 rounded-xl bg-success/20 flex items-center justify-center">
              <HeadphonesIcon className="h-5 w-5 text-success" />
            </div>
            <span className="text-xs font-medium">Support</span>
          </button>
        </div>

        {/* Achievements Section */}
        <div className="glass-card p-4 animate-slide-up" style={{ animationDelay: "0.4s" }}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Target className="h-5 w-5 text-warning" />
              <h2 className="font-display font-bold">Achievements</h2>
            </div>
            <span className="text-xs text-muted-foreground">Level {Math.floor(profile.partners_count / 5) + 1}</span>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2">
            <div className="flex-shrink-0 w-16 h-16 rounded-2xl bg-gradient-to-br from-warning/20 to-warning/10 flex items-center justify-center">
              <Gift className="h-8 w-8 text-warning" />
            </div>
            <div className="flex-shrink-0 w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
              <Star className="h-8 w-8 text-primary" />
            </div>
            <div className="flex-shrink-0 w-16 h-16 rounded-2xl bg-gradient-to-br from-accent/20 to-accent/10 flex items-center justify-center opacity-40">
              <Award className="h-8 w-8 text-accent" />
            </div>
            <div className="flex-shrink-0 w-16 h-16 rounded-2xl bg-secondary flex items-center justify-center opacity-40">
              <Crown className="h-8 w-8 text-muted-foreground" />
            </div>
          </div>
        </div>

        {/* Big Update Posts Section */}
        {dashboardPosts.length > 0 && (
          <div className="animate-slide-up" style={{ animationDelay: "0.45s" }}>
            <div className="flex items-center gap-2 mb-3">
              <Bell className="h-5 w-5 text-primary" />
              <h2 className="font-display font-bold text-lg">Big Update</h2>
            </div>
            <div className="space-y-3">
              {dashboardPosts.map((post) => (
                <div key={post.id} className="glass-card overflow-hidden group">
                  {post.image_url && (
                    <div className="relative h-48 overflow-hidden">
                      <img 
                        src={post.image_url} 
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
                    </div>
                  )}
                  <div className="p-4">
                    <h3 className="font-display font-bold text-lg mb-2">{post.title}</h3>
                    {post.content && (
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap">{post.content}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default Dashboard;