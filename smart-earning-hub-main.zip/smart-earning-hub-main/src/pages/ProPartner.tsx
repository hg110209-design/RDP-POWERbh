import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Zap, Globe, Check, Info } from "lucide-react";

interface InfoItem {
  id: string;
  type: string;
  content_type: string;
  content: string;
}

const ProPartner = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [referralEarnActive, setReferralEarnActive] = useState(false);
  const [globalEarnActive, setGlobalEarnActive] = useState(false);
  const [referralEarnText, setReferralEarnText] = useState("");
  const [globalEarnText, setGlobalEarnText] = useState("");
  const [referralEarnAmount, setReferralEarnAmount] = useState("50");
  const [globalEarnAmount, setGlobalEarnAmount] = useState("100");
  const [loading, setLoading] = useState(true);
  const [referralInfoText, setReferralInfoText] = useState("");
  const [globalInfoText, setGlobalInfoText] = useState("");
  const [referralInfoImages, setReferralInfoImages] = useState<InfoItem[]>([]);
  const [globalInfoImages, setGlobalInfoImages] = useState<InfoItem[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        navigate("/auth");
        return;
      }

      // Fetch profile status
      const { data: profile } = await supabase
        .from("profiles")
        .select("referral_earn_active, global_earn_active")
        .eq("user_id", session.user.id)
        .single();

      if (profile) {
        setReferralEarnActive(profile.referral_earn_active);
        setGlobalEarnActive(profile.global_earn_active);
      }

      // Fetch settings
      const { data: settings } = await supabase
        .from("site_settings")
        .select("key, value")
        .in("key", ["referral_earn_text", "global_earn_text", "referral_earn_amount", "global_earn_amount"]);

      if (settings) {
        settings.forEach(setting => {
          if (setting.key === "referral_earn_text") setReferralEarnText(setting.value || "");
          if (setting.key === "global_earn_text") setGlobalEarnText(setting.value || "");
          if (setting.key === "referral_earn_amount") setReferralEarnAmount(setting.value || "50");
          if (setting.key === "global_earn_amount") setGlobalEarnAmount(setting.value || "100");
        });
      }

      // Fetch pro partner info
      const { data: infoData } = await supabase
        .from("pro_partner_info")
        .select("*")
        .order("order_index");

      if (infoData) {
        const refText = infoData.find(d => d.type === "referral" && d.content_type === "text");
        const globText = infoData.find(d => d.type === "global" && d.content_type === "text");
        
        setReferralInfoText(refText?.content || "");
        setGlobalInfoText(globText?.content || "");
        setReferralInfoImages(infoData.filter(d => d.type === "referral" && d.content_type === "image"));
        setGlobalInfoImages(infoData.filter(d => d.type === "global" && d.content_type === "image"));
      }

      setLoading(false);
    };

    fetchData();
  }, [navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Animated background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/5" />
        <div className="absolute top-1/3 left-1/4 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-1/3 right-1/4 w-64 h-64 bg-accent/10 rounded-full blur-3xl animate-float" style={{ animationDelay: "2s" }} />
      </div>

      {/* Header */}
      <header className="sticky top-0 z-20 glass-card rounded-none border-x-0 border-t-0 px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-2 -ml-2 hover:bg-secondary rounded-lg">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="font-display font-bold text-lg gradient-text">Pro Partner</h1>
      </header>

      <main className="relative z-10 px-4 py-4 pb-20 space-y-4">
        {/* Referral Earn */}
        <div className="glass-card p-5 animate-slide-up relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-primary/20 to-transparent rounded-bl-full" />
          <div className="relative">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-primary/50 flex items-center justify-center shadow-lg shadow-primary/30">
                <Zap className="h-7 w-7 text-primary-foreground" />
              </div>
              <div>
                <h2 className="font-display font-bold text-xl">Referral Earn</h2>
                {referralEarnActive && (
                  <span className="text-xs text-success flex items-center gap-1 bg-success/10 px-2 py-0.5 rounded-full">
                    <Check className="h-3 w-3" /> Active
                  </span>
                )}
              </div>
            </div>

            <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
              {referralEarnText || "Earn money by referring new users to our platform. Get paid for every successful referral!"}
            </p>

            {referralEarnActive ? (
              <div className="bg-success/10 border border-success/30 rounded-xl p-4 text-center">
                <Check className="h-8 w-8 text-success mx-auto mb-2" />
                <p className="text-success font-semibold">Plan Active</p>
                <p className="text-xs text-muted-foreground">You can now earn from referrals</p>
              </div>
            ) : (
              <button
                onClick={() => navigate("/payment/referral_earn")}
                className="w-full btn-primary py-4 text-lg animate-pulse-glow"
              >
                Pay Active - ${referralEarnAmount}
              </button>
            )}
          </div>

          {/* Referral Info Section */}
          {(referralInfoText || referralInfoImages.length > 0) && (
            <div className="mt-4 pt-4 border-t border-border">
              {referralInfoText && (
                <p className="text-sm text-muted-foreground mb-3 whitespace-pre-wrap">{referralInfoText}</p>
              )}
              {referralInfoImages.length > 0 && (
                <div className="grid grid-cols-2 gap-2">
                  {referralInfoImages.map((item) => (
                    <img 
                      key={item.id}
                      src={item.content} 
                      alt="Info" 
                      className="w-full h-auto rounded-lg object-cover"
                    />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Global Earn */}
        <div className="glass-card p-5 animate-slide-up relative overflow-hidden" style={{ animationDelay: "0.1s" }}>
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-accent/20 to-transparent rounded-bl-full" />
          <div className="relative">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-accent to-accent/50 flex items-center justify-center shadow-lg shadow-accent/30">
                <Globe className="h-7 w-7 text-accent-foreground" />
              </div>
              <div>
                <h2 className="font-display font-bold text-xl">Global Earn</h2>
                {globalEarnActive && (
                  <span className="text-xs text-success flex items-center gap-1 bg-success/10 px-2 py-0.5 rounded-full">
                    <Check className="h-3 w-3" /> Active
                  </span>
                )}
              </div>
            </div>

            <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
              {globalEarnText || "Earn commission from your entire team network. Multi-level earning from all your downline members."}
            </p>

            {globalEarnActive ? (
              <div className="bg-success/10 border border-success/30 rounded-xl p-4 text-center">
                <Check className="h-8 w-8 text-success mx-auto mb-2" />
                <p className="text-success font-semibold">Plan Active</p>
                <p className="text-xs text-muted-foreground">You can now earn from your team</p>
              </div>
            ) : (
              <button
                onClick={() => navigate("/payment/global_earn")}
                className="w-full border-2 border-accent text-accent hover:bg-accent/10 px-6 py-4 rounded-xl transition-all text-lg font-semibold"
              >
                Pay Active - ${globalEarnAmount}
              </button>
            )}

          {/* Global Info Section */}
          {(globalInfoText || globalInfoImages.length > 0) && (
            <div className="mt-4 pt-4 border-t border-border">
              {globalInfoText && (
                <p className="text-sm text-muted-foreground mb-3 whitespace-pre-wrap">{globalInfoText}</p>
              )}
              {globalInfoImages.length > 0 && (
                <div className="grid grid-cols-2 gap-2">
                  {globalInfoImages.map((item) => (
                    <img 
                      key={item.id}
                      src={item.content} 
                      alt="Info" 
                      className="w-full h-auto rounded-lg object-cover"
                    />
                  ))}
                </div>
              )}
            </div>
          )}
          </div>
        </div>

      </main>
    </div>
  );
};

export default ProPartner;