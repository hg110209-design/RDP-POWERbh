import { useState, useEffect } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, Copy, Check, CreditCard, Shield, Clock, 
  CheckCircle2, ChevronDown, ChevronUp, Globe, Zap, Lock
} from "lucide-react";

interface PaymentMethod {
  id: string;
  name: string;
  number: string;
  image_url: string | null;
}

const Payment = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { type } = useParams<{ type: string }>();
  const [searchParams] = useSearchParams();
  const userId = searchParams.get("userId");

  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null);
  const [transactionId, setTransactionId] = useState("");
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [amount, setAmount] = useState("10");
  const [showMethods, setShowMethods] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      // Fetch payment methods
      const { data: methods } = await supabase
        .from("payment_methods")
        .select("*")
        .eq("is_active", true);
      
      if (methods) {
        setPaymentMethods(methods);
      }

      // Fetch amount based on type
      let amountKey = "activation_amount";
      if (type === "referral_earn") amountKey = "referral_earn_amount";
      if (type === "global_earn") amountKey = "global_earn_amount";

      const { data: settings } = await supabase
        .from("site_settings")
        .select("value")
        .eq("key", amountKey)
        .single();

      if (settings) {
        setAmount(settings.value || "10");
      }
    };

    fetchData();
  }, [type]);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({
      title: "Copied!",
      description: "Payment number copied to clipboard.",
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedMethod) {
      toast({
        title: "Error",
        description: "Please select a payment method.",
        variant: "destructive",
      });
      return;
    }

    if (!transactionId.trim()) {
      toast({
        title: "Error",
        description: "Please enter the transaction ID.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      // Get current user
      const { data: { session } } = await supabase.auth.getSession();
      const currentUserId = userId || session?.user?.id;

      if (!currentUserId) {
        toast({
          title: "Error",
          description: "User not found. Please try again.",
          variant: "destructive",
        });
        return;
      }

      // Create payment request
      const { error } = await supabase.from("payment_requests").insert({
        user_id: currentUserId,
        type: type,
        amount: parseFloat(amount),
        transaction_id: transactionId.trim(),
        payment_method: selectedMethod.name,
        status: "pending",
      });

      if (error) throw error;

      toast({
        title: "Payment Submitted",
        description: "Your payment is pending approval. Please wait for admin confirmation.",
      });

      navigate("/auth");
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to submit payment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getTitle = () => {
    switch (type) {
      case "account_activation":
        return "Account Activation";
      case "referral_earn":
        return "Referral Earn Plan";
      case "global_earn":
        return "Global Earn Plan";
      default:
        return "Payment";
    }
  };

  const getIcon = () => {
    switch (type) {
      case "account_activation":
        return Shield;
      case "referral_earn":
        return Zap;
      case "global_earn":
        return Globe;
      default:
        return CreditCard;
    }
  };

  const Icon = getIcon();

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Background effects */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-accent/10" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/15 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/15 rounded-full blur-3xl animate-float" style={{ animationDelay: "3s" }} />
      </div>

      {/* Header */}
      <header className="relative z-10 p-4 flex items-center gap-3">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="font-display text-lg font-bold gradient-text">{getTitle()}</h1>
      </header>

      {/* Main content */}
      <main className="relative z-10 flex-1 px-4 py-4 overflow-auto">
        <form onSubmit={handleSubmit} className="max-w-sm mx-auto space-y-4">
          
          {/* Trust badges */}
          <div className="flex justify-center gap-3 animate-slide-up">
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-success/10 rounded-full text-xs">
              <CheckCircle2 className="h-3 w-3 text-success" />
              <span className="text-success">Verified</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-primary/10 rounded-full text-xs">
              <Lock className="h-3 w-3 text-primary" />
              <span className="text-primary">Secure</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-accent/10 rounded-full text-xs">
              <Clock className="h-3 w-3 text-accent" />
              <span className="text-accent">Fast</span>
            </div>
          </div>

          {/* Amount display */}
          <div className="glass-card p-6 text-center animate-slide-up border-2 border-primary/30">
            <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center animate-pulse-glow">
              <Icon className="h-8 w-8 text-primary-foreground" />
            </div>
            <p className="text-sm text-muted-foreground mb-1">Payment Amount</p>
            <p className="font-display text-4xl font-bold gradient-text">${amount}</p>
            <p className="text-xs text-muted-foreground mt-2">One-time payment</p>
          </div>

          {/* Payment method selection */}
          <div className="glass-card overflow-hidden animate-slide-up" style={{ animationDelay: "0.1s" }}>
            <button
              type="button"
              onClick={() => setShowMethods(!showMethods)}
              className="w-full p-4 flex items-center justify-between text-left hover:bg-secondary/50 transition-colors"
            >
              <div className="flex items-center gap-3">
                {selectedMethod ? (
                  <>
                    {selectedMethod.image_url ? (
                      <img src={selectedMethod.image_url} alt={selectedMethod.name} className="h-10 w-10 rounded-lg object-contain" />
                    ) : (
                      <div className="h-10 w-10 rounded-lg bg-primary/20 flex items-center justify-center">
                        <CreditCard className="h-5 w-5 text-primary" />
                      </div>
                    )}
                    <div>
                      <p className="font-medium">{selectedMethod.name}</p>
                      <p className="text-xs text-muted-foreground">Click to change</p>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="h-10 w-10 rounded-lg bg-secondary flex items-center justify-center">
                      <CreditCard className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-medium">Select Payment Method</p>
                      <p className="text-xs text-muted-foreground">Choose from available options</p>
                    </div>
                  </>
                )}
              </div>
              {showMethods ? (
                <ChevronUp className="h-5 w-5 text-muted-foreground" />
              ) : (
                <ChevronDown className="h-5 w-5 text-muted-foreground" />
              )}
            </button>
            
            {showMethods && (
              <div className="border-t border-border p-2 space-y-1 max-h-60 overflow-y-auto">
                {paymentMethods.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No payment methods available.
                  </p>
                ) : (
                  paymentMethods.map((method) => (
                    <button
                      key={method.id}
                      type="button"
                      onClick={() => {
                        setSelectedMethod(method);
                        setShowMethods(false);
                      }}
                      className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all ${
                        selectedMethod?.id === method.id
                          ? "bg-primary/20 border border-primary"
                          : "hover:bg-secondary"
                      }`}
                    >
                      {method.image_url ? (
                        <img src={method.image_url} alt={method.name} className="h-8 w-8 object-contain rounded" />
                      ) : (
                        <div className="h-8 w-8 rounded bg-secondary flex items-center justify-center">
                          <CreditCard className="h-4 w-4 text-muted-foreground" />
                        </div>
                      )}
                      <span className="flex-1 text-left font-medium">{method.name}</span>
                      {selectedMethod?.id === method.id && (
                        <Check className="h-5 w-5 text-primary" />
                      )}
                    </button>
                  ))
                )}
              </div>
            )}
          </div>

          {/* Payment details */}
          {selectedMethod && (
            <div className="glass-card p-4 animate-slide-up space-y-3" style={{ animationDelay: "0.2s" }}>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
                <p className="text-sm font-medium text-foreground">Send payment to:</p>
              </div>
              
              <div className="bg-secondary rounded-lg p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground mb-1">{selectedMethod.name} Number</p>
                    <p className="font-mono text-lg font-bold break-all">{selectedMethod.number}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleCopy(selectedMethod.number)}
                    className="p-3 bg-primary/20 hover:bg-primary/30 rounded-lg transition-colors"
                  >
                    {copied ? (
                      <Check className="h-5 w-5 text-success" />
                    ) : (
                      <Copy className="h-5 w-5 text-primary" />
                    )}
                  </button>
                </div>
              </div>
              
              <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3">
                <p className="text-xs text-destructive text-center">
                  ⚠️ Send exactly ${amount} to this number
                </p>
              </div>
            </div>
          )}

          {/* Transaction ID input */}
          <div className="glass-card p-4 animate-slide-up" style={{ animationDelay: "0.3s" }}>
            <label className="block text-sm font-medium text-foreground mb-2">
              Transaction ID
            </label>
            <input
              type="text"
              value={transactionId}
              onChange={(e) => setTransactionId(e.target.value)}
              placeholder="Enter your transaction ID"
              className="input-field"
              required
            />
            <p className="text-xs text-muted-foreground mt-2">
              Enter the transaction ID you received after payment
            </p>
          </div>

          {/* Submit button */}
          <button
            type="submit"
            disabled={loading || !selectedMethod}
            className="w-full btn-primary py-4 text-lg disabled:opacity-50 disabled:cursor-not-allowed animate-slide-up flex items-center justify-center gap-2"
            style={{ animationDelay: "0.4s" }}
          >
            {loading ? (
              <>
                <div className="animate-spin h-5 w-5 border-2 border-primary-foreground border-t-transparent rounded-full" />
                Submitting...
              </>
            ) : (
              <>
                <CheckCircle2 className="h-5 w-5" />
                Confirm Payment
              </>
            )}
          </button>

          {/* Info section */}
          <div className="glass-card p-4 animate-slide-up" style={{ animationDelay: "0.5s" }}>
            <h3 className="font-medium text-sm mb-3 flex items-center gap-2">
              <Shield className="h-4 w-4 text-primary" />
              How it works
            </h3>
            <ol className="text-xs text-muted-foreground space-y-2">
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-primary/20 text-primary flex items-center justify-center flex-shrink-0 text-xs">1</span>
                <span>Select your preferred payment method</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-primary/20 text-primary flex items-center justify-center flex-shrink-0 text-xs">2</span>
                <span>Send the exact amount to the given number</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-primary/20 text-primary flex items-center justify-center flex-shrink-0 text-xs">3</span>
                <span>Enter your transaction ID and submit</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-success/20 text-success flex items-center justify-center flex-shrink-0 text-xs">✓</span>
                <span>Wait for admin approval (usually within 24 hours)</span>
              </li>
            </ol>
          </div>

        </form>
      </main>
    </div>
  );
};

export default Payment;