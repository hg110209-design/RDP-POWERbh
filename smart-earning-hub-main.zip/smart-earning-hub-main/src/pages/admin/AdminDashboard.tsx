import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { 
  Menu, X, Users, DollarSign, CreditCard, LogOut, Settings,
  ChevronDown, ChevronRight, UserCheck, Wallet, Newspaper,
  HeadphonesIcon, Image, Shield, TrendingUp, Zap, Globe, Crown, History, Upload, Coins
} from "lucide-react";

// Admin components
import AdminStats from "@/components/admin/AdminStats";
import UserSettings from "@/components/admin/UserSettings";
import PaymentSettings from "@/components/admin/PaymentSettings";
import WithdrawalSettings from "@/components/admin/WithdrawalSettings";
import NewsSettings from "@/components/admin/NewsSettings";
import SupportSettings from "@/components/admin/SupportSettings";
import LogoSettings from "@/components/admin/LogoSettings";
import GeneralSettings from "@/components/admin/GeneralSettings";
import ProPartnerSettings from "@/components/admin/ProPartnerSettings";
import ProPartnershipSettings from "@/components/admin/ProPartnershipSettings";
import ReferEarnSettings from "@/components/admin/ReferEarnSettings";
import WithdrawalFooterSettings from "@/components/admin/WithdrawalFooterSettings";
import ProPartnershipFooterSettings from "@/components/admin/ProPartnershipFooterSettings";
import DashboardPostsSettings from "@/components/admin/DashboardPostsSettings";
import PlanHistorySettings from "@/components/admin/PlanHistorySettings";
import InfoUploadSettings from "@/components/admin/InfoUploadSettings";
import ActiveProPartnershipUsers from "@/components/admin/ActiveProPartnershipUsers";
import WithdrawalConfirmTextSettings from "@/components/admin/WithdrawalConfirmTextSettings";
import GlobalMiningSettings from "@/components/admin/GlobalMiningSettings";

type MenuItem = {
  icon: any;
  label: string;
  key: string;
  subItems?: { label: string; key: string }[];
};

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("dashboard");
  const [expandedMenus, setExpandedMenus] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAdmin = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        navigate("/admin");
        return;
      }

      // Check if admin
      const { data: role } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", session.user.id)
        .eq("role", "admin")
        .single();

      if (!role) {
        navigate("/admin");
        return;
      }

      setLoading(false);
    };

    checkAdmin();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session) {
        navigate("/admin");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/admin");
  };

  const toggleMenu = (key: string) => {
    setExpandedMenus(prev => 
      prev.includes(key) 
        ? prev.filter(k => k !== key) 
        : [...prev, key]
    );
  };

  const menuItems: MenuItem[] = [
    { icon: TrendingUp, label: "Dashboard", key: "dashboard" },
    { 
      icon: Users, 
      label: "Users Setting", 
      key: "users",
      subItems: [
        { label: "Active Account", key: "active-account" },
        { label: "Active Referral Earn", key: "active-referral" },
        { label: "Active Global Earn", key: "active-global" },
        { label: "Active Pro Partnership", key: "active-partnership" },
      ]
    },
    { 
      icon: UserCheck, 
      label: "Active Account Setting", 
      key: "account-setting",
      subItems: [
        { label: "Active Setting", key: "activation-setting" },
      ]
    },
    { 
      icon: Zap, 
      label: "Pro Partner Setting", 
      key: "pro-partner",
      subItems: [
        { label: "Referral Earn Settings", key: "referral-settings" },
        { label: "Global Earn Settings", key: "global-settings" },
        { label: "Info Upload", key: "info-upload" },
      ]
    },
    { 
      icon: Crown, 
      label: "Pro Partnership Setting", 
      key: "partnership",
      subItems: [
        { label: "Plans", key: "partnership-setting" },
        { label: "Footer Settings", key: "partnership-footer" },
      ]
    },
    { icon: Coins, label: "Global Mining Setting", key: "mining-setting" },
    { icon: DollarSign, label: "Refer & Earn Setting", key: "refer-setting" },
    { 
      icon: CreditCard, 
      label: "Payment Method Setting", 
      key: "payment",
      subItems: [
        { label: "Payment Methods", key: "payment-methods" },
        { label: "Account Pending", key: "payment-pending" },
        { label: "Referral Earn Pending", key: "referral-pending" },
        { label: "Global Earn Pending", key: "global-pending" },
      ]
    },
    { 
      icon: Wallet, 
      label: "Withdrawal Setting", 
      key: "withdrawal",
      subItems: [
        { label: "Withdrawal Methods", key: "withdrawal-methods" },
        { label: "Confirm Text", key: "withdrawal-confirm-text" },
        { label: "Footer Settings", key: "withdrawal-footer" },
        { label: "Payment Pending", key: "withdrawal-pending" },
        { label: "Payment Approved", key: "withdrawal-approved" },
        { label: "Payment Rejected", key: "withdrawal-rejected" },
        { label: "History", key: "withdrawal-history" },
      ]
    },
    { 
      icon: Newspaper,
      label: "News & Event Setting", 
      key: "news-menu",
      subItems: [
        { label: "News & Events", key: "news" },
        { label: "Dashboard Posts", key: "dashboard-posts" },
      ]
    },
    { icon: HeadphonesIcon, label: "Support Setting", key: "support" },
    { icon: Image, label: "Logo Setting", key: "logo" },
    { icon: Settings, label: "Settings", key: "settings" },
  ];

  const renderContent = () => {
    switch (activeSection) {
      case "dashboard":
        return <AdminStats />;
      case "active-account":
      case "active-referral":
      case "active-global":
      case "active-partnership":
        return <UserSettings section={activeSection} />;
      case "activation-setting":
        return <UserSettings section={activeSection} />;
      case "account-pending":
        return <PaymentSettings section="payment-pending" />;
      case "referral-settings":
      case "global-settings":
        return <ProPartnerSettings section={activeSection} />;
      case "plan-history":
        return <PlanHistorySettings />;
      case "info-upload":
        return <InfoUploadSettings />;
      case "active-partnership":
        return <ActiveProPartnershipUsers />;
      case "partnership-setting":
        return <ProPartnershipSettings />;
      case "partnership-footer":
        return <ProPartnershipFooterSettings />;
      case "mining-setting":
        return <GlobalMiningSettings />;
      case "refer-setting":
        return <ReferEarnSettings />;
      case "payment-methods":
      case "payment-pending":
      case "referral-pending":
      case "global-pending":
        return <PaymentSettings section={activeSection} />;
      case "withdrawal-methods":
      case "withdrawal-pending":
      case "withdrawal-approved":
      case "withdrawal-rejected":
      case "withdrawal-history":
        return <WithdrawalSettings section={activeSection} />;
      case "withdrawal-confirm-text":
        return <WithdrawalConfirmTextSettings />;
      case "withdrawal-footer":
        return <WithdrawalFooterSettings />;
      case "news":
        return <NewsSettings />;
      case "dashboard-posts":
        return <DashboardPostsSettings />;
      case "support":
        return <SupportSettings />;
      case "logo":
        return <LogoSettings />;
      case "settings":
        return <GeneralSettings />;
      default:
        return <AdminStats />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar */}
      <div className={`fixed inset-y-0 right-0 z-40 w-80 bg-card border-l border-border transform transition-transform duration-300 overflow-y-auto ${menuOpen ? "translate-x-0" : "translate-x-full"}`}>
        <div className="p-4">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-display font-bold text-lg flex items-center gap-2">
              <Shield className="h-5 w-5 text-destructive" />
              Admin Menu
            </h2>
            <button onClick={() => setMenuOpen(false)} className="p-2 hover:bg-secondary rounded-lg">
              <X className="h-5 w-5" />
            </button>
          </div>

          <nav className="space-y-1">
            {menuItems.map((item) => (
              <div key={item.key}>
                <button
                  onClick={() => {
                    if (item.subItems) {
                      toggleMenu(item.key);
                    } else {
                      setActiveSection(item.key);
                      setMenuOpen(false);
                    }
                  }}
                  className={`menu-item w-full ${activeSection === item.key ? "active" : ""}`}
                >
                  <item.icon className="h-5 w-5" />
                  <span className="flex-1 text-left">{item.label}</span>
                  {item.subItems && (
                    expandedMenus.includes(item.key) 
                      ? <ChevronDown className="h-4 w-4" />
                      : <ChevronRight className="h-4 w-4" />
                  )}
                </button>
                
                {item.subItems && expandedMenus.includes(item.key) && (
                  <div className="ml-8 space-y-1 mt-1">
                    {item.subItems.map((subItem) => (
                      <button
                        key={subItem.key}
                        onClick={() => {
                          setActiveSection(subItem.key);
                          setMenuOpen(false);
                        }}
                        className={`menu-item w-full text-sm ${activeSection === subItem.key ? "active" : ""}`}
                      >
                        <span>{subItem.label}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
            
            <button
              onClick={handleLogout}
              className="menu-item w-full text-destructive hover:text-destructive"
            >
              <LogOut className="h-5 w-5" />
              <span>Logout</span>
            </button>
          </nav>
        </div>
      </div>

      {/* Overlay */}
      {menuOpen && (
        <div 
          className="fixed inset-0 z-30 bg-background/50 backdrop-blur-sm"
          onClick={() => setMenuOpen(false)}
        />
      )}

      {/* Header */}
      <header className="sticky top-0 z-20 glass-card rounded-none border-x-0 border-t-0 px-4 py-3 flex items-center justify-between">
        <h1 className="font-display font-bold text-lg flex items-center gap-2">
          <Shield className="h-5 w-5 text-destructive" />
          <span className="gradient-text">Admin Panel</span>
        </h1>
        <button
          onClick={() => setMenuOpen(true)}
          className="p-2 hover:bg-secondary rounded-lg transition-colors"
        >
          <Menu className="h-6 w-6" />
        </button>
      </header>

      {/* Main content */}
      <main className="px-4 py-4 pb-20">
        {renderContent()}
      </main>
    </div>
  );
};

export default AdminDashboard;
