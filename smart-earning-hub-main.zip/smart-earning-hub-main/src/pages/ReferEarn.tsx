import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Copy, Check, Users, TrendingUp, Share2, MessageCircle } from "lucide-react";

const ReferEarn = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [referCode, setReferCode] = useState("");
  const [referLink, setReferLink] = useState("");
  const [partnersCount, setPartnersCount] = useState(0);
  const [totalTeams, setTotalTeams] = useState(0);
  const [referInfo, setReferInfo] = useState("");
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        navigate("/auth");
        return;
      }

      // Fetch profile
      const { data: profile } = await supabase
        .from("profiles")
        .select("refer_code, partners_count, total_teams")
        .eq("user_id", session.user.id)
        .single();

      if (profile) {
        setReferCode(profile.refer_code);
        setPartnersCount(profile.partners_count);
        setTotalTeams(profile.total_teams);
      }

      // Fetch domain link
      const { data: settings } = await supabase
        .from("site_settings")
        .select("key, value")
        .in("key", ["domain_link", "refer_earn_info"]);

      if (settings) {
        const domainSetting = settings.find(s => s.key === "domain_link");
        const infoSetting = settings.find(s => s.key === "refer_earn_info");
        
        const domain = domainSetting?.value || window.location.origin;
        setReferLink(`${domain}/register?ref=${profile?.refer_code || ""}`);
        setReferInfo(infoSetting?.value || "");
      } else {
        setReferLink(`${window.location.origin}/register?ref=${profile?.refer_code || ""}`);
      }

      setLoading(false);
    };

    fetchData();
  }, [navigate]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
    toast({
      title: "Copied!",
      description: "Referral link copied to clipboard.",
    });
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(referCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
    toast({
      title: "Copied!",
      description: "Referral code copied to clipboard.",
    });
  };

  const shareToSocial = (platform: string) => {
    const message = encodeURIComponent(`Join me on this amazing platform and start earning! Use my referral link: ${referLink}`);
    
    const urls: Record<string, string> = {
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(referLink)}`,
      instagram: `https://www.instagram.com/`,
      telegram: `https://t.me/share/url?url=${encodeURIComponent(referLink)}&text=${message}`,
      whatsapp: `https://wa.me/?text=${message}`,
    };

    window.open(urls[platform], "_blank");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-20 glass-card rounded-none border-x-0 border-t-0 px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-2 -ml-2 hover:bg-secondary rounded-lg">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="font-display font-bold text-lg gradient-text">Refer & Earn</h1>
      </header>

      <main className="px-4 py-4 pb-20 space-y-4">
        {/* Refer link */}
        <div className="glass-card p-4 animate-slide-up">
          <h2 className="text-sm text-muted-foreground mb-2">Your Refer Link</h2>
          <div className="flex items-center gap-2 bg-secondary rounded-lg p-3">
            <span className="flex-1 text-xs break-all font-mono">{referLink}</span>
            <button
              onClick={handleCopyLink}
              className="p-2 hover:bg-primary/10 rounded-lg transition-colors flex-shrink-0"
            >
              {copiedLink ? (
                <Check className="h-4 w-4 text-success" />
              ) : (
                <Copy className="h-4 w-4 text-muted-foreground" />
              )}
            </button>
          </div>
        </div>

        {/* Refer code */}
        <div className="glass-card p-4 animate-slide-up" style={{ animationDelay: "0.1s" }}>
          <h2 className="text-sm text-muted-foreground mb-2">Refer Code</h2>
          <div className="flex items-center gap-2 bg-secondary rounded-lg p-3">
            <span className="flex-1 font-display text-xl font-bold text-primary">{referCode}</span>
            <button
              onClick={handleCopyCode}
              className="p-2 hover:bg-primary/10 rounded-lg transition-colors"
            >
              {copiedCode ? (
                <Check className="h-4 w-4 text-success" />
              ) : (
                <Copy className="h-4 w-4 text-muted-foreground" />
              )}
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="glass-card p-4 animate-slide-up" style={{ animationDelay: "0.2s" }}>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
                <Users className="h-5 w-5 text-accent" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Partners</p>
                <p className="font-display text-xl font-bold">{partnersCount}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-success/20 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Total Teams</p>
                <p className="font-display text-xl font-bold">{totalTeams}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Info text */}
        {referInfo && (
          <div className="glass-card p-4 animate-slide-up" style={{ animationDelay: "0.3s" }}>
            <p className="text-sm text-muted-foreground">{referInfo}</p>
          </div>
        )}

        {/* Share buttons */}
        <div className="animate-slide-up" style={{ animationDelay: "0.4s" }}>
          <h2 className="font-display font-bold text-lg mb-3">Share on Social Media</h2>
          <div className="grid grid-cols-4 gap-3">
            <button
              onClick={() => shareToSocial("facebook")}
              className="glass-card p-4 flex flex-col items-center gap-2 hover:border-primary/50 transition-all"
            >
              <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center">
                <span className="text-white font-bold">f</span>
              </div>
              <span className="text-xs">Facebook</span>
            </button>

            <button
              onClick={() => shareToSocial("instagram")}
              className="glass-card p-4 flex flex-col items-center gap-2 hover:border-primary/50 transition-all"
            >
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 via-pink-500 to-orange-400 flex items-center justify-center">
                <Share2 className="h-5 w-5 text-white" />
              </div>
              <span className="text-xs">Instagram</span>
            </button>

            <button
              onClick={() => shareToSocial("telegram")}
              className="glass-card p-4 flex flex-col items-center gap-2 hover:border-primary/50 transition-all"
            >
              <div className="w-10 h-10 rounded-full bg-sky-500 flex items-center justify-center">
                <MessageCircle className="h-5 w-5 text-white" />
              </div>
              <span className="text-xs">Telegram</span>
            </button>

            <button
              onClick={() => shareToSocial("whatsapp")}
              className="glass-card p-4 flex flex-col items-center gap-2 hover:border-primary/50 transition-all"
            >
              <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center">
                <MessageCircle className="h-5 w-5 text-white" />
              </div>
              <span className="text-xs">WhatsApp</span>
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ReferEarn;
