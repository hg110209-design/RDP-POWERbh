import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, Newspaper, ImageOff } from "lucide-react";

interface NewsEvent {
  id: string;
  title: string;
  content: string | null;
  image_url: string | null;
  created_at: string;
}

const NewsEvents = () => {
  const navigate = useNavigate();
  const [news, setNews] = useState<NewsEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [imageErrors, setImageErrors] = useState<Set<string>>(new Set());

  useEffect(() => {
    const fetchNews = async () => {
      const { data } = await supabase
        .from("news_events")
        .select("*")
        .eq("is_active", true)
        .order("created_at", { ascending: false });

      if (data) {
        setNews(data);
      }

      setLoading(false);
    };

    fetchNews();
  }, []);

  const handleImageError = (id: string) => {
    setImageErrors(prev => new Set(prev).add(id));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-20 glass-card rounded-none border-x-0 border-t-0 px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-2 -ml-2 hover:bg-secondary rounded-lg">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="font-display font-bold text-lg gradient-text">News & Events</h1>
      </header>

      <main className="px-4 py-4 pb-20 space-y-4">
        {news.length === 0 ? (
          <div className="glass-card p-8 text-center animate-slide-up">
            <Newspaper className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No news or events available.</p>
          </div>
        ) : (
          news.map((item, index) => (
            <div 
              key={item.id} 
              className="glass-card overflow-hidden animate-slide-up"
              style={{ animationDelay: `${0.1 * index}s` }}
            >
              {item.image_url && !imageErrors.has(item.id) ? (
                <div className="aspect-video w-full overflow-hidden bg-secondary">
                  <img 
                    src={item.image_url} 
                    alt={item.title}
                    className="w-full h-full object-cover"
                    onError={() => handleImageError(item.id)}
                  />
                </div>
              ) : item.image_url && imageErrors.has(item.id) ? (
                <div className="aspect-video w-full overflow-hidden bg-secondary flex items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <ImageOff className="h-8 w-8 mx-auto mb-2" />
                    <p className="text-sm">Image unavailable</p>
                  </div>
                </div>
              ) : null}
              <div className="p-4">
                <h2 className="font-display font-bold text-lg mb-2">{item.title}</h2>
                {item.content && (
                  <p className="text-sm text-muted-foreground mb-3 whitespace-pre-wrap">{item.content}</p>
                )}
                <p className="text-xs text-muted-foreground">
                  {new Date(item.created_at).toLocaleDateString()}
                </p>
              </div>
            </div>
          ))
        )}
      </main>
    </div>
  );
};

export default NewsEvents;
