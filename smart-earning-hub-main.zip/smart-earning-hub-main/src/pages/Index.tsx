import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { TrendingUp, Users, DollarSign, Shield, ChevronRight, Zap, Globe, Award, Star, CheckCircle, Wallet } from "lucide-react";

interface LiveTransaction {
  id: number;
  user: string;
  type: 'withdraw' | 'earn' | 'refer';
  amount: string;
}

const Index = () => {
  const [logo, setLogo] = useState<string | null>(null);
  const [siteName, setSiteName] = useState("Best Income Platform");
  const [partnerLink, setPartnerLink] = useState("");
  const [supportEmail, setSupportEmail] = useState("");
  const [currentTransaction, setCurrentTransaction] = useState(0);
  
  // Dynamic stats from database
  const [totalPaid, setTotalPaid] = useState(100);
  const [activeUsers, setActiveUsers] = useState(100);
  const [countries, setCountries] = useState(150);
  const [userRating, setUserRating] = useState("4.9");
  const [dailyRoi] = useState("25%");

  // Live transactions data
  const [liveTransactions, setLiveTransactions] = useState<LiveTransaction[]>([
    { id: 1, user: "User ***456", type: 'withdraw', amount: "+$150.00" },
    { id: 2, user: "User ***789", type: 'earn', amount: "+$75.50" },
    { id: 3, user: "User ***123", type: 'refer', amount: "+5 members" },
    { id: 4, user: "User ***321", type: 'withdraw', amount: "+$200.00" },
    { id: 5, user: "User ***654", type: 'earn', amount: "+$45.25" },
  ]);

  useEffect(() => {
    const fetchSettings = async () => {
      const { data } = await supabase
        .from("site_settings")
        .select("key, value")
        .in("key", [
          "site_logo", "site_name", "partner_program_link", "support_email",
          "live_stats_total_paid", "live_stats_active_users", "live_stats_countries", "live_stats_user_rating"
        ]);
      
      if (data) {
        data.forEach(setting => {
          if (setting.key === "site_logo") setLogo(setting.value);
          if (setting.key === "site_name") setSiteName(setting.value || "Best Income Platform");
          if (setting.key === "partner_program_link") setPartnerLink(setting.value || "");
          if (setting.key === "support_email") setSupportEmail(setting.value || "");
          if (setting.key === "live_stats_total_paid") setTotalPaid(parseFloat(setting.value || "100"));
          if (setting.key === "live_stats_active_users") setActiveUsers(parseFloat(setting.value || "100"));
          if (setting.key === "live_stats_countries") setCountries(parseFloat(setting.value || "150"));
          if (setting.key === "live_stats_user_rating") setUserRating(setting.value || "4.9");
        });
      }
    };
    fetchSettings();
  }, []);

  // Auto-rotate live transactions
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTransaction(prev => (prev + 1) % liveTransactions.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [liveTransactions.length]);

  // Payment gateway logos with real logos
  const paymentGateways = [
    { name: "Binance", logo: "https://cryptologos.cc/logos/binance-coin-bnb-logo.png" },
    { name: "Trust", logo: "https://trustwallet.com/assets/images/media/assets/trust_platform.png" },
    { name: "Payeer", logo: "https://www.payeer.com/bitrix/templates/developer/img/payeer-logo.svg" },
    { name: "bKash", logo: "https://www.bkash.com/sites/all/themes/flavor_flavor/logo.png" },
    { name: "USDT", logo: "https://cryptologos.cc/logos/tether-usdt-logo.png" },
    { name: "Nagad", logo: "https://nagad.com.bd/wp-content/uploads/2023/03/nagad-logo-new-300x92-1.png" },
  ];

  const features = [
    { icon: TrendingUp, title: "Multi-Level Earning", desc: "Earn from your entire team network", color: "from-primary to-primary/50" },
    { icon: Users, title: "Growing Community", desc: "Join thousands of active members", color: "from-accent to-accent/50" },
    { icon: DollarSign, title: "Instant Withdrawals", desc: "Quick and secure payment processing", color: "from-success to-success/50" },
    { icon: Globe, title: "Global Platform", desc: "Available in 150+ countries worldwide", color: "from-primary to-accent" },
  ];

  const stats = [
    { icon: DollarSign, value: `$${totalPaid >= 1000000 ? (totalPaid / 1000000).toFixed(1) + 'M+' : totalPaid >= 1000 ? (totalPaid / 1000).toFixed(0) + 'K+' : totalPaid + '+'}`, label: "Total Paid", color: "text-success" },
    { icon: Users, value: `${activeUsers >= 1000 ? (activeUsers / 1000).toFixed(0) + 'K+' : activeUsers + '+'}`, label: "Active Users", color: "text-accent" },
    { icon: TrendingUp, value: dailyRoi, label: "Daily ROI", color: "text-primary" },
    { icon: Star, value: userRating, label: "User Rating", color: "text-warning" },
  ];

  const getTransactionStyle = (type: string) => {
    switch (type) {
      case 'withdraw': return { bg: 'bg-success/10', text: 'text-success', label: 'withdrew' };
      case 'earn': return { bg: 'bg-primary/10', text: 'text-primary', label: 'earned' };
      case 'refer': return { bg: 'bg-accent/10', text: 'text-accent', label: 'referred' };
      default: return { bg: 'bg-muted', text: 'text-muted-foreground', label: '' };
    }
  };

  return (
    <div className="min-h-screen bg-background overflow-hidden">
      {/* Animated background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-accent/10" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-float" style={{ animationDelay: "3s" }} />
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-success/10 rounded-full blur-3xl animate-float" style={{ animationDelay: "1.5s" }} />
      </div>

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between p-4">
        <div className="flex items-center gap-3">
          {logo ? (
            <img src={logo} alt="Logo" className="h-12 w-auto" />
          ) : (
            <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/30">
              <span className="text-primary-foreground font-display font-bold text-xl">B</span>
            </div>
          )}
          <span className="font-display font-bold text-xl text-foreground hidden sm:block">{siteName}</span>
        </div>
      </header>

      {/* Main content */}
      <main className="relative z-10 px-4 pb-8">
        {/* Partner Program Button - Top */}
        <section className="max-w-xs mx-auto mb-4 animate-fade-in">
          <Link to={partnerLink || "/register"}>
            <button className="w-full bg-gradient-to-r from-warning via-accent to-warning bg-[length:200%_100%] animate-shimmer text-primary-foreground px-4 py-2.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 shadow-lg shadow-warning/20 hover:shadow-warning/40 transition-all duration-300 hover:scale-[1.02]">
              <Award className="h-4 w-4" />
              Partner Program
              <ChevronRight className="h-4 w-4" />
            </button>
          </Link>
        </section>

        {/* Hero section */}
        <section className="text-center py-8 animate-fade-in">
          {/* Trust badges */}
          <div className="flex flex-wrap justify-center gap-2 mb-6">
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-success/10 border border-success/30 rounded-full text-xs">
              <Shield className="h-3.5 w-3.5 text-success" />
              <span className="text-success font-medium">100% Secure</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-primary/10 border border-primary/30 rounded-full text-xs">
              <Zap className="h-3.5 w-3.5 text-primary" />
              <span className="text-primary font-medium">Instant Payout</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-accent/10 border border-accent/30 rounded-full text-xs">
              <Award className="h-3.5 w-3.5 text-accent" />
              <span className="text-accent font-medium">Verified</span>
            </div>
          </div>

          <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold mb-4">
            <span className="gradient-text">Welcome to</span>
            <br />
            <span className="text-foreground">{siteName}</span>
          </h1>
          <p className="text-muted-foreground text-base sm:text-lg max-w-lg mx-auto mb-8">
            Join our community and start earning through our referral program. Build your team and grow together.
          </p>

          {/* Stats Grid */}
          <div className="grid grid-cols-4 gap-2 max-w-md mx-auto mb-8">
            {stats.map((stat, idx) => (
              <div key={idx} className="glass-card p-3 animate-slide-up" style={{ animationDelay: `${idx * 0.1}s` }}>
                <stat.icon className={`h-5 w-5 ${stat.color} mx-auto mb-1`} />
                <p className={`font-display font-bold text-lg ${stat.color}`}>{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Payment Gateways with real logos */}
        <section className="max-w-md mx-auto mb-8 animate-slide-up" style={{ animationDelay: "0.4s" }}>
          <div className="glass-card p-4">
            <h3 className="text-center text-sm font-semibold mb-4 flex items-center justify-center gap-2">
              <CheckCircle className="h-4 w-4 text-success" />
              Supported Payment Methods
            </h3>
            <div className="grid grid-cols-6 gap-2">
              {paymentGateways.map((gateway, idx) => (
                <div key={idx} className="flex flex-col items-center gap-1">
                  <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center shadow-lg overflow-hidden">
                    <img 
                      src={gateway.logo} 
                      alt={gateway.name} 
                      className="w-6 h-6 object-contain"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                        e.currentTarget.nextElementSibling?.classList.remove('hidden');
                      }}
                    />
                    <span className="hidden text-primary font-bold text-xs">{gateway.name.charAt(0)}</span>
                  </div>
                  <span className="text-[10px] text-muted-foreground">{gateway.name}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Action buttons */}
        <section className="max-w-sm mx-auto space-y-3 animate-slide-up" style={{ animationDelay: "0.5s" }}>
          <Link to="/auth" className="block">
            <button className="w-full btn-primary flex items-center justify-center gap-2 py-4 text-lg shadow-lg shadow-primary/30">
              <Shield className="h-5 w-5" />
              Sign In
              <ChevronRight className="h-5 w-5" />
            </button>
          </Link>
          
          <Link to="/register" className="block">
            <button className="w-full btn-outline flex items-center justify-center gap-2 py-4 text-lg">
              Create Account
              <ChevronRight className="h-5 w-5" />
            </button>
          </Link>

        </section>

        {/* Features Grid */}
        <section className="max-w-md mx-auto mt-12 animate-slide-up" style={{ animationDelay: "0.6s" }}>
          <h2 className="font-display text-2xl font-bold text-center text-foreground mb-6">Why Choose Us?</h2>
          <div className="grid grid-cols-2 gap-3">
            {features.map((feature, idx) => (
              <div key={idx} className="glass-card p-4 relative overflow-hidden group hover:border-primary/50 transition-all">
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.color} opacity-5 group-hover:opacity-10 transition-opacity`} />
                <div className="relative">
                  <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center mb-3">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-1">{feature.title}</h3>
                  <p className="text-xs text-muted-foreground">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Live Transactions - Auto rotating */}
        <section className="max-w-md mx-auto mt-8 animate-slide-up" style={{ animationDelay: "0.7s" }}>
          <div className="glass-card p-4 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-accent/5" />
            <div className="relative flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-success animate-pulse" />
                <span className="text-sm font-medium">Live Transactions</span>
              </div>
              <span className="text-xs text-muted-foreground">Updated just now</span>
            </div>
            <div className="relative mt-4 space-y-2 h-[120px] overflow-hidden">
              {liveTransactions.map((tx, index) => {
                const style = getTransactionStyle(tx.type);
                const isActive = index === currentTransaction;
                const isPrev = index === (currentTransaction - 1 + liveTransactions.length) % liveTransactions.length;
                const isNext = index === (currentTransaction + 1) % liveTransactions.length;
                
                return (
                  <div 
                    key={tx.id} 
                    className={`flex items-center justify-between p-2 ${style.bg} rounded-lg transition-all duration-500 absolute w-full ${
                      isActive ? 'opacity-100 translate-y-0' : 
                      isPrev ? 'opacity-50 -translate-y-10' : 
                      isNext ? 'opacity-50 translate-y-10' : 'opacity-0 translate-y-20'
                    }`}
                    style={{ top: isActive ? '0' : isPrev ? '-40px' : isNext ? '80px' : '120px' }}
                  >
                    <span className="text-xs">{tx.user} {style.label}</span>
                    <span className={`${style.text} font-bold text-sm`}>{tx.amount}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="max-w-md mx-auto mt-8 animate-slide-up" style={{ animationDelay: "0.8s" }}>
          <h2 className="font-display text-xl font-bold text-center mb-4">What Users Say</h2>
          <div className="glass-card p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <span className="text-primary-foreground font-bold">R</span>
              </div>
              <div>
                <p className="font-semibold text-sm">Rahim K.</p>
                <div className="flex gap-0.5">
                  {[1,2,3,4,5].map(i => <Star key={i} className="h-3 w-3 text-warning fill-warning" />)}
                </div>
              </div>
            </div>
            <p className="text-sm text-muted-foreground italic">
              "Best platform I've ever used! Got my first withdrawal within 24 hours. Highly recommended!"
            </p>
          </div>
        </section>

        {/* Support */}
        {supportEmail && (
          <section className="max-w-sm mx-auto mt-8 text-center animate-slide-up" style={{ animationDelay: "0.9s" }}>
            <div className="glass-card p-4">
              <p className="text-muted-foreground text-sm">
                Need help? Contact us at{" "}
                <a href={`mailto:${supportEmail}`} className="text-primary hover:underline font-medium">
                  {supportEmail}
                </a>
              </p>
            </div>
          </section>
        )}

        {/* Footer */}
        <footer className="mt-12 text-center text-xs text-muted-foreground">
          <p>© 2024 {siteName}. All rights reserved.</p>
        </footer>
      </main>
    </div>
  );
};

export default Index;