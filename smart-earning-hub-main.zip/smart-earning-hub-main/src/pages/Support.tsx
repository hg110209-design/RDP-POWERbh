import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, HeadphonesIcon, ExternalLink } from "lucide-react";

interface SupportLink {
  id: string;
  title: string;
  link: string;
  image_url: string | null;
}

const Support = () => {
  const navigate = useNavigate();
  const [links, setLinks] = useState<SupportLink[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLinks = async () => {
      const { data } = await supabase
        .from("support_links")
        .select("*")
        .eq("is_active", true);

      if (data) {
        setLinks(data);
      }

      setLoading(false);
    };

    fetchLinks();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-20 glass-card rounded-none border-x-0 border-t-0 px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-2 -ml-2 hover:bg-secondary rounded-lg">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="font-display font-bold text-lg gradient-text">Support</h1>
      </header>

      <main className="px-4 py-4 pb-20 space-y-4">
        {links.length === 0 ? (
          <div className="glass-card p-8 text-center animate-slide-up">
            <HeadphonesIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No support links available.</p>
          </div>
        ) : (
          links.map((link, index) => (
            <a
              key={link.id}
              href={link.link}
              target="_blank"
              rel="noopener noreferrer"
              className="glass-card p-4 flex items-center gap-4 hover:border-primary/50 transition-all animate-slide-up"
              style={{ animationDelay: `${0.1 * index}s` }}
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center overflow-hidden flex-shrink-0">
                {link.image_url ? (
                  <img src={link.image_url} alt={link.title} className="w-full h-full object-cover" />
                ) : (
                  <HeadphonesIcon className="h-6 w-6 text-primary-foreground" />
                )}
              </div>
              <div className="flex-1">
                <h2 className="font-semibold text-foreground">{link.title}</h2>
                <p className="text-xs text-muted-foreground truncate">{link.link}</p>
              </div>
              <ExternalLink className="h-5 w-5 text-muted-foreground flex-shrink-0" />
            </a>
          ))
        )}
      </main>
    </div>
  );
};

export default Support;
