import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Trophy, Users, Check, Star, Info } from "lucide-react";

interface Plan {
  id: string;
  name: string;
  description: string | null;
  referral_target: number;
  reward_amount: number;
  order_index: number;
}

interface Progress {
  plan_id: string;
  referrals_completed: number;
  is_completed: boolean;
}

const ProPartnership = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [plans, setPlans] = useState<Plan[]>([]);
  const [progress, setProgress] = useState<Progress[]>([]);
  const [partnersCount, setPartnersCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState<string | null>(null);
  const [partnershipDescription, setPartnershipDescription] = useState("");
  const [partnershipImage, setPartnershipImage] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        navigate("/auth");
        return;
      }

      setUserId(session.user.id);

      // Fetch plans
      const { data: plansData } = await supabase
        .from("pro_partnership_plans")
        .select("*")
        .eq("is_active", true)
        .order("order_index");

      if (plansData) {
        setPlans(plansData);
      }

      // Fetch user progress
      const { data: progressData } = await supabase
        .from("user_partnership_progress")
        .select("*")
        .eq("user_id", session.user.id);

      if (progressData) {
        setProgress(progressData);
      }

      // Fetch partners count
      const { data: profile } = await supabase
        .from("profiles")
        .select("partners_count")
        .eq("user_id", session.user.id)
        .single();

      if (profile) {
        setPartnersCount(profile.partners_count);
      }

      // Fetch partnership settings
      const { data: settings } = await supabase
        .from("site_settings")
        .select("key, value")
        .in("key", ["pro_partnership_description", "pro_partnership_footer_image"]);

      if (settings) {
        settings.forEach(s => {
          if (s.key === "pro_partnership_description") setPartnershipDescription(s.value || "");
          if (s.key === "pro_partnership_footer_image") setPartnershipImage(s.value || "");
        });
      }

      setLoading(false);
    };

    fetchData();
  }, [navigate]);

  const getProgressForPlan = (planId: string) => {
    return progress.find(p => p.plan_id === planId);
  };

  const handleActivateSalary = async (plan: Plan, planProgress: Progress | undefined) => {
    if (!userId) return;

    const referralsNeeded = plan.referral_target;
    const referralsCompleted = planProgress?.referrals_completed || 0;
    
    // Calculate actual referrals for this plan
    // For the first plan, use total partners
    // For subsequent plans, calculate based on previous completions
    const currentPlanIndex = plans.findIndex(p => p.id === plan.id);
    let previousReferrals = 0;
    
    for (let i = 0; i < currentPlanIndex; i++) {
      const prevPlan = plans[i];
      previousReferrals += prevPlan.referral_target;
    }
    
    const effectiveReferrals = Math.max(0, partnersCount - previousReferrals);
    
    if (effectiveReferrals < referralsNeeded) {
      toast({
        title: "Mission Incomplete",
        description: `You need ${referralsNeeded - effectiveReferrals} more referrals to complete this mission.`,
        variant: "destructive",
      });
      return;
    }

    try {
      // Check if progress exists
      if (planProgress) {
        // Update existing progress
        await supabase
          .from("user_partnership_progress")
          .update({
            is_completed: true,
            completed_at: new Date().toISOString(),
            referrals_completed: referralsNeeded,
          })
          .eq("user_id", userId)
          .eq("plan_id", plan.id);
      } else {
        // Create new progress
        await supabase
          .from("user_partnership_progress")
          .insert({
            user_id: userId,
            plan_id: plan.id,
            referrals_completed: referralsNeeded,
            is_completed: true,
            completed_at: new Date().toISOString(),
          });
      }

      // Get next plan name
      const nextPlan = plans[currentPlanIndex + 1];
      
      toast({
        title: "Congratulations!",
        description: `Mission completed! You earned $${plan.reward_amount}.${nextPlan ? ` Next: ${nextPlan.name}` : " You have completed all missions!"}`,
      });

      // Refresh progress
      const { data: newProgress } = await supabase
        .from("user_partnership_progress")
        .select("*")
        .eq("user_id", userId);

      if (newProgress) {
        setProgress(newProgress);
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to activate salary. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-20 glass-card rounded-none border-x-0 border-t-0 px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-2 -ml-2 hover:bg-secondary rounded-lg">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="font-display font-bold text-lg gradient-text">Pro Partnership</h1>
      </header>

      <main className="px-4 py-4 pb-20 space-y-4">
        {/* Current referrals display */}
        <div className="glass-card p-4 flex items-center gap-3 animate-slide-up">
          <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
            <Users className="h-6 w-6 text-primary" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Your Total Referrals</p>
            <p className="font-display text-2xl font-bold">{partnersCount}</p>
          </div>
        </div>

        {/* Plans */}
        {plans.map((plan, index) => {
          const planProgress = getProgressForPlan(plan.id);
          const isCompleted = planProgress?.is_completed;
          
          // Calculate progress
          let previousReferrals = 0;
          for (let i = 0; i < index; i++) {
            previousReferrals += plans[i].referral_target;
          }
          const effectiveReferrals = Math.max(0, partnersCount - previousReferrals);
          const progressPercent = Math.min(100, (effectiveReferrals / plan.referral_target) * 100);
          const canActivate = effectiveReferrals >= plan.referral_target && !isCompleted;

          return (
            <div 
              key={plan.id}
              className="glass-card p-4 animate-slide-up"
              style={{ animationDelay: `${0.1 * (index + 1)}s` }}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${isCompleted ? "bg-success/20" : "bg-warning/20"}`}>
                  {isCompleted ? (
                    <Check className="h-6 w-6 text-success" />
                  ) : (
                    <Trophy className="h-6 w-6 text-warning" />
                  )}
                </div>
                <div className="flex-1">
                  <h2 className="font-display font-bold text-lg">{plan.name}</h2>
                  <p className="text-sm text-muted-foreground">Reward: ${plan.reward_amount}</p>
                </div>
                {isCompleted && (
                  <Star className="h-6 w-6 text-warning fill-warning" />
                )}
              </div>

              {plan.description && (
                <p className="text-sm text-muted-foreground mb-4">{plan.description}</p>
              )}

              {/* Progress meter */}
              <div className="mb-4">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">Progress</span>
                  <span className="font-medium">{Math.min(effectiveReferrals, plan.referral_target)}/{plan.referral_target}</span>
                </div>
                <div className="h-3 bg-secondary rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-500 ${isCompleted ? "bg-success" : "bg-primary"}`}
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>

              {isCompleted ? (
                <div className="bg-success/10 border border-success/30 rounded-lg p-3 text-center">
                  <p className="text-success font-medium flex items-center justify-center gap-2">
                    <Check className="h-4 w-4" />
                    Mission Completed
                  </p>
                </div>
              ) : (
                <button
                  onClick={() => handleActivateSalary(plan, planProgress)}
                  disabled={!canActivate}
                  className={`w-full py-3 rounded-lg font-medium transition-all ${
                    canActivate 
                      ? "btn-primary" 
                      : "bg-secondary text-muted-foreground cursor-not-allowed"
                  }`}
                >
                  {canActivate ? "Active Salary" : `Need ${plan.referral_target - effectiveReferrals} more referrals`}
                </button>
              )}
            </div>
          );
        })}

        {plans.length === 0 && (
          <div className="glass-card p-8 text-center">
            <Trophy className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No partnership plans available yet.</p>
          </div>
        )}

        {/* Partnership Footer Section with Text and Image */}
        {(partnershipDescription || partnershipImage) && (
          <div className="glass-card p-6 animate-slide-up relative overflow-hidden" style={{ animationDelay: `${0.1 * (plans.length + 2)}s` }}>
            {/* Background gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
            
            <div className="relative z-10">
              <div className="flex items-start gap-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <Info className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-display font-bold mb-2">About Partnership Program</h3>
                  {partnershipDescription && (
                    <p className="text-sm text-muted-foreground whitespace-pre-wrap">{partnershipDescription}</p>
                  )}
                </div>
              </div>

              {/* Footer image */}
              {partnershipImage && (
                <div className="flex justify-center mt-4">
                  <img 
                    src={partnershipImage} 
                    alt="Partnership" 
                    className="max-h-40 w-auto object-contain rounded-lg opacity-90"
                  />
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default ProPartnership;
