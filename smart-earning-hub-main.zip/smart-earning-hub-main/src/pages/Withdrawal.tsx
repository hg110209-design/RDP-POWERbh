import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Wallet, Check, X, Clock, Shield, Zap, Lock, ChevronDown, CreditCard } from "lucide-react";

interface WithdrawalMethod {
  id: string;
  name: string;
  image_url: string | null;
  min_amount: number;
  max_amount: number;
}

interface WithdrawalHistory {
  id: string;
  amount: number;
  payment_method: string;
  status: string;
  created_at: string;
}

const Withdrawal = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [balance, setBalance] = useState(0);
  const [methods, setMethods] = useState<WithdrawalMethod[]>([]);
  const [history, setHistory] = useState<WithdrawalHistory[]>([]);
  const [selectedMethod, setSelectedMethod] = useState<WithdrawalMethod | null>(null);
  const [showMethodPicker, setShowMethodPicker] = useState(false);
  const [formData, setFormData] = useState({
    amount: "",
    firstName: "",
    lastName: "",
    accountId: "",
  });
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [footerText, setFooterText] = useState("");
  const [footerImage, setFooterImage] = useState("");
  const [confirmText, setConfirmText] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        navigate("/auth");
        return;
      }

      // Fetch balance
      const { data: profile } = await supabase
        .from("profiles")
        .select("total_profit")
        .eq("user_id", session.user.id)
        .single();

      if (profile) {
        setBalance(profile.total_profit);
      }

      // Fetch withdrawal methods
      const { data: methodsData } = await supabase
        .from("withdrawal_methods")
        .select("*")
        .eq("is_active", true);

      if (methodsData) {
        setMethods(methodsData);
      }

      // Fetch history
      const { data: historyData } = await supabase
        .from("withdrawals")
        .select("*")
        .eq("user_id", session.user.id)
        .order("created_at", { ascending: false })
        .limit(10);

      if (historyData) {
        setHistory(historyData);
      }

      // Fetch footer settings
      const { data: settings } = await supabase
        .from("site_settings")
        .select("key, value")
        .in("key", ["withdrawal_footer_text", "withdrawal_footer_image", "withdrawal_confirm_text"]);

      if (settings) {
        settings.forEach(s => {
          if (s.key === "withdrawal_footer_text") setFooterText(s.value || "");
          if (s.key === "withdrawal_footer_image") setFooterImage(s.value || "");
          if (s.key === "withdrawal_confirm_text") setConfirmText(s.value || "");
        });
      }

      setLoading(false);
    };

    fetchData();
  }, [navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedMethod) {
      toast({
        title: "Error",
        description: "Please select a payment method.",
        variant: "destructive",
      });
      return;
    }

    const amount = parseFloat(formData.amount);

    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Error",
        description: "Please enter a valid amount.",
        variant: "destructive",
      });
      return;
    }

    if (amount > balance) {
      toast({
        title: "Error",
        description: "Insufficient balance.",
        variant: "destructive",
      });
      return;
    }

    if (amount < selectedMethod.min_amount) {
      toast({
        title: "Error",
        description: `Minimum withdrawal amount is $${selectedMethod.min_amount}.`,
        variant: "destructive",
      });
      return;
    }

    if (amount > selectedMethod.max_amount) {
      toast({
        title: "Error",
        description: `Maximum withdrawal amount is $${selectedMethod.max_amount}.`,
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      // Create withdrawal request
      const { error: withdrawError } = await supabase.from("withdrawals").insert({
        user_id: session.user.id,
        amount,
        payment_method: selectedMethod.name,
        account_name: `${formData.firstName} ${formData.lastName}`,
        account_id: formData.accountId,
        status: "pending",
      });

      if (withdrawError) throw withdrawError;

      // Deduct from balance
      const { error: updateError } = await supabase
        .from("profiles")
        .update({ total_profit: balance - amount })
        .eq("user_id", session.user.id);

      if (updateError) throw updateError;

      toast({
        title: "Success",
        description: "Withdrawal request submitted successfully.",
      });

      // Reset form
      setFormData({ amount: "", firstName: "", lastName: "", accountId: "" });
      setSelectedMethod(null);
      setBalance(balance - amount);

      // Refresh history
      const { data: newHistory } = await supabase
        .from("withdrawals")
        .select("*")
        .eq("user_id", session.user.id)
        .order("created_at", { ascending: false })
        .limit(10);

      if (newHistory) {
        setHistory(newHistory);
      }
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to submit withdrawal request.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Animated background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-success/5" />
        <div className="absolute top-1/3 left-1/4 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-1/3 right-1/4 w-64 h-64 bg-success/10 rounded-full blur-3xl animate-float" style={{ animationDelay: "2s" }} />
      </div>

      {/* Header */}
      <header className="sticky top-0 z-20 glass-card rounded-none border-x-0 border-t-0 px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-2 -ml-2 hover:bg-secondary rounded-lg">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="font-display font-bold text-lg gradient-text">Withdrawal</h1>
      </header>

      <main className="relative z-10 px-4 py-4 pb-20 space-y-4">
        {/* Balance Card */}
        <div className="glass-card p-5 animate-slide-up relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-success/10" />
          <div className="relative flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-success flex items-center justify-center shadow-lg shadow-primary/30">
              <Wallet className="h-8 w-8 text-primary-foreground" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground font-medium">Your Balance</p>
              <p className="font-display text-3xl font-bold gradient-text">${balance.toFixed(2)}</p>
            </div>
          </div>
          
          {methods.length > 0 && (
            <div className="relative mt-4 pt-4 border-t border-border grid grid-cols-2 gap-4">
              <div className="glass-card p-3 text-center">
                <p className="text-xs text-muted-foreground mb-1">Min Amount</p>
                <p className="font-display font-bold text-lg">${methods[0]?.min_amount || 0}</p>
              </div>
              <div className="glass-card p-3 text-center">
                <p className="text-xs text-muted-foreground mb-1">Max Amount</p>
                <p className="font-display font-bold text-lg">${methods[0]?.max_amount || 1000}</p>
              </div>
            </div>
          )}
        </div>

        {/* Withdrawal form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Amount */}
          <div className="glass-card p-4 animate-slide-up" style={{ animationDelay: "0.1s" }}>
            <label className="block text-sm font-medium mb-2">Amount (USD)</label>
            <input
              type="number"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              placeholder="Enter amount"
              className="input-field text-lg"
              required
            />
          </div>

          {/* Payment method - Button Style */}
          <div className="glass-card p-4 animate-slide-up" style={{ animationDelay: "0.2s" }}>
            <label className="block text-sm font-medium mb-3">Payment Method</label>
            <button
              type="button"
              onClick={() => setShowMethodPicker(!showMethodPicker)}
              className="w-full flex items-center justify-between p-4 rounded-xl border-2 border-border hover:border-primary/50 transition-all bg-secondary/30"
            >
              {selectedMethod ? (
                <div className="flex items-center gap-3">
                  {selectedMethod.image_url ? (
                    <img src={selectedMethod.image_url} alt={selectedMethod.name} className="h-10 w-10 rounded-lg object-contain" />
                  ) : (
                    <div className="h-10 w-10 rounded-lg bg-primary/20 flex items-center justify-center">
                      <CreditCard className="h-5 w-5 text-primary" />
                    </div>
                  )}
                  <span className="font-medium">{selectedMethod.name}</span>
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-secondary flex items-center justify-center">
                    <CreditCard className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <span className="text-muted-foreground">Select Payment Method</span>
                </div>
              )}
              <ChevronDown className={`h-5 w-5 text-muted-foreground transition-transform ${showMethodPicker ? "rotate-180" : ""}`} />
            </button>

            {/* Method picker dropdown */}
            {showMethodPicker && (
              <div className="mt-3 grid grid-cols-3 gap-2">
                {methods.map((method) => (
                  <button
                    key={method.id}
                    type="button"
                    onClick={() => {
                      setSelectedMethod(method);
                      setShowMethodPicker(false);
                    }}
                    className={`flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all ${
                      selectedMethod?.id === method.id
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-primary/50 bg-secondary/30"
                    }`}
                  >
                    {method.image_url ? (
                      <img src={method.image_url} alt={method.name} className="h-10 w-10 object-contain" />
                    ) : (
                      <div className="h-10 w-10 rounded-lg bg-primary/20 flex items-center justify-center">
                        <CreditCard className="h-5 w-5 text-primary" />
                      </div>
                    )}
                    <span className="text-xs font-medium text-center">{method.name}</span>
                    {selectedMethod?.id === method.id && (
                      <Check className="h-4 w-4 text-primary" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Account details */}
          <div className="glass-card p-4 space-y-4 animate-slide-up" style={{ animationDelay: "0.3s" }}>
            <div>
              <label className="block text-sm font-medium mb-2">First Name</label>
              <input
                type="text"
                value={formData.firstName}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                placeholder="Enter first name"
                className="input-field"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Last Name</label>
              <input
                type="text"
                value={formData.lastName}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                placeholder="Enter last name"
                className="input-field"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Account ID / Number</label>
              <input
                type="text"
                value={formData.accountId}
                onChange={(e) => setFormData({ ...formData, accountId: e.target.value })}
                placeholder="Enter account ID"
                className="input-field"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full btn-primary py-4 text-lg animate-slide-up"
            style={{ animationDelay: "0.4s" }}
          >
            {submitting ? "Processing..." : "Confirm Withdrawal"}
          </button>

          {/* Confirm Text */}
          {confirmText && (
            <div className="glass-card p-4 animate-slide-up" style={{ animationDelay: "0.45s" }}>
              <p className="text-sm text-muted-foreground text-center">{confirmText}</p>
            </div>
          )}
        </form>

        {/* History */}
        {history.length > 0 && (
          <div className="glass-card p-4 animate-slide-up" style={{ animationDelay: "0.5s" }}>
            <h2 className="font-display font-bold text-lg mb-3">Withdrawal History</h2>
            <div className="space-y-3">
              {history.map((item) => (
                <div key={item.id} className="flex items-center justify-between p-3 bg-secondary/50 rounded-xl">
                  <div>
                    <p className="font-display font-bold">${item.amount.toFixed(2)}</p>
                    <p className="text-xs text-muted-foreground">{item.payment_method}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(item.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <div className={`px-3 py-1.5 rounded-full text-xs font-medium flex items-center gap-1.5 ${
                    item.status === "approved" 
                      ? "bg-success/20 text-success" 
                      : item.status === "rejected"
                      ? "bg-destructive/20 text-destructive"
                      : "bg-warning/20 text-warning"
                  }`}>
                    {item.status === "approved" && <Check className="h-3.5 w-3.5" />}
                    {item.status === "rejected" && <X className="h-3.5 w-3.5" />}
                    {item.status === "pending" && <Clock className="h-3.5 w-3.5" />}
                    {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Footer Section with Text and Image */}
        {(footerText || footerImage) && (
          <div className="relative overflow-hidden animate-slide-up" style={{ animationDelay: "0.6s" }}>
            {/* Background blending image */}
            {footerImage && (
              <div className="absolute inset-0 z-0">
                <img 
                  src={footerImage} 
                  alt="Footer background" 
                  className="w-full h-full object-cover opacity-20 blur-sm"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
              </div>
            )}
            
            <div className="glass-card p-6 relative z-10">
              {/* Background gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
              
              <div className="relative z-10">
                {/* Trust badges */}
                <div className="flex justify-center gap-6 mb-6">
                  <div className="flex flex-col items-center">
                    <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mb-2">
                      <Shield className="h-6 w-6 text-primary" />
                    </div>
                    <span className="text-xs text-muted-foreground">Secure</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="w-12 h-12 rounded-full bg-success/20 flex items-center justify-center mb-2">
                      <Zap className="h-6 w-6 text-success" />
                    </div>
                    <span className="text-xs text-muted-foreground">Fast</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center mb-2">
                      <Lock className="h-6 w-6 text-accent" />
                    </div>
                    <span className="text-xs text-muted-foreground">Protected</span>
                  </div>
                </div>

                {/* Footer text */}
                {footerText && (
                  <p className="text-center text-sm text-muted-foreground mb-4">{footerText}</p>
                )}

                {/* Footer image */}
                {footerImage && (
                  <div className="flex justify-center">
                    <img 
                      src={footerImage} 
                      alt="Withdrawal" 
                      className="max-h-32 w-auto object-contain rounded-lg"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default Withdrawal;