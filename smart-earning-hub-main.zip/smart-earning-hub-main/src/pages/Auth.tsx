import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Eye, EyeOff, Mail, Lock, ArrowLeft, Shield, Users, TrendingUp, Globe, Wallet, Award, CheckCircle2 } from "lucide-react";
import { z } from "zod";

const signInSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

const Auth = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [logo, setLogo] = useState<string | null>(null);
  const [signInText, setSignInText] = useState("");
  const [siteName, setSiteName] = useState("Best Income Platform");

  useEffect(() => {
    // Check if already logged in
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        navigate("/dashboard");
      }
    };
    checkAuth();

    // Fetch settings
    const fetchSettings = async () => {
      const { data } = await supabase
        .from("site_settings")
        .select("key, value")
        .in("key", ["site_logo", "sign_in_text", "site_name"]);
      
      if (data) {
        data.forEach(setting => {
          if (setting.key === "site_logo") setLogo(setting.value);
          if (setting.key === "sign_in_text") setSignInText(setting.value || "");
          if (setting.key === "site_name") setSiteName(setting.value || "Best Income Platform");
        });
      }
    };
    fetchSettings();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (session) {
        navigate("/dashboard");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      signInSchema.parse({ email, password });
    } catch (err) {
      if (err instanceof z.ZodError) {
        toast({
          title: "Validation Error",
          description: err.errors[0].message,
          variant: "destructive",
        });
        return;
      }
    }

    setLoading(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        if (error.message.includes("Invalid login credentials")) {
          toast({
            title: "Sign In Failed",
            description: "Invalid email or password. Please try again.",
            variant: "destructive",
          });
        } else {
          toast({
            title: "Sign In Failed",
            description: error.message,
            variant: "destructive",
          });
        }
        return;
      }

      if (data.session) {
        // Check if account is active
        const { data: profile } = await supabase
          .from("profiles")
          .select("status")
          .eq("user_id", data.session.user.id)
          .single();

        if (profile?.status === "pending") {
          toast({
            title: "Account Pending",
            description: "Your account is pending activation. Please wait for admin approval.",
            variant: "destructive",
          });
          await supabase.auth.signOut();
          return;
        }

        toast({
          title: "Welcome Back!",
          description: "Successfully signed in.",
        });
        navigate("/dashboard");
      }
    } catch (err) {
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const features = [
    { icon: Users, label: "Global Community", desc: "Join thousands of partners" },
    { icon: TrendingUp, label: "Daily Earnings", desc: "Earn from multiple sources" },
    { icon: Wallet, label: "Fast Withdrawal", desc: "Quick and secure payments" },
    { icon: Award, label: "Rewards", desc: "Bonuses and incentives" },
  ];

  const stats = [
    { value: "10K+", label: "Active Users" },
    { value: "$500K+", label: "Total Paid" },
    { value: "150+", label: "Countries" },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Background effects */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-accent/10" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/15 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/15 rounded-full blur-3xl animate-float" style={{ animationDelay: "3s" }} />
        {/* Grid pattern */}
        <div className="absolute inset-0 opacity-5" style={{ 
          backgroundImage: 'linear-gradient(hsl(var(--primary)) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--primary)) 1px, transparent 1px)',
          backgroundSize: '50px 50px'
        }} />
      </div>

      {/* Header */}
      <header className="relative z-10 p-4">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back</span>
        </button>
      </header>

      {/* Main content */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 py-8">
        {/* Logo and Welcome */}
        <div className="mb-6 text-center animate-fade-in">
          {logo ? (
            <img src={logo} alt="Logo" className="h-16 w-auto mx-auto mb-4" />
          ) : (
            <div className="h-16 w-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center animate-pulse-glow">
              <Shield className="h-8 w-8 text-primary-foreground" />
            </div>
          )}
          <p className="text-sm text-muted-foreground mb-1">Welcome to</p>
          <h1 className="font-display text-2xl font-bold gradient-text">{siteName}</h1>
        </div>

        {/* Stats bar */}
        <div className="w-full max-w-sm mb-6 animate-slide-up">
          <div className="glass-card p-3 flex justify-around">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <p className="font-display font-bold text-primary text-lg">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Info box */}
        {signInText && (
          <div className="glass-card p-4 mb-6 max-w-sm w-full animate-slide-up border-l-4 border-l-primary">
            <p className="text-sm text-muted-foreground">{signInText}</p>
          </div>
        )}

        {/* Sign in form */}
        <div className="glass-card p-6 w-full max-w-sm animate-slide-up" style={{ animationDelay: "0.1s" }}>
          <div className="text-center mb-6">
            <h2 className="font-display text-xl font-bold gradient-text">Sign In</h2>
            <p className="text-sm text-muted-foreground mt-1">Access your account</p>
          </div>

          <form onSubmit={handleSignIn} className="space-y-4">
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input-field pl-10"
                required
              />
            </div>

            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="input-field pl-10 pr-10"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? "Signing In..." : "Sign In"}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground">
              Don't have an account?{" "}
              <button
                onClick={() => navigate("/register")}
                className="text-primary hover:underline font-medium"
              >
                Register Now
              </button>
            </p>
          </div>
        </div>

        {/* Features grid */}
        <div className="w-full max-w-sm mt-6 animate-slide-up" style={{ animationDelay: "0.2s" }}>
          <div className="grid grid-cols-2 gap-3">
            {features.map((feature, index) => (
              <div key={index} className="glass-card p-3 flex items-start gap-2">
                <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <feature.icon className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="font-medium text-sm text-foreground">{feature.label}</p>
                  <p className="text-xs text-muted-foreground">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Trust badges */}
        <div className="w-full max-w-sm mt-6 animate-slide-up" style={{ animationDelay: "0.3s" }}>
          <div className="flex justify-center items-center gap-4 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <CheckCircle2 className="h-4 w-4 text-success" />
              <span>Verified Platform</span>
            </div>
            <div className="flex items-center gap-1">
              <Shield className="h-4 w-4 text-primary" />
              <span>Secure</span>
            </div>
            <div className="flex items-center gap-1">
              <Globe className="h-4 w-4 text-accent" />
              <span>Worldwide</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Auth;
