import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Coins, RefreshCw, Globe, Shield, Users, Zap, Award, CheckCircle } from "lucide-react";

const GlobalMining = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [exchanging, setExchanging] = useState(false);
  
  // Mining data
  const [hpBalance, setHpBalance] = useState(0);
  const [lastClaimAt, setLastClaimAt] = useState<Date | null>(null);
  const [currentProgress, setCurrentProgress] = useState(0);
  
  // Settings from admin
  const [coinsPerDay, setCoinsPerDay] = useState(1);
  const [hpPrice, setHpPrice] = useState(0);
  const [exchangeStatus, setExchangeStatus] = useState<'coming_soon' | 'price'>('coming_soon');
  
  // User balance
  const [totalProfit, setTotalProfit] = useState(0);
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/auth");
        return;
      }
      
      setUserId(session.user.id);

      // Fetch settings
      const { data: settings } = await supabase
        .from("site_settings")
        .select("key, value")
        .in("key", ["mining_coins_per_day", "mining_hp_price", "mining_exchange_status"]);

      if (settings) {
        settings.forEach(s => {
          if (s.key === "mining_coins_per_day") setCoinsPerDay(parseFloat(s.value || "1"));
          if (s.key === "mining_hp_price") setHpPrice(parseFloat(s.value || "0"));
          if (s.key === "mining_exchange_status") setExchangeStatus(s.value as 'coming_soon' | 'price' || 'coming_soon');
        });
      }

      // Fetch user mining data
      const { data: miningData } = await supabase
        .from("user_mining_data")
        .select("*")
        .eq("user_id", session.user.id)
        .maybeSingle();

      if (miningData) {
        setHpBalance(miningData.hp_balance);
        setLastClaimAt(new Date(miningData.last_claim_at));
      } else {
        // Create mining record for user
        await supabase.from("user_mining_data").insert({
          user_id: session.user.id,
          hp_balance: 0,
          last_claim_at: new Date().toISOString()
        });
        setLastClaimAt(new Date());
      }

      // Fetch user profile for total profit
      const { data: profile } = await supabase
        .from("profiles")
        .select("total_profit")
        .eq("user_id", session.user.id)
        .maybeSingle();

      if (profile) {
        setTotalProfit(profile.total_profit || 0);
      }

      setLoading(false);
    };

    fetchData();
  }, [navigate]);

  // Calculate mining progress - every 100 progress = 1 HP
  useEffect(() => {
    if (!lastClaimAt) return;

    const calculateProgress = () => {
      const now = new Date();
      const timeSinceLastClaim = now.getTime() - lastClaimAt.getTime();
      const secondsPerDay = 24 * 60 * 60; // 86400 seconds
      
      // Calculate progress (0-100 scale, when reaches 100 it becomes 1 HP)
      const secondsPassed = Math.floor(timeSinceLastClaim / 1000);
      const totalProgress = (secondsPassed / secondsPerDay) * 100 * coinsPerDay;
      
      // Progress display (0-99.99)
      const displayProgress = totalProgress % 100;
      setCurrentProgress(displayProgress);
      
      // Calculate full HP coins earned (every 100 progress = 1 HP)
      const fullCoins = Math.floor(totalProgress / 100);
      if (fullCoins > 0 && userId) {
        // Update balance in database
        supabase.from("user_mining_data")
          .update({ 
            hp_balance: hpBalance + fullCoins,
            last_claim_at: new Date().toISOString()
          })
          .eq("user_id", userId)
          .then(() => {
            setHpBalance(prev => prev + fullCoins);
            setLastClaimAt(new Date());
          });
      }
    };

    calculateProgress();
    const interval = setInterval(calculateProgress, 1000);
    return () => clearInterval(interval);
  }, [lastClaimAt, coinsPerDay, userId, hpBalance]);

  const handleExchange = async () => {
    if (exchangeStatus === 'coming_soon') {
      toast({
        title: "Coming Soon",
        description: "HP Exchange will be available soon!",
      });
      return;
    }

    if (hpBalance <= 0) {
      toast({
        title: "Insufficient Balance",
        description: "You don't have any HP coins to exchange.",
        variant: "destructive",
      });
      return;
    }

    setExchanging(true);

    try {
      const exchangeAmount = hpBalance * hpPrice;
      
      // Update user profile balance
      const { error: profileError } = await supabase
        .from("profiles")
        .update({ total_profit: totalProfit + exchangeAmount })
        .eq("user_id", userId);

      if (profileError) throw profileError;

      // Update mining data
      const { error: miningError } = await supabase
        .from("user_mining_data")
        .update({ 
          hp_balance: 0,
          total_exchanged: hpBalance
        })
        .eq("user_id", userId);

      if (miningError) throw miningError;

      setTotalProfit(prev => prev + exchangeAmount);
      setHpBalance(0);

      toast({
        title: "Exchange Successful!",
        description: `You exchanged ${hpBalance} HP for $${exchangeAmount.toFixed(2)}`,
      });
    } catch (error) {
      toast({
        title: "Exchange Failed",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setExchanging(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-accent/10" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/15 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/15 rounded-full blur-3xl animate-float" style={{ animationDelay: "3s" }} />
      </div>

      {/* Header */}
      <header className="sticky top-0 z-20 glass-card rounded-none border-x-0 border-t-0 px-4 py-3 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-2 hover:bg-secondary rounded-lg">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="font-display text-lg font-bold gradient-text">Global Mining</h1>
      </header>

      <main className="relative z-10 px-4 py-6 space-y-6">
        {/* Mining Wheel */}
        <div className="flex flex-col items-center animate-slide-up">
          <div className="relative w-64 h-64">
            {/* Outer glow ring */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-warning/30 via-primary/30 to-warning/30 animate-spin" style={{ animationDuration: '8s' }} />
            
            {/* Inner spinning wheel */}
            <div className="absolute inset-2 rounded-full bg-gradient-to-br from-card via-secondary to-card border-4 border-warning/50 shadow-2xl shadow-warning/20">
              {/* Rotating lights */}
              {[...Array(12)].map((_, i) => (
                <div
                  key={i}
                  className="absolute w-3 h-3 rounded-full bg-warning animate-pulse"
                  style={{
                    top: '50%',
                    left: '50%',
                    transform: `rotate(${i * 30}deg) translateY(-115px) translateX(-50%)`,
                    animationDelay: `${i * 0.1}s`
                  }}
                />
              ))}
              
              {/* Center content */}
              <div className="absolute inset-8 rounded-full bg-gradient-to-br from-secondary to-card flex flex-col items-center justify-center border-2 border-primary/30">
                <Coins className="h-10 w-10 text-warning mb-2 animate-bounce" />
                <span className="text-sm text-muted-foreground">HP Balance</span>
                <span className="font-display text-3xl font-bold text-foreground">
                  {hpBalance.toFixed(2)}
                </span>
                <span className="text-xs text-primary mt-1">
                  +{currentProgress.toFixed(2)}
                </span>
              </div>
            </div>
            
            {/* Progress indicator */}
            <svg className="absolute inset-0 w-full h-full -rotate-90">
              <circle
                cx="128"
                cy="128"
                r="120"
                fill="none"
                stroke="hsl(var(--primary) / 0.2)"
                strokeWidth="4"
              />
              <circle
                cx="128"
                cy="128"
                r="120"
                fill="none"
                stroke="hsl(var(--primary))"
                strokeWidth="4"
                strokeDasharray={`${(currentProgress / 100) * 754} 754`}
                className="transition-all duration-1000"
              />
            </svg>
          </div>
          
          <p className="text-sm text-muted-foreground mt-4">
            Progress: {currentProgress.toFixed(2)} / 100 (1 HP)
          </p>
        </div>

        {/* HP Price / Exchange Rate */}
        <div className="glass-card p-4 animate-slide-up" style={{ animationDelay: "0.1s" }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Coins className="h-5 w-5 text-warning" />
              <span className="text-sm font-medium">HP Exchange Rate</span>
            </div>
            <span className="font-display text-lg font-bold text-primary">
              {exchangeStatus === 'coming_soon' ? 'Coming Soon' : `$${hpPrice.toFixed(4)}`}
            </span>
          </div>
        </div>

        {/* HP Balance & Value */}
        <div className="glass-card p-4 animate-slide-up" style={{ animationDelay: "0.2s" }}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">HP Balance</span>
            <span className="font-display text-xl font-bold">{hpBalance.toFixed(2)} HP</span>
          </div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Progress</span>
            <span className="font-display text-lg font-bold text-primary">{currentProgress.toFixed(2)} / 100</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Value</span>
            <span className="font-display text-lg font-bold text-success">
              {exchangeStatus === 'coming_soon' ? 'Coming Soon' : `$${(hpBalance * hpPrice).toFixed(2)}`}
            </span>
          </div>
        </div>

        {/* Exchange Button */}
        <button
          onClick={handleExchange}
          disabled={exchanging || exchangeStatus === 'coming_soon' || hpBalance <= 0}
          className="w-full btn-primary flex items-center justify-center gap-2 py-4 disabled:opacity-50 disabled:cursor-not-allowed animate-slide-up"
          style={{ animationDelay: "0.3s" }}
        >
          <RefreshCw className={`h-5 w-5 ${exchanging ? 'animate-spin' : ''}`} />
          {exchangeStatus === 'coming_soon' ? 'Exchange Coming Soon' : 'Exchange to USD'}
        </button>

        {/* Mining Info Section */}
        <div className="glass-card p-6 animate-slide-up" style={{ animationDelay: "0.4s" }}>
          <h3 className="font-display text-xl font-bold text-center mb-4 gradient-text">
            About Global Mining
          </h3>
          
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="glass-card p-4 text-center">
              <Globe className="h-8 w-8 text-primary mx-auto mb-2" />
              <p className="font-bold text-lg">150+</p>
              <p className="text-xs text-muted-foreground">Countries</p>
            </div>
            <div className="glass-card p-4 text-center">
              <Users className="h-8 w-8 text-accent mx-auto mb-2" />
              <p className="font-bold text-lg">50K+</p>
              <p className="text-xs text-muted-foreground">Active Miners</p>
            </div>
            <div className="glass-card p-4 text-center">
              <Shield className="h-8 w-8 text-success mx-auto mb-2" />
              <p className="font-bold text-lg">100%</p>
              <p className="text-xs text-muted-foreground">Secure</p>
            </div>
            <div className="glass-card p-4 text-center">
              <Zap className="h-8 w-8 text-warning mx-auto mb-2" />
              <p className="font-bold text-lg">24/7</p>
              <p className="text-xs text-muted-foreground">Mining</p>
            </div>
          </div>

          <div className="space-y-3 text-sm text-muted-foreground">
            <div className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-success flex-shrink-0 mt-0.5" />
              <p>Earn HP coins automatically every 24 hours</p>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-success flex-shrink-0 mt-0.5" />
              <p>Exchange HP coins to real USD when exchange opens</p>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-success flex-shrink-0 mt-0.5" />
              <p>Join miners from over 150 countries worldwide</p>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-success flex-shrink-0 mt-0.5" />
              <p>Secure and reliable mining platform</p>
            </div>
          </div>
        </div>

        {/* Daily Earning Info */}
        <div className="glass-card p-4 animate-slide-up" style={{ animationDelay: "0.5s" }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Award className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">Daily HP Earning</span>
            </div>
            <span className="font-display text-lg font-bold text-primary">
              {coinsPerDay} HP / Day
            </span>
          </div>
        </div>
      </main>
    </div>
  );
};

export default GlobalMining;