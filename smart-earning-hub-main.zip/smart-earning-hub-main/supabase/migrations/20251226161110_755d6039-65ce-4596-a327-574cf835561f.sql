-- Add a policy to allow admins to read all profiles using IN clause
-- First drop the existing policy if it conflicts
DROP POLICY IF EXISTS "Admins can read profiles for pending requests" ON public.profiles;

-- Create a new permissive policy for admins to read all profiles
CREATE POLICY "Admins can read profiles for pending requests" 
ON public.profiles 
FOR SELECT 
USING (has_role(auth.uid(), 'admin'::app_role));