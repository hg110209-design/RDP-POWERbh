-- Create user mining data table
CREATE TABLE public.user_mining_data (
    id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid NOT NULL,
    hp_balance numeric NOT NULL DEFAULT 0,
    last_claim_at timestamp with time zone DEFAULT now(),
    total_exchanged numeric NOT NULL DEFAULT 0,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE public.user_mining_data ENABLE ROW LEVEL SECURITY;

-- Policies for user mining data
CREATE POLICY "Users can view their own mining data" 
ON public.user_mining_data 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own mining data" 
ON public.user_mining_data 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own mining data" 
ON public.user_mining_data 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can manage all mining data" 
ON public.user_mining_data 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role));

-- Add trigger for updated_at
CREATE TRIGGER update_user_mining_data_updated_at
BEFORE UPDATE ON public.user_mining_data
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default mining settings into site_settings
INSERT INTO public.site_settings (key, value) VALUES 
    ('mining_coins_per_day', '1'),
    ('mining_hp_price', '0'),
    ('mining_exchange_status', 'coming_soon'),
    ('live_stats_total_paid', '100'),
    ('live_stats_active_users', '100'),
    ('live_stats_countries', '150'),
    ('live_stats_user_rating', '4.9'),
    ('referral_bonus_amount', '1')
ON CONFLICT (key) DO NOTHING;