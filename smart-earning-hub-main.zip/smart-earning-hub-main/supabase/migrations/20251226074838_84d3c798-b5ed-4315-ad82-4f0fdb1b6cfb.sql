-- Create app_role enum for admin roles
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

-- Create profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  username TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  refer_code TEXT UNIQUE NOT NULL,
  referred_by TEXT,
  profile_image TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'inactive')),
  total_profit DECIMAL(10,2) DEFAULT 0,
  daily_profit DECIMAL(10,2) DEFAULT 0,
  partners_count INTEGER DEFAULT 0,
  total_teams INTEGER DEFAULT 0,
  referral_earn_active BOOLEAN DEFAULT FALSE,
  global_earn_active BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create user_roles table for admin access
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL DEFAULT 'user',
  UNIQUE (user_id, role)
);

-- Create payment_methods table
CREATE TABLE public.payment_methods (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  number TEXT NOT NULL,
  image_url TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create payment_requests table
CREATE TABLE public.payment_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('account_activation', 'referral_earn', 'global_earn')),
  amount DECIMAL(10,2) NOT NULL,
  transaction_id TEXT NOT NULL,
  payment_method TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create withdrawals table
CREATE TABLE public.withdrawals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  payment_method TEXT NOT NULL,
  account_name TEXT NOT NULL,
  account_id TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create pro_partnership_plans table
CREATE TABLE public.pro_partnership_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  referral_target INTEGER NOT NULL,
  reward_amount DECIMAL(10,2) NOT NULL,
  order_index INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create user_partnership_progress table
CREATE TABLE public.user_partnership_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  plan_id UUID REFERENCES public.pro_partnership_plans(id) ON DELETE CASCADE NOT NULL,
  referrals_completed INTEGER DEFAULT 0,
  is_completed BOOLEAN DEFAULT FALSE,
  completed_at TIMESTAMP WITH TIME ZONE,
  UNIQUE (user_id, plan_id)
);

-- Create news_events table
CREATE TABLE public.news_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  content TEXT,
  image_url TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create support_links table
CREATE TABLE public.support_links (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  link TEXT NOT NULL,
  image_url TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create site_settings table
CREATE TABLE public.site_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT UNIQUE NOT NULL,
  value TEXT,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create slider_images table
CREATE TABLE public.slider_images (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  image_url TEXT NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  order_index INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create withdrawal_methods table
CREATE TABLE public.withdrawal_methods (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  image_url TEXT,
  min_amount DECIMAL(10,2) DEFAULT 0,
  max_amount DECIMAL(10,2) DEFAULT 1000,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_methods ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.withdrawals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pro_partnership_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_partnership_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.news_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.slider_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.withdrawal_methods ENABLE ROW LEVEL SECURITY;

-- Create security definer function for role checking
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- RLS Policies for profiles
CREATE POLICY "Users can view their own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profile" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all profiles" ON public.profiles
  FOR SELECT USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update all profiles" ON public.profiles
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for user_roles
CREATE POLICY "Users can view their own roles" ON public.user_roles
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage roles" ON public.user_roles
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for payment_methods (public read, admin write)
CREATE POLICY "Anyone can view payment methods" ON public.payment_methods
  FOR SELECT USING (true);

CREATE POLICY "Admins can manage payment methods" ON public.payment_methods
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for payment_requests
CREATE POLICY "Users can view their own requests" ON public.payment_requests
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own requests" ON public.payment_requests
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can manage all requests" ON public.payment_requests
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for withdrawals
CREATE POLICY "Users can view their own withdrawals" ON public.withdrawals
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own withdrawals" ON public.withdrawals
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can manage all withdrawals" ON public.withdrawals
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for pro_partnership_plans (public read)
CREATE POLICY "Anyone can view plans" ON public.pro_partnership_plans
  FOR SELECT USING (true);

CREATE POLICY "Admins can manage plans" ON public.pro_partnership_plans
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for user_partnership_progress
CREATE POLICY "Users can view their own progress" ON public.user_partnership_progress
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own progress" ON public.user_partnership_progress
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all progress" ON public.user_partnership_progress
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for news_events (public read)
CREATE POLICY "Anyone can view news" ON public.news_events
  FOR SELECT USING (true);

CREATE POLICY "Admins can manage news" ON public.news_events
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for support_links (public read)
CREATE POLICY "Anyone can view support links" ON public.support_links
  FOR SELECT USING (true);

CREATE POLICY "Admins can manage support links" ON public.support_links
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for site_settings (public read)
CREATE POLICY "Anyone can view site settings" ON public.site_settings
  FOR SELECT USING (true);

CREATE POLICY "Admins can manage site settings" ON public.site_settings
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for slider_images (public read)
CREATE POLICY "Anyone can view slider images" ON public.slider_images
  FOR SELECT USING (true);

CREATE POLICY "Admins can manage slider images" ON public.slider_images
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for withdrawal_methods (public read)
CREATE POLICY "Anyone can view withdrawal methods" ON public.withdrawal_methods
  FOR SELECT USING (true);

CREATE POLICY "Admins can manage withdrawal methods" ON public.withdrawal_methods
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- Create function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  new_refer_code TEXT;
  referred_by_code TEXT;
BEGIN
  -- Generate unique refer code
  new_refer_code := (SELECT COALESCE(MAX(CAST(refer_code AS INTEGER)), 0) + 1 FROM public.profiles)::TEXT;
  
  -- Get referred_by from metadata
  referred_by_code := NEW.raw_user_meta_data ->> 'referred_by';
  
  INSERT INTO public.profiles (
    user_id,
    username,
    name,
    email,
    refer_code,
    referred_by,
    status
  ) VALUES (
    NEW.id,
    NEW.raw_user_meta_data ->> 'username',
    NEW.raw_user_meta_data ->> 'name',
    NEW.email,
    new_refer_code,
    referred_by_code,
    'pending'
  );
  
  -- Add default user role
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user');
  
  -- Update referrer's partners count if referred
  IF referred_by_code IS NOT NULL THEN
    UPDATE public.profiles 
    SET partners_count = partners_count + 1
    WHERE refer_code = referred_by_code;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger for new user
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create function to update updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create trigger for profiles updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default site settings
INSERT INTO public.site_settings (key, value) VALUES
  ('site_name', 'Best Income Platform'),
  ('activation_amount', '10'),
  ('referral_earn_amount', '50'),
  ('global_earn_amount', '100'),
  ('referral_bonus', '5'),
  ('global_commission_percent', '10'),
  ('partner_program_link', ''),
  ('support_email', 'support@example.com'),
  ('support_team_link', ''),
  ('domain_link', ''),
  ('sign_in_logo', ''),
  ('registration_guide', 'Welcome to our platform! Follow these steps to activate your account.'),
  ('sign_in_text', 'Welcome back! Sign in to access your dashboard.'),
  ('referral_earn_text', 'Earn money by referring new users to our platform.'),
  ('global_earn_text', 'Earn commission from your entire team network.'),
  ('refer_earn_info', 'Share your referral link and earn rewards for every successful referral.');

-- Insert default Bronze plan
INSERT INTO public.pro_partnership_plans (name, description, referral_target, reward_amount, order_index) VALUES
  ('Bronze', 'Complete 5 referrals to earn your first salary', 5, 25, 1);