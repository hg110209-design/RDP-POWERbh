-- Create table for pro partner info uploads (text and images)
CREATE TABLE public.pro_partner_info (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  type TEXT NOT NULL CHECK (type IN ('referral', 'global')),
  content_type TEXT NOT NULL CHECK (content_type IN ('text', 'image')),
  content TEXT NOT NULL,
  order_index INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.pro_partner_info ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage pro partner info"
ON public.pro_partner_info
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Anyone can view pro partner info"
ON public.pro_partner_info
FOR SELECT
USING (true);

-- Create table for plan activation requests
CREATE TABLE public.plan_activation_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  plan_type TEXT NOT NULL CHECK (plan_type IN ('referral', 'global')),
  transaction_id TEXT NOT NULL,
  payment_method TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.plan_activation_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage plan requests"
ON public.plan_activation_requests
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can view their own requests"
ON public.plan_activation_requests
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own requests"
ON public.plan_activation_requests
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Create table for user active plans tracking
CREATE TABLE public.user_active_plans (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  plan_id UUID REFERENCES public.pro_partnership_plans(id) ON DELETE CASCADE,
  activated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  is_active BOOLEAN DEFAULT true
);

ALTER TABLE public.user_active_plans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage user plans"
ON public.user_active_plans
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can view their own plans"
ON public.user_active_plans
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Anyone can view active plans"
ON public.user_active_plans
FOR SELECT
USING (true);