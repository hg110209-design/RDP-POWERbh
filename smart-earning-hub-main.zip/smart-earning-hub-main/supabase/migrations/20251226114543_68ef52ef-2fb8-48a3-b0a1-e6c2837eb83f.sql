-- Create dashboard posts table for Big Update section
CREATE TABLE public.dashboard_posts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT,
  image_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  is_active BOOLEAN DEFAULT true
);

-- Enable RLS
ALTER TABLE public.dashboard_posts ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Admins can manage dashboard posts" 
ON public.dashboard_posts 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Anyone can view dashboard posts" 
ON public.dashboard_posts 
FOR SELECT 
USING (true);