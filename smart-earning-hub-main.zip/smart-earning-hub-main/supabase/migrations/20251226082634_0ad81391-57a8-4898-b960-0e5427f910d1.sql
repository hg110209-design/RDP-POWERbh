-- Create storage bucket for admin images
INSERT INTO storage.buckets (id, name, public) VALUES ('admin-images', 'admin-images', true);

-- Create storage policy for admin access
CREATE POLICY "Admins can upload images"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'admin-images' AND 
  has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Anyone can view admin images"
ON storage.objects
FOR SELECT
USING (bucket_id = 'admin-images');

CREATE POLICY "Admins can delete images"
ON storage.objects
FOR DELETE
USING (
  bucket_id = 'admin-images' AND 
  has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Admins can update images"
ON storage.objects
FOR UPDATE
USING (
  bucket_id = 'admin-images' AND 
  has_role(auth.uid(), 'admin'::app_role)
);